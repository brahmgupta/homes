﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum TransactionComponentType
    {
        Rollover,
        PersonalNonConcessionalContribution,
        PersonalConcessionalContribution,
        VoluntaryEmployerContribution,
        SalarySacrifice,
        SpousalContributions,
        SuperGuaranteeFromEmployer,
        GovernmentContribution,
        CapitalGainsTaxSmallBusinessRetirementExempt,
        CapitalGainsTaxSmallBusiness15YearExempt,
        PersonalInjury
    }
}