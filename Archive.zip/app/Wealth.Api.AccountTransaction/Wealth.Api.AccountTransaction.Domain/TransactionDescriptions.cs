﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public static class TransactionDescriptions
    {
        public const string AdminFee = "Admin Fee";
        public const string DepositInterest = "Deposit Interest";
        public const string AdvisorFeeRebate = "Advisor Fee Rebate";
        public const string Contributions = "Contributions";
    }
}