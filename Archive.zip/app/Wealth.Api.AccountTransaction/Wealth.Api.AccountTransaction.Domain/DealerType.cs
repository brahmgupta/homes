﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum DealerType
    {
        None,
        FinancialPlanning,
        OnlineBroker,
        Stockbroker,
        CBADealer,
        CBAThirdPartyDealer,
        Masterfund,
        OtherAdvisers,
        SelfDirected,
        Dealer121,
        WhittakerMacNaught,
        CountFinancial
    }
}
