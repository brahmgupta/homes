﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wealth.Api.AccountTransaction.Domain
{
    public class TransactionRefund
    {
        public decimal Amount { get; set; }
        public TransactionRefundType RefundType { get; set; }
    }
}
