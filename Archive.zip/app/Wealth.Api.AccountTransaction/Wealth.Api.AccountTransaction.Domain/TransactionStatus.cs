﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum TransactionStatus
    {
        Pending,
        Unfunded,
        Completed
    }
}