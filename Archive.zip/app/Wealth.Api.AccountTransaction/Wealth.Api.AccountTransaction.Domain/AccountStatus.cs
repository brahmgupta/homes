﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum AccountStatus
    {
        Open = 0,
        Pending = 1,
        Closed = 2,
    }
}