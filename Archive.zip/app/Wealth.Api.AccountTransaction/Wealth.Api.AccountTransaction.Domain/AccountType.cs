﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum AccountType
    {
        Unknown,
        Annuity,
        Cash,
        Pension,
        Superannuation,
        UnitTrust,
        Other
    }
}