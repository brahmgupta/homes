﻿namespace Wealth.Api.AccountTransaction.Domain.Requests
{
    public class GetAccountRequest : RequestContext
    {
        public string AccountNumber { get; set; }
    }
}