﻿namespace Wealth.Api.AccountTransaction.Domain.Requests
{
    public class GetTransactionsRequest : GetAccountRequest
    {
        public AccountType AccountType { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}