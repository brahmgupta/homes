﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum TransactionRefundType
    {
        Redemption,
        Application,
        Others
    }
}