﻿namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers
{
    public class TransactionComponentSetting
    {
        public string Description { get; set; }
        public bool IsTaxable { get; set; }
    }
}