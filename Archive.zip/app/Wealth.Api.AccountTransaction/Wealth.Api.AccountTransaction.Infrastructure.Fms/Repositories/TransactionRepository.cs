﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;
using MediatR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Wealth.Api.AccountTransaction.Domain;
using Wealth.Api.AccountTransaction.Domain.Requests;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetAccounts;
using Wealth.Toolkit.Response.Models;
using Error = FluentResults.Error;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        private static TransactionRequestFactory _transactionRequestFactory;
        private readonly ILogger<ITransactionRepository> _logger;
        private readonly IMediator _mediator;

        public TransactionRepository(IMediator mediator, ILogger<ITransactionRepository> logger,
            TransactionRequestFactory transactionRequestFactory)
        {
            _transactionRequestFactory = transactionRequestFactory;
            _mediator = mediator;
            _logger = logger;
        }

        public async Task<Result<AccountDetails>> GetAccount(GetAccountRequest request,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var contextLogInfo = GetRequestContextLogInfo(request);
            var accountsResult = await GetAccountsList(request, cancellationToken);
            if (accountsResult.IsFailed)
            {
                return accountsResult.ToResult<AccountDetails>();
            }

            var account = accountsResult.ValueOrDefault?.FirstOrDefault(x => x.AccountNumber == request.AccountNumber);
            if (account == null)
            {
                _logger.LogWarning($"No account found for {contextLogInfo}");
                return Results.Fail<AccountDetails>(
                    new Error(ErrorCodes.NotFound).CausedBy(
                        $"No account found for account number {request.AccountNumber}"));
            }

            return account.ToResult();
        }

        public async Task<Result<IEnumerable<Transaction>>> GetTransactions(GetTransactionsRequest request,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var contextLogInfo = GetRequestContextLogInfo(request);

            _logger.LogDebug($"Retrieving transactions for {contextLogInfo}");

            var transactionRequest =
                _transactionRequestFactory.CreateRequest(request);

            var transactionsResult = await _mediator.Send(transactionRequest, cancellationToken);

            if (transactionsResult.IsFailed)
            {
                return transactionsResult.ToResult<IEnumerable<Transaction>>();
            }

            if (_logger.IsEnabled(LogLevel.Debug))
            {
                var transactions = transactionsResult.Value.ToList();
                _logger.LogDebug(!transactions.Any()
                    ? $"No transaction found for {contextLogInfo}"
                    : $"Successfully retrieved transactions for {contextLogInfo}");
            }

            return transactionsResult;
        }

        private async Task<Result<IEnumerable<AccountDetails>>> GetAccountsList(RequestContext request,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var contextLogInfo = GetRequestContextLogInfo(request);
            _logger.LogDebug($"Retrieving accounts for {contextLogInfo}");

            var accountsRequest = new GetAccountsRequest(request);

            var accountsResult = await _mediator.Send(accountsRequest, cancellationToken);
            if (accountsResult.IsFailed)
            {
                return accountsResult.ToResult<IEnumerable<AccountDetails>>();
            }

            if (!accountsResult.Value.Any())
            {
                _logger.LogWarning($"No account found for {contextLogInfo}");
                return Results.Fail<IEnumerable<AccountDetails>>(
                    new Error(ErrorCodes.NotFound).CausedBy($"No account found"));
            }

            return accountsResult;
        }

        private static string GetRequestContextLogInfo(RequestContext request)
        {
            return JsonConvert.SerializeObject(request.OutOfBand);
        }
    }
}