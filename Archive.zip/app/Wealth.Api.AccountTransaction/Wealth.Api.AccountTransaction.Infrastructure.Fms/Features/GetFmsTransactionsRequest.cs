﻿using System.Collections.Generic;
using FluentResults;
using MediatR;
using Wealth.Api.AccountTransaction.Domain;
using Wealth.Api.AccountTransaction.Domain.Requests;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Features
{
    public abstract class GetFmsTransactionsRequest : FmsRequest, IRequest<Result<IEnumerable<Transaction>>>
    {
        protected GetFmsTransactionsRequest(GetTransactionsRequest request) : base(request)
        {
            AccountNumber = request.AccountNumber;
            PageIndex = request.PageIndex;
            PageSize = request.PageSize;
        }

        public string AccountNumber { get; }
        public int PageIndex { get; }
        public int PageSize { get; }
    }
}