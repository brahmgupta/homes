﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Wealth.Api.AccountTransaction.Application.Infrastructure
{
    public static class EnumerableExtensions
    {
        public static IEnumerable<TOut> SafeConvert<TIn, TOut>(this IEnumerable<TIn> @this, Func<TIn, TOut> convert)
        {
            return @this?.Select(convert).Where(item => item != null);
        }
    }
}
