﻿using FluentValidation;
using Wealth.Api.AccountTransaction.Application.Models;
using Wealth.Api.AccountTransaction.Domain;

namespace Wealth.Api.AccountTransaction.Application.Infrastructure
{
    public class BaseRequestValidator<T> : AbstractValidator<T> where T : BaseRequest
    {
        public BaseRequestValidator()
        {
            RuleFor(b => b.OutOfBand)
                .Must(o => o!=null && o.TryGetValue(OutOfBandConstants.OutOfBandCustomerNumberKey, out var customerNumber)
                           && !string.IsNullOrWhiteSpace(customerNumber))
                .Must(o => o != null && o.TryGetValue(OutOfBandConstants.OutOfBandCompanyCodeKey, out var companyCode)
                           && !string.IsNullOrWhiteSpace(companyCode))
                .Must(o => o != null && (o.TryGetValue(OutOfBandConstants.OutOfBandChannelKey, out var channel) &&
                           channel.Equals(OutOfBandConstants.OutOfBandMobileChannelValue) ||
                           o.TryGetValue(OutOfBandConstants.OutOfBandSessionIdKey, out var sessionId)
                           && !string.IsNullOrWhiteSpace(sessionId)));
        }
    }
}
