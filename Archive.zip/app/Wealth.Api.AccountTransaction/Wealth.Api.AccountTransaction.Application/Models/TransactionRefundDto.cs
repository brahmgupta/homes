﻿
namespace Wealth.Api.AccountTransaction.Application.Models
{
    public class TransactionRefundDto
    {
        public decimal Amount { get; set; }
        public string RefundType { get; set; }
    }
}