﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Host.Infrastructure
{
    public static class OutOfBandFactory
    {
        public static IDictionary<string, string> Create(
            string sessionId,
            string channel,
            string companyCode,
            string customerNumber,
            string adviserCode = null, 
            string dealerCode = null,
            string staffOin = null,
            string sourceChannel = null
        )
        {
            var outOfBand = new Dictionary<string, string>
            {
                {nameof(companyCode), companyCode},
                {nameof(customerNumber), customerNumber}
            };

            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                outOfBand.Add(nameof(sessionId), sessionId);
            }

            if (!string.IsNullOrWhiteSpace(channel))
            {
                outOfBand.Add(nameof(channel), channel);
            }

            if (!string.IsNullOrWhiteSpace(adviserCode))
            {
                outOfBand.Add(nameof(adviserCode), adviserCode);
            }

            if (!string.IsNullOrWhiteSpace(dealerCode))
            {
                outOfBand.Add(nameof(dealerCode), dealerCode);
            }

            if (!string.IsNullOrWhiteSpace(staffOin))
            {
                outOfBand.Add(nameof(staffOin), staffOin);
            }

            if (!string.IsNullOrWhiteSpace(sourceChannel))
            {
                outOfBand.Add(nameof(sourceChannel), sourceChannel);
            }

            return outOfBand;
        }
    }
}
