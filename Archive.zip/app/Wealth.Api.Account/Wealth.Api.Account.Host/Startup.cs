using System;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Host.Infrastructure;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Configuration;
using Wealth.Toolkit.HttpService.Extensions;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;
using Wealth.Toolkit.Response.Filters;

[assembly: ApiController]
[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace Wealth.Api.Account.Host
{
    public class Startup
    {
        private const string API_NAME = "Wealth Api Account";

        public Startup(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            configuration.LoadAppSecrets("appsecrets.json", "Wealth.Api.Account.appSecrets.key");
            Configuration = configuration;
            HostingEnvironment = hostingEnvironment;
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment HostingEnvironment { get; }

        // ReSharper disable once UnusedParameter.Local
        private static Task HandleException(HttpContext context)
        {
            return Task.CompletedTask;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public virtual void ConfigureServices(IServiceCollection services)
        {
            services
                .AddMvc(options => { options.Filters.Add(typeof(HttpGlobalExceptionFilter)); })
                .AddJsonOptions(options => { options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore; })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2)
                .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<BaseRequest>());
            services.AddReleaseFeatureToggle(HostingEnvironment.EnvironmentName);
            services.AddHttpServices(Configuration);
            services.AddDependencies(Configuration);
            services
                .AddLogging(logging =>
                {
                    logging.AddConsole();
                    logging.AddConfiguration(Configuration.GetSection("Logging"));
                })
                .AddLoggerContext();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = API_NAME, Version = "V1" });
                c.EnableAnnotations();
                c.DescribeAllEnumsAsStrings();
                c.CustomSchemaIds(x => x.FullName);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public virtual void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            loggerFactory.UseNlog(serviceProvider);
            app.UseRouter(a => a.MapGet("healthcheck", context =>
            {
                context.Response.Headers[HeaderNames.CacheControl] = "no-cache, no-store";
                context.Response.Headers[HeaderNames.Pragma] = "no-cache";
                return context.Response.WriteAsync($"Success from ({env.EnvironmentName})");
            }));

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("../swagger/v1/swagger.json", API_NAME);
                });
            }

            app.UseExceptionHandler(new ExceptionHandlerOptions
            {
                ExceptionHandler = HandleException
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpServices();
            app.UsePerformanceLogger();
            app.UseMvc();
        }
    }
}
