﻿using System.Collections.Generic;
using System.Threading.Tasks;
using FluentResults;

namespace Wealth.Api.Account.Core.Queries
{
    public interface IAccountQueries
    {
        Task<Result<IEnumerable<AccountDto>>> GetAccounts(GetAccountsRequest request);
        Task<Result<AccountDto>> GetAccount(GetAccountRequest request);
    }
}
