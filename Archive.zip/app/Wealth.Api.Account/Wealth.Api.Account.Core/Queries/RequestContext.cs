﻿namespace Wealth.Api.Account.Core.Queries
{
    public class RequestContext
    {
        public string SessionId { get; set; }
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
    }
}