﻿namespace Wealth.Api.Account.Core.Queries
{
    public class InvestmentOptionDto
    {
        public string Name { get; set; }

        public decimal Units { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Amount { get; set; }

        public string AssetType { get; set; }

        public decimal CurrentInterestRate { get; set; }

        public string ProductGroup { get; set; }
    }
}
