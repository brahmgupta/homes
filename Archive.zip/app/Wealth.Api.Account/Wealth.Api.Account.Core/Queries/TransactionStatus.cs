﻿namespace Wealth.Api.Account.Core.Queries
{
    public enum TransactionStatus
    {
        Pending,
        Unfunded,
        Completed
    }
}
