using System;

namespace Wealth.Api.Account.Core.Queries
{
    public class BeneficiaryDto
    {
        public BeneficiaryType BeneficiaryType { get; set; }

        public string Name { get; set; }

        public DateTime? Dob { get; set; }

        public string Relationship { get; set; }

        public decimal? Percentage { get; set; }
    }
}