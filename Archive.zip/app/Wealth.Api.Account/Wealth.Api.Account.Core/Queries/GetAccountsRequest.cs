﻿namespace Wealth.Api.Account.Core.Queries
{
    public class GetAccountsRequest : RequestContext
    {
        public AccountStatus AccountStatus { get; set; }
    }
}