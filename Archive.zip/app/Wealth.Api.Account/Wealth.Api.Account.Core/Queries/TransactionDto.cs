﻿using System;

namespace Wealth.Api.Account.Core.Queries
{
    public class TransactionDto
    {
        public DateTime? Date { get; set; }

        public string Description { get; set; }

        public decimal Amount { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Units { get; set; }

        public decimal UnitBalance { get; set; }

        public bool IsRefunded { get; set; }

        public decimal Fees { get; set; }

        public decimal Net { get; set; }

        public decimal AccountBalance { get; set; }

        public TransactionStatus Status { get; set; }
    }
}
