﻿using RichardSzalay.MockHttp;

namespace Wealth.Api.Account.Tests
{
    public class TestHttpMessageHandler
    {
        public TestHttpMessageHandler()
        {
            Instance = new MockHttpMessageHandler();
        }

        public MockHttpMessageHandler Instance { get; }
    }
}
