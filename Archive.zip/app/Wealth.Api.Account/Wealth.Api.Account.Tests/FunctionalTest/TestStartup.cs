﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NSubstitute;
using Wealth.Api.Account.Domain.AccountAggregate;
using Wealth.Api.Account.Host;
using Wealth.Api.Account.Host.Infrastructure;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Fms;
using Wealth.Toolkit.Response.Filters;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public class TestStartup : Startup
    {
        public TestStartup(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
            : base(configuration, hostingEnvironment)
        {
        }

        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);

            services
                .AddSingleton(x => Substitute.For<IAccountRepository>());

            var testHttpMessageHandler = new TestHttpMessageHandler();
            var mockHttpClient = testHttpMessageHandler.Instance.ToHttpClient();
            services.AddReleaseFeatureToggle("development");
            services
                .AddTransient<IFmsResponseHandler>(x =>
                    new FmsResponseHandler(Substitute.For<ILogger<FmsResponseHandler>>()));
            services.Configure<AppSettings>(Configuration);

            var serviceProvider = services.BuildServiceProvider();
            var fmsGatewayApiSettings = serviceProvider.GetService<IOptions<FmsGatewayApiSettings>>();
            var fmsResponseHandler = serviceProvider.GetService<IFmsResponseHandler>();
            var logger = Substitute.For<ILogger<FmsHttpService>>();

            services
                .AddMvc(options => { options.Filters.Add(typeof(HttpGlobalExceptionFilter)); })
                .AddJsonOptions(options =>
                {
                    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                });

            services.AddDependencies(Configuration);

            services
                .AddSingleton(x => testHttpMessageHandler)
                .AddTransient<IFmsHttpService>(x =>
                    new FmsHttpService(mockHttpClient, fmsGatewayApiSettings, fmsResponseHandler, logger));
        }
    }
}
