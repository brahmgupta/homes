﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Newtonsoft.Json;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Infrastructure;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Ppde;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests : BaseTest
    {
        private PensionPaymentDetailsDto pensionPaymentDetails;

        class PensionPaymentTestData
        {
            public string PAccountFeeOption { get; set; }

            public string PAllocatedPensionAccountFlag { get; set; }

            public string PPensionType { get; set; }

            public string PPreRetirementIndicator { get; set; }

            public string PFirstPaymentDateChangeFlag { get; set; }

            public string PPaymentFrequency { get; set; }

            public string PPaymentFrequencyDescription { get; set; }

            public DateTime PLastPaymentDate { get; set; }

            public decimal PLastPaymentAmount { get; set; }

            public DateTime PNextPaymentDate { get; set; }

            public decimal PNextPaymentAmount { get; set; }

            public string PAnnualPensionRequested { get; set; }

            public decimal PMinAmountPercentage { get; set; }

            public decimal PMaxAmountPercentage { get; set; }

            public decimal PTerm { get; set; }

            public decimal PGrossAnnualAmount { get; set; }

            public decimal PGrossPerPaymentAmount { get; set; }

            public DateTime PNextAllowedMonthlyPaymentDate { get; set; }

            public decimal PGrossAnnualAllowed { get; set; }

            public DateTime PLastFundValDate { get; set; }

            public string PIncreasedByCPI { get; set; }

            public decimal PCPIRate { get; set; }

            public string PProRataEditable { get; set; }

            public string PProRata { get; set; }

            public string PIncomeVariationType { get; set; }

            public decimal PGrossSpecifiedAnnualAmount { get; set; }

            public decimal PIncomeVariancePercentage { get; set; }

            public string PNewComponent { get; set; }

            public string PAnnualPaymentFinancialYear { get; set; }

            public decimal PPaymentRequired { get; set; }

            public decimal PYearToDatePaid { get; set; }

            public decimal PRemainingPayment { get; set; }

            public decimal PDeductibleAllowed { get; set; }

            public decimal PDeductibleYearToDatePaid { get; set; }

            public decimal PRebatePreDays { get; set; }

            public decimal PRebatePostDays { get; set; }

            public decimal PFeePaymentAmount { get; set; }

            public int PPensionPaymentDetailCount { get; set; }

            public string PPensionPaymentBankBSBNumber { get; set; }

            public string PPensionPaymentBankShortName { get; set; }

            public string PPensionPaymentBankName { get; set; }

            public string PPensionPaymentBankAccountNumber { get; set; }

            public string PPensionPaymentBankAccountName { get; set; }

            public int PPensionScheduleDetailCount { get; set; }

            public DateTime PPensionScheduleDate { get; set; }

            public string PPensionPaymentScheduleWarning { get; set; }

            public string PManagedAccountFlag { get; set; }

            public string PPensionDrawdownAutoAlign { get; set; }

        }

        class PensionPaymentExpectedData
        {
            public string EAccountFeeOption { get; set; }

            public string EAllocatedPensionAccountFlag { get; set; }

            public string EPensionType { get; set; }

            public string EPreRetirementIndicator { get; set; }

            public string EFirstPaymentDateChangeFlag { get; set; }

            public string EPaymentFrequency { get; set; }

            public string EPaymentFrequencyDescription { get; set; }

            public DateTime ELastPaymentDate { get; set; }

            public decimal ELastPaymentAmount { get; set; }

            public DateTime ENextPaymentDate { get; set; }

            public decimal ENextPaymentAmount { get; set; }

            public string EAnnualPensionRequested { get; set; }

            public decimal EMinAmountPercentage { get; set; }

            public decimal EMaxAmountPercentage { get; set; }

            public decimal ETerm { get; set; }

            public decimal EGrossAnnualAmount { get; set; }

            public decimal EGrossPerPaymentAmount { get; set; }

            public DateTime ENextAllowedMonthlyPaymentDate { get; set; }

            public decimal EGrossAnnualAllowed { get; set; }

            public DateTime ELastFundValDate { get; set; }

            public string EIncreasedByCPI { get; set; }

            public decimal ECPIRate { get; set; }

            public string EProRataEditable { get; set; }

            public string EProRata { get; set; }

            public string EIncomeVariationType { get; set; }

            public decimal EGrossSpecifiedAnnualAmount { get; set; }

            public decimal EIncomeVariancePercentage { get; set; }

            public string ENewComponent { get; set; }

            public string EAnnualPaymentFinancialYear { get; set; }

            public decimal EPaymentRequired { get; set; }

            public decimal EYearToDatePaid { get; set; }

            public decimal ERemainingPayment { get; set; }

            public decimal EDeductibleAllowed { get; set; }

            public decimal EDeductibleYearToDatePaid { get; set; }

            public decimal ERebatePreDays { get; set; }

            public decimal ERebatePostDays { get; set; }

            public decimal EFeePaymentAmount { get; set; }

            public int EPensionPaymentDetailCount { get; set; }

            public string EPensionPaymentBankBSBNumber { get; set; }

            public string EPensionPaymentBankShortName { get; set; }

            public string EPensionPaymentBankName { get; set; }

            public string EPensionPaymentBankAccountNumber { get; set; }

            public string EPensionPaymentBankAccountName { get; set; }

            public int EPensionScheduleDetailCount { get; set; }

            public DateTime EPensionScheduleDate { get; set; }

            public string EPensionPaymentScheduleWarning { get; set; }

            public string EManagedAccountFlag { get; set; }

            public string EPensionDrawdownAutoAlign { get; set; }

        }

        private void CallPensionPaymentDetailMock(PensionPaymentTestData data)
        {
            MockGetPensionPaymentDetailsRplResponse(data.PAccountFeeOption, data.PAllocatedPensionAccountFlag, data.PPensionType, data.PPreRetirementIndicator, data.PFirstPaymentDateChangeFlag,
            data.PPaymentFrequency, data.PPaymentFrequencyDescription, data.PLastPaymentAmount, data.PNextPaymentAmount,
            data.PAnnualPensionRequested, data.PMinAmountPercentage, data.PMaxAmountPercentage, data.PTerm, data.PGrossAnnualAmount, data.PGrossPerPaymentAmount,
            data.PGrossAnnualAllowed, data.PIncreasedByCPI, data.PCPIRate, data.PProRataEditable,
            data.PProRata, data.PIncomeVariationType, data.PGrossSpecifiedAnnualAmount, data.PIncomeVariancePercentage, data.PNewComponent, data.PAnnualPaymentFinancialYear,
            data.PPaymentRequired, data.PPensionScheduleDetailCount, data.PManagedAccountFlag, data.PPensionDrawdownAutoAlign, data.PPensionPaymentDetailCount);
        }

        private void ValidatePensionPaymentDetails(PensionPaymentExpectedData expData)
        {
            pensionPaymentDetails.AccountFeeOption.Should().Be(expData.EAccountFeeOption);
            pensionPaymentDetails.AllocatedPensionAccountFlag.Should().Be(expData.EAllocatedPensionAccountFlag);
            pensionPaymentDetails.PensionType.Should().Be(expData.EPensionType);
            pensionPaymentDetails.PreRetirementIndicator.Should().Be(expData.EPreRetirementIndicator);
            pensionPaymentDetails.FirstPaymentDateChangeFlag.Should().Be(expData.EFirstPaymentDateChangeFlag);
            pensionPaymentDetails.PaymentFrequency.Should().Be(expData.EPaymentFrequency);
            pensionPaymentDetails.PaymentFrequencyDescription.Should().Be(expData.EPaymentFrequencyDescription);
            pensionPaymentDetails.LastPaymentAmount.Should().Be(expData.ELastPaymentAmount);
            pensionPaymentDetails.NextPaymentAmount.Should().Be(expData.ENextPaymentAmount);
            pensionPaymentDetails.AnnualPensionRequested.Should().Be(expData.EAnnualPensionRequested);
            pensionPaymentDetails.MinAmountPercentage.Should().Be(expData.EMinAmountPercentage);
            pensionPaymentDetails.MaxAmountPercentage.Should().Be(expData.EMaxAmountPercentage);
            pensionPaymentDetails.Term.Should().Be(expData.ETerm);
            pensionPaymentDetails.GrossAnnualAmount.Should().Be(expData.EGrossAnnualAmount);
            pensionPaymentDetails.GrossPerPaymentAmount.Should().Be(expData.EGrossPerPaymentAmount);
            pensionPaymentDetails.GrossAnnualAllowed.Should().Be(expData.EGrossAnnualAllowed);
            pensionPaymentDetails.IncreasedByCPI.Should().Be(expData.EIncreasedByCPI);
            pensionPaymentDetails.CPIRate.Should().Be(expData.ECPIRate);
            pensionPaymentDetails.ProRataEditable.Should().Be(expData.EProRataEditable);
            pensionPaymentDetails.ProRata.Should().Be(expData.EProRata);
            pensionPaymentDetails.IncomeVariationType.Should().Be(expData.EIncomeVariationType);
            pensionPaymentDetails.GrossSpecifiedAnnualAmount.Should().Be(expData.EGrossSpecifiedAnnualAmount);
            pensionPaymentDetails.IncomeVariancePercentage.Should().Be(expData.EIncomeVariancePercentage);
            pensionPaymentDetails.NewComponent.Should().Be(expData.ENewComponent);
            pensionPaymentDetails.AnnualPaymentFinancialYear.Should().Be(expData.EAnnualPaymentFinancialYear);
            pensionPaymentDetails.PaymentRequired.Should().Be(expData.EPaymentRequired);
            pensionPaymentDetails.PensionScheduleDetailCount.Should().Be(expData.EPensionScheduleDetailCount);
            pensionPaymentDetails.ManagedAccountFlag.Should().Be(expData.EManagedAccountFlag);
            pensionPaymentDetails.PensionDrawdownAutoAlign.Should().Be(expData.EPensionDrawdownAutoAlign);
        }

        private void MockGetPensionPaymentDetailsRplResponse(string PAccountFeeOption, string PAllocatedPensionAccountFlag, string PPensionType, string PPreRetirementIndicator,
            string PFirstPaymentDateChangeFlag, string PPaymentFrequency, string PPaymentFrequencyDescription, decimal PLastPaymentAmount, decimal PNextPaymentAmount,
            string PAnnualPensionRequested, decimal PMinAmountPercentage, decimal PMaxAmountPercentage, decimal PTerm, decimal PGrossAnnualAmount, decimal PGrossPerPaymentAmount,
            decimal PGrossAnnualAllowed, string PIncreasedByCPI, decimal PCPIRate, string PProRataEditable,
            string PProRata, string PIncomeVariationType, decimal PGrossSpecifiedAnnualAmount, decimal PIncomeVariancePercentage, string PNewComponent, string PAnnualPaymentFinancialYear,
            decimal PPaymentRequired, int PPensionScheduleDetailCount, string PManagedAccountFlag, string PPensionDrawdownAutoAlign, int PPensionPaymentDetailCount)
        {

            var rplResponse = MyFixture.Build<GetPensionPaymentDetailsRplResponse>()
            .With(p => p.AccountFeeOption, PAccountFeeOption)
            .With(p => p.AllocatedPensionAccountFlag, PAllocatedPensionAccountFlag)
            .With(p => p.PensionType, PPensionType)
            .With(p => p.PreRetirementIndicator, PPreRetirementIndicator)
            .With(p => p.FirstPaymentDateChangeFlag, PFirstPaymentDateChangeFlag)
            .With(p => p.PaymentFrequency, PPaymentFrequency)
            .With(p => p.PaymentFrequencyDescription, PPaymentFrequencyDescription)
            .With(p => p.LastPaymentDate, FmsType.ToDecimalDate(DateTime.Parse("2019-01-01")))
            .With(p => p.LastPaymentAmount, PLastPaymentAmount)
            .With(p => p.NextPaymentDate, FmsType.ToDecimalDate(DateTime.Parse("2019-01-01")))
            .With(p => p.NextPaymentAmount, PNextPaymentAmount)
            .With(p => p.AnnualPensionRequested, PAnnualPensionRequested)
            .With(p => p.MinAmountPercentage, PMinAmountPercentage)
            .With(p => p.MaxAmountPercentage, PMaxAmountPercentage)
            .With(p => p.Term, PTerm)
            .With(p => p.GrossAnnualAmount, PGrossAnnualAmount)
            .With(p => p.GrossPerPaymentAmount, PGrossPerPaymentAmount)
            .With(p => p.NextAllowedMonthlyPaymentDate, FmsType.ToDecimalDate(DateTime.Parse("2019-01-01")))
            .With(p => p.GrossAnnualAllowed, PGrossAnnualAllowed)
            .With(p => p.LastFundValDate, FmsType.ToDecimalDate(DateTime.Parse("2019-01-01")))
            .With(p => p.IncreasedByCPI, PIncreasedByCPI)
            .With(p => p.CPIRate, PCPIRate)
            .With(p => p.ProRataEditable, PProRataEditable)
            .With(p => p.ProRata, PProRata)
            .With(p => p.IncomeVariationType, PIncomeVariationType)
            .With(p => p.GrossSpecifiedAnnualAmount, PGrossSpecifiedAnnualAmount)
            .With(p => p.IncomeVariancePercentage, PIncomeVariancePercentage)
            .With(p => p.NewComponent, PNewComponent)
            .With(p => p.AnnualPaymentFinancialYear, PAnnualPaymentFinancialYear)
            .With(p => p.PaymentRequired, PPaymentRequired)
            .With(p => p.PensionScheduleDetailCount, PPensionScheduleDetailCount)
            .With(p => p.PensionScheduleDate, new List<decimal> { FmsType.ToDecimalDate(DateTime.Parse("2019-01-01")) })
            .With(p => p.MessageIndicator, 0)
            .With(p => p.ManagedAccountFlag, PManagedAccountFlag)
            .With(p => p.PensionDrawdownAutoAlign, PPensionDrawdownAutoAlign)
            .With(p => p.PensionPaymentDetailCount, PPensionPaymentDetailCount)
            .Without(p => p.MessageType)
            .Without(p => p.Messages)
            .Create();

            MockRplResponse("FIRPPDED", rplResponse);
        }

        [Theory]
        [ExcelData("FunctionalTest\\PensionPayment_Enquiry_GetData_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetPensionPaymentDetails(
                    string PaccountFeeOption, string PallocatedPensionAccountFlag, string PpensionType, string PpreRetirementIndicator, string PfirstPaymentDateChangeFlag,
                    string PpaymentFrequency, string PpaymentFrequencyDescription, decimal PlastPaymentAmount,
                    decimal PnextPaymentAmount, string PannualPensionRequested, decimal PminAmountPercentage, decimal PmaxAmountPercentage, decimal Pterm, decimal PgrossAnnualAmount,
                    decimal PgrossPerPaymentAmount, decimal PgrossAnnualAllowed, string PincreasedByCPI, decimal PcPIRate,
                    string PproRataEditable, string PproRata, string PincomeVariationType, decimal PgrossSpecifiedAnnualAmount, decimal PincomeVariancePercentage, string PnewComponent,
                    string PannualPaymentFinancialYear, decimal PpaymentRequired, int PpensionScheduleDetailCount, string PmanagedAccountFlag,
                    string PpensionDrawdownAutoAlign, int PpensionPaymentDetailCount,
                    string EaccountFeeOption, string EallocatedPensionAccountFlag, string EpensionType, string EpreRetirementIndicator, string EfirstPaymentDateChangeFlag,
                    string EpaymentFrequency, string EpaymentFrequencyDescription, decimal ElastPaymentAmount, decimal EnextPaymentAmount,
                    string EannualPensionRequested, decimal EminAmountPercentage, decimal EmaxAmountPercentage, decimal Eterm, decimal EgrossAnnualAmount,
                    decimal EgrossPerPaymentAmount, decimal EgrossAnnualAllowed, string EincreasedByCPI, decimal EcPIRate,
                    string EproRataEditable, string EproRata, string EincomeVariationType, decimal EgrossSpecifiedAnnualAmount, decimal EincomeVariancePercentage, string EnewComponent,
                    string EannualPaymentFinancialYear, decimal EpaymentRequired, int EpensionScheduleDetailCount, string EmanagedAccountFlag, string EpensionDrawdownAutoAlign,
                    int EpensionPaymentDetailCount)
        {
            var accountNumber = MyFixture.Create<int>();

            var pensionPaymentData = new PensionPaymentTestData
            {
                PAccountFeeOption = PaccountFeeOption,
                PAllocatedPensionAccountFlag = PallocatedPensionAccountFlag,
                PPensionType = PpensionType,
                PPreRetirementIndicator = PpreRetirementIndicator,
                PFirstPaymentDateChangeFlag = PfirstPaymentDateChangeFlag,
                PPaymentFrequency = PpaymentFrequency,
                PPaymentFrequencyDescription = PpaymentFrequencyDescription,
                PLastPaymentAmount = PlastPaymentAmount,
                PNextPaymentAmount = PnextPaymentAmount,
                PAnnualPensionRequested = PannualPensionRequested,
                PMinAmountPercentage = PminAmountPercentage,
                PMaxAmountPercentage = PmaxAmountPercentage,
                PTerm = Pterm,
                PGrossAnnualAmount = PgrossAnnualAmount,
                PGrossPerPaymentAmount = PgrossPerPaymentAmount,
                PGrossAnnualAllowed = PgrossAnnualAllowed,
                PIncreasedByCPI = PincreasedByCPI,
                PCPIRate = PcPIRate,
                PProRataEditable = PproRataEditable,
                PProRata = PproRata,
                PIncomeVariationType = PincomeVariationType,
                PGrossSpecifiedAnnualAmount = PgrossSpecifiedAnnualAmount,
                PIncomeVariancePercentage = PincomeVariancePercentage,
                PNewComponent = PnewComponent,
                PAnnualPaymentFinancialYear = PannualPaymentFinancialYear,
                PPaymentRequired = PpaymentRequired,
                PPensionScheduleDetailCount = PpensionScheduleDetailCount,
                PManagedAccountFlag = PmanagedAccountFlag,
                PPensionDrawdownAutoAlign = PpensionDrawdownAutoAlign,
                PPensionPaymentDetailCount = PpensionPaymentDetailCount
            };

            var pensionPaymentExpectedData = new PensionPaymentExpectedData
            {
                EAccountFeeOption = EaccountFeeOption,
                EAllocatedPensionAccountFlag = EallocatedPensionAccountFlag,
                EPensionType = EpensionType,
                EPreRetirementIndicator = EpreRetirementIndicator,
                EFirstPaymentDateChangeFlag = EfirstPaymentDateChangeFlag,
                EPaymentFrequency = EpaymentFrequency,
                EPaymentFrequencyDescription = EpaymentFrequencyDescription,
                ELastPaymentAmount = ElastPaymentAmount,
                ENextPaymentAmount = EnextPaymentAmount,
                EAnnualPensionRequested = EannualPensionRequested,
                EMinAmountPercentage = EminAmountPercentage,
                EMaxAmountPercentage = EmaxAmountPercentage,
                ETerm = Eterm,
                EGrossAnnualAmount = EgrossAnnualAmount,
                EGrossPerPaymentAmount = EgrossPerPaymentAmount,
                EGrossAnnualAllowed = EgrossAnnualAllowed,
                EIncreasedByCPI = EincreasedByCPI,
                ECPIRate = EcPIRate,
                EProRataEditable = EproRataEditable,
                EProRata = EproRata,
                EIncomeVariationType = EincomeVariationType,
                EGrossSpecifiedAnnualAmount = EgrossSpecifiedAnnualAmount,
                EIncomeVariancePercentage = EincomeVariancePercentage,
                ENewComponent = EnewComponent,
                EAnnualPaymentFinancialYear = EannualPaymentFinancialYear,
                EPaymentRequired = EpaymentRequired,
                EPensionScheduleDetailCount = EpensionScheduleDetailCount,
                EManagedAccountFlag = EmanagedAccountFlag,
                EPensionDrawdownAutoAlign = EpensionDrawdownAutoAlign,
                EPensionPaymentDetailCount = EpensionPaymentDetailCount
            };

            CallPensionPaymentDetailMock(pensionPaymentData);

            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/drawdown?customerNumber=12345678").GetAsync();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            pensionPaymentDetails = JsonConvert.DeserializeObject<PensionPaymentDetailsDto>(jsonResponse);

            ValidatePensionPaymentDetails(pensionPaymentExpectedData);
        }

        [Theory]
        [ExcelData("FunctionalTest\\PensionPayment_Enquiry_GetData_TestData.xlsx")]
        public async Task ShouldThrowNotFoundErrorWhenNoAccountNumberPassed(
                    string PaccountFeeOption, string PallocatedPensionAccountFlag, string PpensionType, string PpreRetirementIndicator, string PfirstPaymentDateChangeFlag,
                    string PpaymentFrequency, string PpaymentFrequencyDescription, decimal PlastPaymentAmount,
                    decimal PnextPaymentAmount, string PannualPensionRequested, decimal PminAmountPercentage, decimal PmaxAmountPercentage, decimal Pterm, decimal PgrossAnnualAmount,
                    decimal PgrossPerPaymentAmount, decimal PgrossAnnualAllowed, string PincreasedByCPI, decimal PcPIRate,
                    string PproRataEditable, string PproRata, string PincomeVariationType, decimal PgrossSpecifiedAnnualAmount, decimal PincomeVariancePercentage, string PnewComponent,
                    string PannualPaymentFinancialYear, decimal PpaymentRequired, int PpensionScheduleDetailCount, string PmanagedAccountFlag,
                    string PpensionDrawdownAutoAlign, int PpensionPaymentDetailCount,
                    string EaccountFeeOption, string EallocatedPensionAccountFlag, string EpensionType, string EpreRetirementIndicator, string EfirstPaymentDateChangeFlag,
                    string EpaymentFrequency, string EpaymentFrequencyDescription, decimal ElastPaymentAmount, decimal EnextPaymentAmount,
                    string EannualPensionRequested, decimal EminAmountPercentage, decimal EmaxAmountPercentage, decimal Eterm, decimal EgrossAnnualAmount,
                    decimal EgrossPerPaymentAmount, decimal EgrossAnnualAllowed, string EincreasedByCPI, decimal EcPIRate,
                    string EproRataEditable, string EproRata, string EincomeVariationType, decimal EgrossSpecifiedAnnualAmount, decimal EincomeVariancePercentage, string EnewComponent,
                    string EannualPaymentFinancialYear, decimal EpaymentRequired, int EpensionScheduleDetailCount, string EmanagedAccountFlag, string EpensionDrawdownAutoAlign,
                    int EpensionPaymentDetailCount)
        {
            var accountNumber = string.Empty;

            var pensionPaymentData = new PensionPaymentTestData
            {
                PAccountFeeOption = PaccountFeeOption,
                PAllocatedPensionAccountFlag = PallocatedPensionAccountFlag,
                PPensionType = PpensionType,
                PPreRetirementIndicator = PpreRetirementIndicator,
                PFirstPaymentDateChangeFlag = PfirstPaymentDateChangeFlag,
                PPaymentFrequency = PpaymentFrequency,
                PPaymentFrequencyDescription = PpaymentFrequencyDescription,
                PLastPaymentAmount = PlastPaymentAmount,
                PNextPaymentAmount = PnextPaymentAmount,
                PAnnualPensionRequested = PannualPensionRequested,
                PMinAmountPercentage = PminAmountPercentage,
                PMaxAmountPercentage = PmaxAmountPercentage,
                PTerm = Pterm,
                PGrossAnnualAmount = PgrossAnnualAmount,
                PGrossPerPaymentAmount = PgrossPerPaymentAmount,
                PGrossAnnualAllowed = PgrossAnnualAllowed,
                PIncreasedByCPI = PincreasedByCPI,
                PCPIRate = PcPIRate,
                PProRataEditable = PproRataEditable,
                PProRata = PproRata,
                PIncomeVariationType = PincomeVariationType,
                PGrossSpecifiedAnnualAmount = PgrossSpecifiedAnnualAmount,
                PIncomeVariancePercentage = PincomeVariancePercentage,
                PNewComponent = PnewComponent,
                PAnnualPaymentFinancialYear = PannualPaymentFinancialYear,
                PPaymentRequired = PpaymentRequired,
                PPensionScheduleDetailCount = PpensionScheduleDetailCount,
                PManagedAccountFlag = PmanagedAccountFlag,
                PPensionDrawdownAutoAlign = PpensionDrawdownAutoAlign,
                PPensionPaymentDetailCount = PpensionPaymentDetailCount
            };

            CallPensionPaymentDetailMock(pensionPaymentData);

            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/drawdown?customerNumber=12345678").GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }
    }
}
