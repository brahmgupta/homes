﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aaex;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aapp;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aasf;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Abpb;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Ewaa;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Iesf;
using Wealth.Toolkit.Fms;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests : BaseTest
    {
        private const string SESSION_ID = "sessionId";
        private const string COMPANY_CODE = "companyCode";
        private const string CHANNEL = "channel";

        private const string ADVISER_CODE = "adviserCode";
        private const string DEALER_CODE = "dealerCode";
        private const string STAFF_OIN = "staffOIN";

        private const string SuperFund = "SF";
        private const string PersonalSuper = "PS";
        private const string AnnuityFund = "CF";
        private const string PensionFund = "PP";
        private const string UnitTrust = "UT";

        private AccountDto account;
        private const string BeneficiaryType_DOB = "dob";

        class BeneficiaryTestData
        {
            public decimal AccountValue { get; set; }
            public int AccountNumber { get; set; }
            public string ProductType { get; set; }
            public List<decimal> DdobList { get; set; }
            public string BbeneficiaryType { get; set; }
            public List<string> BbeneficiaryDescription { get; set; }
            public List<string> BbindingNominationNames { get; set; }
            public List<decimal> BbenefitiaryPercentsList { get; set; }
            public List<string> Rrelationships { get; set; }
            public decimal ExpiryDateStatus { get; set; }
            public string AccessLevel { get; set; }
        }

        class BeneficiaryExpectedData
        {
            public string EexpProductType { get; set; }
            public List<decimal> EexpDobs { get; set; }
            public List<string> EexpBeneficiaryTypes { get; set; }
            public List<string> EexpBeneficiaryDescriptions { get; set; }
            public List<string> EexpBindingNominationNames { get; set; }
            public List<decimal> EexpBenefitiaryPercents { get; set; }
            public List<string> EexpRelationships { get; set; }
            public int EaccessMode { get; set; }
        }
        Dictionary<string, Action<BeneficiaryTestData>> callBeneficiaryMock;
        private void BuildBeneficiaryMocks()
        {
            callBeneficiaryMock = new Dictionary<string, Action<BeneficiaryTestData>>
            {
                { SuperFund, CallSuperAccountMock },
                { PersonalSuper, CallSuperAccountMock },
                { AnnuityFund, CallAnnuityAccountMock },
                { PensionFund, CallPensionAccountMock }
            };
        }

        public AccountsControllerTests()
        {
            BuildBeneficiaryMocks();
            BuildBeneficiaryResponses();
            BuildInsuranceMocks();
            BuildInsuranceResponse();
            BuildInvestmentsMocks();
            BuildInvestmentsResponse();
            BuildTransactionsMocks();
            BuildTransactionsResponse();
            BuildUpdateInsuranceMocks();
        }

        Dictionary<string, Action<BeneficiaryExpectedData>> beneficiaryValidation;
        private void BuildBeneficiaryResponses()
        {
            beneficiaryValidation = new Dictionary<string, Action<BeneficiaryExpectedData>>
            {
                { SuperFund, ValidateSuperAccountBeneficiaryResponse },
                { PersonalSuper, ValidateSuperAccountBeneficiaryResponse },
                { AnnuityFund, ValidateAnnuityAccountResponse },
                { PensionFund, ValidatePensionAccountResponse }
            };
        }

        private RequestBuilder CreateRequestBuilder(string path, string sessionId = "12345", string companyCode = "001",
            string adviserCode = "1234", string dealerCode = "4321", string staffOIN = "12345678")
        {
            return Server
                .CreateRequest(path)
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .AddHeader(SESSION_ID, sessionId)
                .AddHeader(COMPANY_CODE, companyCode)
                .AddHeader(ADVISER_CODE, adviserCode)
                .AddHeader(DEALER_CODE, dealerCode)
                .AddHeader(STAFF_OIN, staffOIN);
        }

        private RequestBuilder CreateRequestMobileChannelBuilder(string path, string companyCode = "001")
        {
            return Server
                .CreateRequest(path)
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .AddHeader(CHANNEL, "mobile")
                .AddHeader(COMPANY_CODE, companyCode);
        }


        private void CallSuperAccountMock(BeneficiaryTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType, data.AccessLevel);
            MockGetAccountBeneficiaryRplResponse(data.DdobList, data.BbeneficiaryType, data.BbindingNominationNames, data.BbenefitiaryPercentsList,
                data.Rrelationships, data.BbeneficiaryDescription, data.ExpiryDateStatus);
            MockGetSuperannuationAccountInvestmentsRplResponse();
            MockGetInvestmentAssetAllocationRplResponse();
        }

        private void CallAnnuityAccountMock(BeneficiaryTestData data)
        {
            List<string> beneficiaryTypes = data.BbeneficiaryType.Split(",").ToList();
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType, data.AccessLevel, isAnnuity: true);
            MockGetExternalManagedAccountDetailsRplResponse(data.DdobList, beneficiaryTypes, data.BbeneficiaryDescription, data.BbindingNominationNames, data.BbenefitiaryPercentsList,
                data.Rrelationships);
        }

        private void CallPensionAccountMock(BeneficiaryTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType, data.AccessLevel);
            MockGetPensionAccountDetailsRplResponse(data.DdobList, data.BbeneficiaryType, data.BbeneficiaryDescription, data.BbindingNominationNames, data.BbenefitiaryPercentsList,
                data.Rrelationships, data.ExpiryDateStatus);
            MockGetInvestmentAssetAllocationRplResponse();
        }

        private void ValidateSuperAccountBeneficiaryResponse(BeneficiaryExpectedData expData)
        {
            var beneficiary = account.Beneficiaries.ToArray();
            var typrOfBbeneficiary = beneficiary.GetType();
            for (int i = 0; i < expData.EexpBindingNominationNames.Count; i++)
            {
                account.AccountType.Should().Be(expData.EexpProductType);
                account.OpenAccountsCount.Should().Be(1);
                account.AccessMode.Should().Be(expData.EaccessMode);
                if (expData.EexpDobs[i] == 0)
                {
                    typrOfBbeneficiary.GetProperty(BeneficiaryType_DOB).Should().BeNull();
                }
                else
                {
                    beneficiary[i].Dob.Should().Be(FmsHelper.ToDate(expData.EexpDobs.ToArray()[i]));
                }
                beneficiary[i].Type.Should().Be(NullToString(expData.EexpBeneficiaryTypes[i]));
                beneficiary[i].Description.Should().Be(NullToString(expData.EexpBeneficiaryDescriptions[i]));
                beneficiary[i].Name.Should().Be(expData.EexpBindingNominationNames[i]);
                beneficiary[i].Percentage.Should().Be(expData.EexpBenefitiaryPercents[i]);
                beneficiary[i].Relationship.Should().Be(expData.EexpRelationships[i]);
            }
        }

        private void ValidateAnnuityAccountResponse(BeneficiaryExpectedData expData)
        {
            var beneficiary = account.Beneficiaries.ToArray();
            var typrOfBbeneficiary = beneficiary.GetType();
            for (int i = 0; i < expData.EexpBindingNominationNames.Count; i++)
            {
                account.AccountType.Should().Be(expData.EexpProductType);
                account.OpenAccountsCount.Should().Be(1);
                account.AccessMode.Should().Be(expData.EaccessMode);
                if (expData.EexpDobs[i] == 0)
                {
                    typrOfBbeneficiary.GetProperty(BeneficiaryType_DOB).Should().BeNull();
                }
                else
                {
                    beneficiary[i].Dob.Should().Be(FmsHelper.ToDate(expData.EexpDobs.ToArray()[i]));
                }
                beneficiary[i].Type.Should().Be(NullToString(expData.EexpBeneficiaryTypes[i]));
                beneficiary[i].Name.Should().Be(expData.EexpBindingNominationNames[i]);
                beneficiary[i].Percentage.Should().Be(expData.EexpBenefitiaryPercents[i]);
                beneficiary[i].Relationship.Should().Be(expData.EexpRelationships[i]);
            }
        }

        private void ValidatePensionAccountResponse(BeneficiaryExpectedData expData)
        {
            var beneficiary = account.Beneficiaries.ToArray();
            var typrOfBbeneficiary = beneficiary.GetType();
            for (int i = 0; i < expData.EexpBindingNominationNames.Count; i++)
            {
                account.AccountType.Should().Be(expData.EexpProductType);
                account.OpenAccountsCount.Should().Be(1);
                account.AccessMode.Should().Be(expData.EaccessMode);
                if (expData.EexpDobs[i] == 0)
                {
                    typrOfBbeneficiary.GetProperty(BeneficiaryType_DOB).Should().BeNull();
                }
                else
                {
                    beneficiary[i].Dob.Should().Be(FmsHelper.ToDate(expData.EexpDobs.ToArray()[i]));
                }
                beneficiary[i].Type.Should().Be(NullToString(expData.EexpBeneficiaryTypes[i]));
                beneficiary[i].Description.Should().Be(NullToString(expData.EexpBeneficiaryDescriptions[i]));
                beneficiary[i].Name.Should().Be(expData.EexpBindingNominationNames[i]);
                beneficiary[i].Percentage.Should().Be(expData.EexpBenefitiaryPercents[i]);
                beneficiary[i].Relationship.Should().Be(expData.EexpRelationships[i]);
            }
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetAccountForExistingAccountNumber(string productType
            , string dobs, string beneficiaryType, string beneficiaryDescrition, string bindingNominationName,
            string benefitiaryPercent, string relationship, decimal expiryDateStatus, string expProductType
            , string expDob, string expBeneficiaryType, string expBeneficiaryDescription, string expBindingNominationName,
            string expBenefitiaryPercent, string expRelationship, string accessLevel, int expAccessLevel)
        {
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();

            // Arrange
            var myTestData = new BeneficiaryTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                DdobList = dobs.Split(",").Select(decimal.Parse).ToList(),
                BbeneficiaryType = beneficiaryType,
                BbeneficiaryDescription = beneficiaryDescrition.Split(",").ToList(),
                BbenefitiaryPercentsList = benefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                BbindingNominationNames = bindingNominationName.Split(',').ToList(),
                Rrelationships = relationship.Split(',').ToList(),
                ExpiryDateStatus = expiryDateStatus,
                AccessLevel = accessLevel
            };

            var myExpectedTestData = new BeneficiaryExpectedData
            {
                EexpProductType = expProductType,
                EexpDobs = expDob.Split(",").Select(decimal.Parse).ToList(),
                EexpBeneficiaryTypes = expBeneficiaryType.Split(",").ToList(),
                EexpBeneficiaryDescriptions = expBeneficiaryDescription.Split(",").ToList(),
                EexpBindingNominationNames = expBindingNominationName.Split(',').ToList(),
                EexpBenefitiaryPercents = expBenefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                EexpRelationships = expRelationship.Split(',').ToList(),
                EaccessMode = expAccessLevel
            };

            //Calling product type
            callBeneficiaryMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}?customerNumber=12345").GetAsync();

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<AccountDto>(jsonResponse);

            //Test Validation
            beneficiaryValidation[productType](myExpectedTestData);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetAccountForExistingAccountNumberForMobileChannel(string productType
            , string dobs, string beneficiaryType, string beneficiaryDescrition, string bindingNominationName,
            string benefitiaryPercent, string relationship, decimal expiryDateStatus, string expProductType
            , string expDob, string expBeneficiaryType, string expBeneficiaryDescription, string expBindingNominationName,
            string expBenefitiaryPercent, string expRelationship, string accessLevel, int expAccessLevel)
        {
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();

            // Arrange
            var myTestData = new BeneficiaryTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                DdobList = dobs.Split(",").Select(decimal.Parse).ToList(),
                BbeneficiaryType = beneficiaryType,
                BbeneficiaryDescription = beneficiaryDescrition.Split(",").ToList(),
                BbenefitiaryPercentsList = benefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                BbindingNominationNames = bindingNominationName.Split(',').ToList(),
                Rrelationships = relationship.Split(',').ToList(),
                ExpiryDateStatus = expiryDateStatus,
                AccessLevel = accessLevel
            };

            var myExpectedTestData = new BeneficiaryExpectedData
            {
                EexpProductType = expProductType,
                EexpDobs = expDob.Split(",").Select(decimal.Parse).ToList(),
                EexpBeneficiaryTypes = expBeneficiaryType.Split(",").ToList(),
                EexpBeneficiaryDescriptions = expBeneficiaryDescription.Split(",").ToList(),
                EexpBindingNominationNames = expBindingNominationName.Split(',').ToList(),
                EexpBenefitiaryPercents = expBenefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                EexpRelationships = expRelationship.Split(',').ToList(),
                EaccessMode = expAccessLevel
            };

            //Calling product type
            callBeneficiaryMock[productType](myTestData);

            // Act
            var response = await CreateRequestMobileChannelBuilder($"/api/accounts/{accountNumber}?customerNumber=12345").GetAsync();

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<AccountDto>(jsonResponse);

            //Test Validation
            beneficiaryValidation[productType](myExpectedTestData);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetAccountsWithDetails(string productType
            , string dobs, string beneficiaryType, string beneficiaryDescrition, string bindingNominationName,
            string benefitiaryPercent, string relationship, decimal expiryDateStatus, string expProductType
            , string expDob, string expBeneficiaryType, string expBeneficiaryDescription, string expBindingNominationName,
            string expBenefitiaryPercent, string expRelationship, string accessLevel, int expAccessLevel)
        {
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();

            // Arrange
            var myTestData = new BeneficiaryTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                DdobList = dobs.Split(",").Select(decimal.Parse).ToList(),
                BbeneficiaryType = beneficiaryType,
                BbeneficiaryDescription = beneficiaryDescrition.Split(",").ToList(),
                BbenefitiaryPercentsList = benefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                BbindingNominationNames = bindingNominationName.Split(',').ToList(),
                Rrelationships = relationship.Split(',').ToList(),
                ExpiryDateStatus = expiryDateStatus,
                AccessLevel = accessLevel
            };

            var myExpectedTestData = new BeneficiaryExpectedData
            {
                EexpProductType = expProductType,
                EexpDobs = expDob.Split(",").Select(decimal.Parse).ToList(),
                EexpBeneficiaryTypes = expBeneficiaryType.Split(",").ToList(),
                EexpBeneficiaryDescriptions = expBeneficiaryDescription.Split(",").ToList(),
                EexpBindingNominationNames = expBindingNominationName.Split(',').ToList(),
                EexpBenefitiaryPercents = expBenefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                EexpRelationships = expRelationship.Split(',').ToList(),
                EaccessMode = expAccessLevel
            };

            //Calling product type
            callBeneficiaryMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts?customerNumber=12345&details=true").GetAsync();

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<IEnumerable<AccountDto>>(jsonResponse).First();

            //Test Validation
            beneficiaryValidation[productType](myExpectedTestData);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetAccountsWithoutDetails(string productType
            , string dobs, string beneficiaryType, string beneficiaryDescrition, string bindingNominationName,
            string benefitiaryPercent, string relationship, decimal expiryDateStatus, string expProductType
            , string expDob, string expBeneficiaryType, string expBeneficiaryDescription, string expBindingNominationName,
            string expBenefitiaryPercent, string expRelationship, string accessLevel, int expAccessLevel)
        {
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();

            // Arrange
            var myTestData = new BeneficiaryTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                DdobList = dobs.Split(",").Select(decimal.Parse).ToList(),
                BbeneficiaryType = beneficiaryType,
                BbeneficiaryDescription = beneficiaryDescrition.Split(",").ToList(),
                BbenefitiaryPercentsList = benefitiaryPercent.Split(",").Select(decimal.Parse).ToList(),
                BbindingNominationNames = bindingNominationName.Split(',').ToList(),
                Rrelationships = relationship.Split(',').ToList(),
                ExpiryDateStatus = expiryDateStatus,
                AccessLevel = accessLevel
            };
            //Calling product type
            callBeneficiaryMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts?customerNumber=12345&details=false").GetAsync();

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<IEnumerable<AccountDto>>(jsonResponse).First();

            //Test Validation
            account.AccountNumber.Should().Be(accountNumber.ToString());
            account.AccountType.Should().Be(expProductType);
            account.Beneficiaries.Count().Should().Be(0);
            account.InvestmentOptions.Count().Should().Be(0);
            account.Transactions.Count().Should().Be(0);
            account.Insurance.Should().BeNull();
            account.DealerType.Should().Be("None");
            account.AccessMode.Should().Be(expAccessLevel);
        }

        //ANNUITY RPL
        private void MockGetExternalManagedAccountDetailsRplResponse(List<decimal> dobs, List<string> beneficiaryType, List<string> beneficiaryDescriptions, List<string> bindingNominationNames,
            List<decimal> benefitPercentage, List<string> relationships)
        {
            var rplResponse = MyFixture.Build<GetExternalManagedAccountDetailsRplResponse>()
                .With(p => p.NumberOfBeneficiaries, dobs.Count)
                .With(p => p.DateOfBirth, dobs)
                .With(p => p.TypeCode, beneficiaryType)
                .With(p => p.TypeDescription, beneficiaryDescriptions)
                .With(p => p.BeneficiaryName, bindingNominationNames)
                .With(p => p.BenefitPercentage, benefitPercentage)
                .With(p => p.RelationshipDescription, relationships)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAAEXD", rplResponse);
        }

        //PENSION RPL
        private void MockGetPensionAccountDetailsRplResponse(List<decimal> dobs, string beneficiaryType, List<string> beneficiaryDescriptions, List<string> bindingNominationNames,
            List<decimal> benefitPercentage, List<string> relationships, decimal expiryDateStatus)
        {
            var rplResponse = MyFixture.Build<GetPensionAccountDetailsRplResponse>()
                .With(p => p.BindingNominationDetailCount, dobs.Count)
                .With(p => p.InvestmentOptionDetailCount, 0)
                .With(p => p.BeneficiaryDateOfBirth, dobs)
                .With(p => p.BeneficiaryType, NullToString(beneficiaryType))
                .With(p => p.BeneficiaryName, bindingNominationNames)
                .With(p => p.BeneficiaryPercent, benefitPercentage)
                .With(p => p.BeneficiaryDescription, beneficiaryDescriptions)
                .With(p => p.BeneficiaryRelationshipDescription, relationships)
                .With(p => p.ExpiryDateStatus, expiryDateStatus)
                .With(p => p.EffectiveDate, 0)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAAPPJ", rplResponse);
        }

        public string NullToString(string value)
        {
            switch (value)
            {
                case "NULL":
                    return "";
                case " ":
                    return "";
                default:
                    return value;
            }
        }

        // INVESTMENT RPLs
        private void MockGetInvestmentAssetAllocationRplResponse()
        {
            var rplResponse = MyFixture.Build<GetInvestmentAssetAllocationsRplResponse>()
                .With(i => i.InvestmentOptionDetailCount, 0)
                .With(i => i.InvestmentTotalAllocationPercentages, new List<decimal>(){0,0,0,0,0,0,0})
                .With(i => i.InvestmentOptionEffectiveDate, new List<decimal>() { 0 })
                .Without(i => i.MessageType)
                .Without(i => i.Messages)
                .Without(i => i.MessageCount)
                .Without(i => i.MessageIndicator)
                .Create();
            MockRplResponse("FIREWAAA", rplResponse);
        }

        private void MockGetSuperannuationAccountInvestmentsRplResponse()
        {
            var rplResponse = MyFixture.Build<SuperannuationAccountInvestmentsRplResponse>()
                .With(p => p.InvestmentOptionDetailCount, 0)
                .With(p => p.InvestmentOptionName, new List<string>())
                .With(p => p.InvestmentOptionUnits, new List<decimal>())
                .With(p => p.InvestmentOptionUnitPrice, new List<decimal>())
                .With(p => p.InvestmentOptionAmount, new List<decimal>())
                .With(p => p.InvestmentOptionProductGroup, new List<string>())
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAASFH", rplResponse);
        }


        private void MockGetPensionInvestmentsRplResponse()
        {
            var rplResponse = MyFixture.Build<GetPensionAccountDetailsRplResponse>()
                .With(p => p.InvestmentOptionDetailCount, 0)
                .With(p => p.InvestmentOptionName, new List<string>())
                .With(p => p.InvestmentOptionUnits, new List<decimal>())
                .With(p => p.InvestmentOptionUnitPrice, new List<decimal>())
                .With(p => p.InvestmentOptionAmount, new List<decimal>())
                .With(p => p.InvestmentOptionProductGroup, new List<string>())
                .With(p => p.BindingNominationDetailCount, 0)
                .With(p => p.BeneficiaryDateOfBirth, new List<decimal>())
                .With(p => p.BeneficiaryType, "")
                .With(p => p.BeneficiaryName, new List<string>())
                .With(p => p.BeneficiaryPercent, new List<decimal>())
                .With(p => p.BeneficiaryDescription, new List<string>())
                .With(p => p.BeneficiaryRelationshipDescription, new List<string>())
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAAPPJ", rplResponse);
        }

        //SUPER RPL
        private void MockGetAccountBeneficiaryRplResponse(List<decimal> dobs, string beneficiaryType,
            List<string> bindingNominationNames,
            List<decimal> benefitiaryPercents,
            List<string> relationships,
            List<string> beneficiaryDescriptions,
            decimal expiryDateStatus)
        {
            var rplResponse = MyFixture.Build<GetAccountInsuranceRplResponse>()
                .With(p => p.BindingNominationDetailCount, dobs.Count)
                .With(p => p.BenefitiaryDateOfBirth, dobs)
                .With(p => p.BeneficiaryType, NullToString(beneficiaryType))
                .With(p => p.BeneficiaryDescription, beneficiaryDescriptions)
                .With(p => p.BindingNominationName, bindingNominationNames)
                .With(p => p.BenefitiaryPercent, benefitiaryPercents)
                .With(p => p.Relationship, relationships)
                .With(p => p.BindingNominationDetailCount, bindingNominationNames.Count())
                .With(p => p.MessageIndicator, 0)
                .With(p => p.IsSmoker, "Y")
                .With(p => p.ExpiryDateStatus, expiryDateStatus)
                .With(p => p.InsuranceElectionDate, 20190101)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRIESFJ", rplResponse);
        }

        //ANNUITY ACCOUNT
        private void MockGetAccountsRplResponse(
            decimal accountValue,
            int accountNumber,
            string productType,
            string accessLevel = "02",
            bool isAnnuity = false,
            string productAbbreviation = null)
        {
            productAbbreviation = productAbbreviation ?? MyFixture.Create<string>();
            var rplResponse = MyFixture.Build<GetAccountsRplResponse>()
                .With(p => p.AccountNumber, new List<decimal> { accountNumber })
                .With(p => p.AccountValue, new List<decimal> { accountValue })
                .With(p => p.ProductType, new List<string> { productType })
                .With(p => p.ProductAbbreviation, new List<string>(){productAbbreviation})
                .With(p => p.AccountsCount, 1)
                .With(p => p.GroupId, new List<string> { isAnnuity ? "E" : "" })
                .With(p => p.BalanceDate, "20190417")
                .With(p => p.MessageIndicator, 0)
                .With(p => p.NextPaymentDate, new List<string> { "20190417"})
                .With(p => p.NextPaymentAmount, new List<decimal> { 1 })
                .With(p => p.AccountDesignation, new List<string> { "my super account" })
                .With(p => p.OwnerData, "Owner name")
                .With(p => p.Continue, 0)
                .With(p => p.Status, new List<string> {"Open"})
                .With(p => p.AccessLevel, new List<string>{ accessLevel })
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRABPBI", rplResponse);
        }

        private void MockRplResponse(string rplName, object expectedRplResponse,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            MockHttp
                .When(HttpMethod.Post, $"{AppSettings.FmsGatewayApi.BaseUrl}/{rplName}")
                .Respond(httpStatusCode, new StringContent(JsonConvert.SerializeObject(expectedRplResponse)));
        }
    }
}