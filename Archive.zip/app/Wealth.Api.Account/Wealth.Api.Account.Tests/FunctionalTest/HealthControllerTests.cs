using System.IO;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Wealth.Api.Account.Host;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public class HealthControllerTests
    {
        private TestServer _server;

        [Fact]
        public async Task ShouldReturnOkGivenHealthIsCalled()
        {
            _server = new TestServer(new WebHostBuilder()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>());

            var response = await _server.CreateRequest("healthcheck").GetAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}
