﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Newtonsoft.Json;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Atpp;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Atsf;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests
    {
        private const string DATE_COMPARISON_FORMAT = "MM/dd/yyyy";
        private class TransactionsTestData
        {
            public decimal AccountValue { get; set; }
            public int AccountNumber { get; set; }
            public string ProductType { get; set; }
            public long TransactionDetailCount { get; set; }
            public IList<long> TransactionDate { get; set; }
            public IList<string> TransactionDescription { get; set; }
            public IList<decimal> TransactionAmount { get; set; }
            public IList<decimal> TransactionUnitPrice { get; set; }
            public IList<decimal> TransactionUnits { get; set; }
            public IList<decimal> TransactionUnitBalance { get; set; }
            public IList<string> PendingFlag { get; set; }
            public IList<decimal> TransactionFees { get; set; }
            public IList<string> IsTransactionRefunded { get; set; }
        }

        private class TransactionsExpectedTestData
        {
            public decimal AccountValue { get; set; }
            public string AccountNumber { get; set; }
            public string AccountType { get; set; }
            public bool TransactionLimitReached { get; set; }
            public IList<DateTime> Date { get; set; }
            public IList<string> Description { get; set; }
            public IList<decimal> Amount { get; set; }
            public IList<decimal> UnitPrice { get; set; }
            public IList<decimal> Units { get; set; }
            public IList<decimal> UnitBalance { get; set; }
            public IList<bool> IsRefunded { get; set; }
            public IList<decimal> Fees { get; set; }
            public IList<decimal> Net { get; set; }
            public IList<decimal> AccountBalance { get; set; }
            public IList<string> Status { get; set; }
            public IList<string> RefundType { get; set; }
            public int TransactionsCount { get; set; }
        }
        private void CallSuperAccountForTransactionsMock(TransactionsTestData transactionsTestData)
        {
            MockGetAccountsRplResponse(transactionsTestData.AccountValue, transactionsTestData.AccountNumber, transactionsTestData.ProductType);
            MockGetSuperannuationAccountInvestmentsRplResponse();
            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());
            MockGetInvestmentAssetAllocationRplResponse();
            MockGetSuperannuationAccountTransactionsRplResponse(
                transactionsTestData.TransactionDetailCount,
                transactionsTestData.TransactionDate,
                transactionsTestData.TransactionDescription,
                transactionsTestData.TransactionAmount,
                transactionsTestData.TransactionUnitPrice,
                transactionsTestData.TransactionUnits,
                transactionsTestData.TransactionUnitBalance,
                transactionsTestData.PendingFlag,
                transactionsTestData.TransactionFees,
                transactionsTestData.IsTransactionRefunded
            );
        }

        private void CallPensionAccountForTransactionsMock(TransactionsTestData transactionsTestData)
        {
            MockGetAccountsRplResponse(transactionsTestData.AccountValue, transactionsTestData.AccountNumber, transactionsTestData.ProductType);
            MockGetPensionInvestmentsRplResponse();
            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());
            MockGetInvestmentAssetAllocationRplResponse();
            MockGetPensionAccountTransactionsRplResponse(
                transactionsTestData.TransactionDetailCount,
                transactionsTestData.TransactionDate,
                transactionsTestData.TransactionDescription,
                transactionsTestData.TransactionAmount,
                transactionsTestData.TransactionUnitPrice,
                transactionsTestData.TransactionUnits,
                transactionsTestData.TransactionUnitBalance,
                transactionsTestData.PendingFlag,
                transactionsTestData.TransactionFees,
                transactionsTestData.IsTransactionRefunded
            );
        }

        private Dictionary<string, Action<TransactionsTestData>> _callTransactionsMock;
        private void BuildTransactionsMocks()
        {
            _callTransactionsMock = new Dictionary<string, Action<TransactionsTestData>>()
            {
                { SuperFund, CallSuperAccountForTransactionsMock },
                { PensionFund, CallPensionAccountForTransactionsMock }
            };
        }

        Dictionary<string, Action<TransactionsExpectedTestData, AccountTransactionsDto>> _transactionsValidation;
        private void BuildTransactionsResponse()
        {
            _transactionsValidation = new Dictionary<string, Action<TransactionsExpectedTestData, AccountTransactionsDto>>
            {
                { SuperFund, ValidateTransactionsData },
                { PensionFund, ValidateTransactionsData}
            };
        }

        private void ValidateTransactionsData(TransactionsExpectedTestData expectedData, AccountTransactionsDto accountTransactions)
        {
            accountTransactions.Transactions.Count().Should().Be(expectedData.TransactionsCount);
            accountTransactions.AccountNumber.Should().Be(expectedData.AccountNumber);
            accountTransactions.AccountType.Should().Be(expectedData.AccountType);
            accountTransactions.TransactionLimitReached.Should().Be(expectedData.TransactionLimitReached);
            var transactionsDto = accountTransactions.Transactions.ToList();

            for (var i = 0; i < expectedData.TransactionsCount; i++)
            {
                transactionsDto[i].AccountBalance.Should().Be(expectedData.AccountBalance[i]);
                transactionsDto[i].Amount.Should().Be(expectedData.Amount[i]);
                transactionsDto[i].Date?.ToString(DATE_COMPARISON_FORMAT).Should()
                        .Be(expectedData.Date[i].ToString(DATE_COMPARISON_FORMAT));
                transactionsDto[i].Description.Should().Be(expectedData.Description[i]);
                transactionsDto[i].Fees.Should().Be(expectedData.Fees[i]);
                transactionsDto[i].IsRefunded.Should().Be(expectedData.IsRefunded[i]);
                transactionsDto[i].Net.Should().Be(expectedData.Net[i]);
                transactionsDto[i].RefundType.Should().Be(expectedData.RefundType[i]);
                transactionsDto[i].Status.Should().Be(expectedData.Status[i]);
                transactionsDto[i].UnitBalance.Should().Be(expectedData.UnitBalance[i]);
                transactionsDto[i].UnitPrice.Should().Be(expectedData.UnitPrice[i]);
                transactionsDto[i].Units.Should().Be(expectedData.Units[i]);
            }
        }

        private void MockGetSuperannuationAccountTransactionsRplResponse(
            long transactionDetailCount,
            IList<long> transactionDate,
            IList<string> transactionDescription,
            IList<decimal> transactionAmount,
            IList<decimal> transactionUnitPrice,
            IList<decimal> transactionUnits,
            IList<decimal> transactionUnitBalance,
            IList<string> pendingFlag,
            IList<decimal> transactionFees,
            IList<string> isTransactionRefunded)
        {
            var rplResponse = MyFixture.Build<SuperannuationAccountTransactionsRplResponse>()
                .With(p => p.TransactionDetailCount, transactionDetailCount)
                .With(p => p.TransactionDate, transactionDate)
                .With(p => p.TransactionDescription, transactionDescription)
                .With(p => p.TransactionAmount, transactionAmount)
                .With(p => p.TransactionUnitPrice, transactionUnitPrice)
                .With(p => p.TransactionUnits, transactionUnits)
                .With(p => p.TransactionUnitBalance, transactionUnitBalance)
                .With(p => p.PendingFlag, pendingFlag)
                .With(p => p.TransactionFees, transactionFees)
                .With(p => p.IsTransactionRefunded, isTransactionRefunded)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRATSFC", rplResponse);
        }

        private void MockGetPensionAccountTransactionsRplResponse(
            long transactionDetailCount,
            IList<long> transactionDate,
            IList<string> transactionDescription,
            IList<decimal> transactionAmount,
            IList<decimal> transactionUnitPrice,
            IList<decimal> transactionUnits,
            IList<decimal> transactionUnitBalance,
            IList<string> pendingFlag,
            IList<decimal> transactionFees,
            IList<string> isTransactionRefunded)
        {
            var rplResponse = MyFixture.Build<PensionAccountTransactionsRplResponse>()
                .With(p => p.TransactionDetailCount, transactionDetailCount)
                .With(p => p.TransactionDate, transactionDate)
                .With(p => p.TransactionDescription, transactionDescription)
                .With(p => p.TransactionAmount, transactionAmount)
                .With(p => p.TransactionUnitPrice, transactionUnitPrice)
                .With(p => p.TransactionUnits, transactionUnits)
                .With(p => p.TransactionUnitBalance, transactionUnitBalance)
                .With(p => p.IsTransactionPending, pendingFlag)
                .With(p => p.TransactionFees, transactionFees)
                .With(p => p.IsTransactionRefunded, isTransactionRefunded)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRATPPC", rplResponse);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_Transactions_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetTransactions(
            decimal accountValue,
            int accountNumber,
            string productType,
            int transactionDetailCount,
            string transactionDates,
            string transactionDescriptions,
            string transactionAmounts,
            string transactionUnitPrices,
            string transactionUnits,
            string transactionUnitBalances,
            string pendingFlags,
            string transactionFees,
            string isTransactionRefunded,
            decimal expectedAccountValue,
            int expectedAccountNumber,
            string expectedAccountType,
            bool expectedTransactionLimitReached,
            string expectedDates,
            string expectedDescriptions,
            string expectedAmounts,
            string expectedUnitPrices,
            string expectedUnits,
            string expectedUnitBalances,
            string expectedIsRefunded,
            string expectedFees,
            string expectedNets,
            string expectedAccountBalance,
            string expectedStatus,
            string expectedRefundType,
            int expectedTransactionsCounts
        )
        {
            // Arrange
            var testData = new TransactionsTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                TransactionDetailCount = transactionDetailCount,
                TransactionDate = transactionDates.Split(",").Select(long.Parse).ToList(),
                TransactionDescription = transactionDescriptions.Split(",").ToList(),
                TransactionAmount = transactionAmounts.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnitPrice = transactionUnitPrices.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnits = transactionUnits.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnitBalance = transactionUnitBalances.Split(",").Select(decimal.Parse).ToList(),
                PendingFlag = pendingFlags.Split(",").ToList(),
                TransactionFees = transactionFees.Split(",").Select(decimal.Parse).ToList(),
                IsTransactionRefunded = isTransactionRefunded.Split(",").ToList()
            };

            var expectedTestData = new TransactionsExpectedTestData
            {
                AccountValue = expectedAccountValue,
                AccountNumber = expectedAccountNumber.ToString(),
                AccountType = expectedAccountType,
                TransactionLimitReached = expectedTransactionLimitReached,
                Date = expectedDates.Split(",").Select(DateTime.Parse).ToList(),
                Description = expectedDescriptions.Split(","),
                Amount = expectedAmounts.Split(",").Select(decimal.Parse).ToList(),
                UnitPrice = expectedUnitPrices.Split(",").Select(decimal.Parse).ToList(),
                Units = expectedUnits.Split(",").Select(decimal.Parse).ToList(),
                UnitBalance = expectedUnitBalances.Split(",").Select(decimal.Parse).ToList(),
                IsRefunded = expectedIsRefunded.Split(",").Select(bool.Parse).ToList(),
                Fees = expectedFees.Split(",").Select(decimal.Parse).ToList(),
                Net = expectedNets.Split(",").Select(decimal.Parse).ToList(),
                AccountBalance = expectedAccountBalance.Split(",").Select(decimal.Parse).ToList(),
                Status = expectedStatus.Split(","),
                RefundType = expectedRefundType.Split(","),
                TransactionsCount = expectedTransactionsCounts
            };

            //Calling product type
            _callTransactionsMock[productType](testData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/transactions?customerNumber=12345").GetAsync();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var accountTransactions = JsonConvert.DeserializeObject<AccountTransactionsDto>(jsonResponse);

            //Test Validation
            _transactionsValidation[productType](expectedTestData, accountTransactions);
        }
    }
}
