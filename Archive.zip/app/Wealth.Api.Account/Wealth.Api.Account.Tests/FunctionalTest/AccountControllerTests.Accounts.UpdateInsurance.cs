﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.JsonPatch;
using Newtonsoft.Json;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Infrastructure;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Iesf;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Iued;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Iusf;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests
    {
        class UpdateInsuranceTestData
        {
            public decimal AccountValue { get; set; }
            public string ProductType { get; set; }
            public string ProductAbbreviation { get; set; }
            public int AccountNumber { get; set; }
            public bool? IisSmoker { get; set; }
            public DateTime IelectionDate { get; set; }
        }

        private Dictionary<string, Action<UpdateInsuranceTestData>> callUpdateInsuranceMock;
        private void BuildUpdateInsuranceMocks()
        {
            callUpdateInsuranceMock = new Dictionary<string, Action<UpdateInsuranceTestData>>
            {
                { SuperFund, CallSuperAccountForUpdateInsuranceMock },
                { PensionFund, CallPensionAccountForUpdateInsuranceMock }
            };
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Update_Insurance_TestData.xlsx")]
        private async void ShouldHandleInsuranceUpdateCorrectly(

            decimal accountValue,
            string productType,
            string IisSmoker,
            string IelectionDate,
            string IproductAbbreviation,
            string UisSmoker,
            string UelectionDate,
            int httpStatusCode)
        {
            // Arrange
            int accountNumber = MyFixture.Create<int>();

            var myTestData = new UpdateInsuranceTestData()
            {
                AccountValue = accountValue,
                ProductType = productType,
                ProductAbbreviation = IproductAbbreviation,
                AccountNumber = accountNumber,
                IisSmoker = StringToNullableBool(IisSmoker),
                IelectionDate = string.IsNullOrEmpty(IelectionDate) ? DateTime.MinValue : DateTime.Parse(IelectionDate)
            };

            var patchDocument = new JsonPatchDocument<InsuranceDto>();
            if (StringToNullableBool(UisSmoker) != null)
            {
                patchDocument.Replace(i => i.IsSmoker, StringToNullableBool(UisSmoker));
            }

            if (UelectionDate.Equals("Today"))
            {
                patchDocument.Replace(i => i.InsuranceElectionDate, DateTime.Today);
            }
            else if (!string.IsNullOrEmpty(UelectionDate))
            {
                patchDocument.Replace(i => i.InsuranceElectionDate, DateTime.Parse(UelectionDate));
            }

            var patchJson = JsonConvert.SerializeObject(patchDocument);

            //Calling product type
            callUpdateInsuranceMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/insurance?customerNumber=12345")
                .And(h => { h.Content = new StringContent(patchJson, Encoding.UTF8, "application/json-patch+json"); })
                .SendAsync("PATCH");
            // Assert
            response.StatusCode.Should().Be(httpStatusCode);
        }
        [Theory]
        [ExcelData("FunctionalTest\\Zero_Dollar_Account_Update_Insurance_TestData.xlsx")]
        private async void ShouldHandleResponseForZerDollarAccountInsuranceUpdate(
            decimal accountValue,
            string productType,
            string IisSmoker,
            string IelectionDate,
            string IproductAbbreviation,
            string UisSmoker,
            string UelectionDate,
            int httpStatusCode)
        {
            // Arrange
            int accountNumber = MyFixture.Create<int>();

            var myTestData = new UpdateInsuranceTestData()
            {
                AccountValue = accountValue,
                ProductType = productType,
                ProductAbbreviation = IproductAbbreviation,
                AccountNumber = accountNumber,
                IisSmoker = StringToNullableBool(IisSmoker),
                IelectionDate = string.IsNullOrEmpty(IelectionDate) ? DateTime.MinValue : DateTime.Parse(IelectionDate)
            };

            var patchDocument = new JsonPatchDocument<InsuranceDto>();
            if (StringToNullableBool(UisSmoker) != null)
            {
                patchDocument.Replace(i => i.IsSmoker, StringToNullableBool(UisSmoker));
            }

            if (UelectionDate.Equals("Today"))
            {
                patchDocument.Replace(i => i.InsuranceElectionDate, DateTime.Today);
            }
            else if (!string.IsNullOrEmpty(UelectionDate))
            {
                patchDocument.Replace(i => i.InsuranceElectionDate, DateTime.Parse(UelectionDate));
            }

            var patchJson = JsonConvert.SerializeObject(patchDocument);

            //Calling product type
            callUpdateInsuranceMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/insurance?customerNumber=12345")
                .And(h => { h.Content = new StringContent(patchJson, Encoding.UTF8, "application/json-patch+json"); })
                .SendAsync("PATCH");
            // Assert
            response.StatusCode.Should().Be(httpStatusCode);
        }

        private void CallSuperAccountForUpdateInsuranceMock(UpdateInsuranceTestData testData)
        {
            MockGetAccountsRplResponse(testData.AccountValue,
                testData.AccountNumber, testData.ProductType, "02", false, testData.ProductAbbreviation);
            MockGetSuperannuationAccountInvestmentsRplResponse();
            MockGetInvestmentAssetAllocationRplResponse();
            MockGetAccountInsuranceRplResponse(testData.IelectionDate, testData.IisSmoker);

            MockUpdateInsuranceElectionRplResponse();
            MockUpdateSmokerStatusRplResponse();
        }

        private void CallPensionAccountForUpdateInsuranceMock(UpdateInsuranceTestData testData)
        {
            MockGetAccountsRplResponse(testData.AccountValue,
                testData.AccountNumber, testData.ProductType, "02", false, testData.ProductAbbreviation);
            MockGetPensionInvestmentsRplResponse();
            MockGetInvestmentAssetAllocationRplResponse();
            MockGetAccountInsuranceRplResponse(testData.IelectionDate, testData.IisSmoker);

            MockUpdateInsuranceElectionRplResponse();
            MockUpdateSmokerStatusRplResponse();
        }

        private void MockUpdateInsuranceElectionRplResponse()
        {
            var rplResponse = MyFixture.Build<UpdateInsuranceElectionRplResponse>()
                .With(i => i.ElectInDate)
                .With(i => i.ElectInMethod)
                .With(i => i.ElectInMethodDescription)
                .With(i => i.ExecutionDate)
                .With(i => i.ExecutionTime)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();
            MockRplResponse("FIRIUEDA", rplResponse);
        }

        private void MockUpdateSmokerStatusRplResponse()
        {
            var rplResponse = MyFixture.Build<UpdateSmokerStatusRplResponse>()
                .With(i => i.ExecutionDate)
                .With(i => i.ExecutionTime)
                .With(i => i.ResponseCode)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();
            MockRplResponse("FIRIUSFA", rplResponse);
        }

        private void MockGetAccountInsuranceRplResponse(DateTime IinsuranceElectionDate, bool? IisSmoker)
        {
            var rplResponse = MyFixture.Build<GetAccountInsuranceRplResponse>()
            .With(p => p.BindingNominationDetailCount, 0)
            .With(p => p.EmployerSelectedDeathAmount)
            .With(p => p.EmployerSelectedDeathPremium)
            .With(p => p.EmployerSelectedSciAmount)
            .With(p => p.EmployerSelectedSciPremium)
            .With(p => p.EmployerSelectedTpdAmount)
            .With(p => p.EmployerSelectedTpdPremium)
            .With(p => p.InvestorSelectedDeathAmount)
            .With(p => p.InvestorSelectedDeathPremium)
            .With(p => p.InvestorSelectedSciAmount)
            .With(p => p.InvestorSelectedSciPremium)
            .With(p => p.InvestorSelectedTpdAmount)
            .With(p => p.InvestorSelectedTpdPremium)
            .With(p => p.MaximumBenefitPeriod)
            .With(p => p.WaitingPeriod)
            .With(p => p.TotalDeathCoverAmount)
            .With(p => p.TotalSciCoverAmount)
            .With(p => p.TotalTpdCoverAmount)
            .With(p => p.TotalSciPremium)
            .With(p => p.InsuranceElectionDate, FmsType.ToDecimalDate(IinsuranceElectionDate))
            .With(p => p.OccupationDescription)
            .With(p => p.IsSmoker, FmsType.ToFmsBoolean(IisSmoker))
            .With(p => p.MessageIndicator, 0)
            .Without(p => p.MessageType)
            .Without(p => p.Messages)
            .Create();

            MockRplResponse("FIRIESFJ", rplResponse);
        }
    }
}
