﻿using FluentResults;
using System.Threading;
using System.Threading.Tasks;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public interface IPensionPaymentRepository
    {
        Task<Result<PensionPayment>> GetPensionPaymentDetails(GetPensionPaymentDetailsRequest request,
            CancellationToken cancellationToken = default(CancellationToken));

        Task<Result<PensionPaymentUpdate>> UpdatePensionPaymentDetails(UpdatePensionPaymentDetailsRequest request,
            CancellationToken cancellationToken = default(CancellationToken));
    }
}
