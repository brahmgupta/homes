﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class PensionPayment : Entity<string>
    {
        public PensionPayment(string accountFeeOption, string allocatedPensionAccountFlag, string pensionType, string preRetirementIndicator, string firstPaymentDateChangeFlag,
            string paymentFrequency, string paymentFrequencyDescription, DateTime? lastPaymentDate, decimal lastPaymentAmount, DateTime? nextPaymentDate, decimal nextPaymentAmount,
            string annualPensionRequested, decimal minAmountPercentage, decimal maxAmountPercentage, decimal term, decimal grossAnnualAmount, decimal grossPerPaymentAmount,
            DateTime? nextAllowedMonthlyPaymentDate, decimal grossAnnualAllowed, DateTime? lastFundValDate, string increasedByCPI, decimal cPIRate, string proRataEditable,
            string proRata, string incomeVariationType, decimal grossSpecifiedAnnualAmount, decimal incomeVariancePercentage, string newComponent, string annualPaymentFinancialYear,
            decimal paymentRequired, decimal yearToDatePaid, decimal remainingPayment, decimal deductibleAllowed, decimal deductibleYearToDatePaid, decimal rebatePreDays,
            decimal rebatePostDays, decimal feePaymentAmount, int pensionPaymentDetailCount, IEnumerable<PensionPaymentDetail> pensionPaymentDetails, string pensionPaymentBankBSBNumber,
            string pensionPaymentBankShortName, string pensionPaymentBankName, IEnumerable<PensionPaymentBankAddressDetail> pensionPaymentBankAddressDetails, string pensionPaymentBankAccountNumber,
            string pensionPaymentBankAccountName, int pensionScheduleDetailCount, IEnumerable<PensionScheduleDetail> pensionScheduleDetails, string pensionPaymentScheduleWarning,
            string managedAccountFlag, string pensionDrawdownAutoAlign, IEnumerable<string> messages, IEnumerable<string> messageTypes)
        {
            AccountFeeOption = accountFeeOption;
            AllocatedPensionAccountFlag = allocatedPensionAccountFlag;
            PensionType = pensionType;
            PreRetirementIndicator = preRetirementIndicator;
            FirstPaymentDateChangeFlag = firstPaymentDateChangeFlag;
            PaymentFrequency = paymentFrequency;
            PaymentFrequencyDescription = paymentFrequencyDescription;
            LastPaymentDate = lastPaymentDate;
            LastPaymentAmount = lastPaymentAmount;
            NextPaymentDate = nextPaymentDate;
            NextPaymentAmount = nextPaymentAmount;
            AnnualPensionRequested = annualPensionRequested;
            MinAmountPercentage = minAmountPercentage;
            MaxAmountPercentage = maxAmountPercentage;
            Term = term;
            GrossAnnualAmount = grossAnnualAmount;
            GrossPerPaymentAmount = grossPerPaymentAmount;
            NextAllowedMonthlyPaymentDate = nextAllowedMonthlyPaymentDate;
            GrossAnnualAllowed = grossAnnualAllowed;
            LastFundValDate = lastFundValDate;
            IncreasedByCPI = increasedByCPI;
            CPIRate = cPIRate;
            ProRataEditable = proRataEditable;
            ProRata = proRata;
            IncomeVariationType = incomeVariationType;
            GrossSpecifiedAnnualAmount = grossSpecifiedAnnualAmount;
            IncomeVariancePercentage = incomeVariancePercentage;
            NewComponent = newComponent;
            AnnualPaymentFinancialYear = annualPaymentFinancialYear;
            PaymentRequired = paymentRequired;
            YearToDatePaid = yearToDatePaid;
            RemainingPayment = remainingPayment;
            DeductibleAllowed = deductibleAllowed;
            DeductibleYearToDatePaid = deductibleYearToDatePaid;
            RebatePreDays = rebatePreDays;
            RebatePostDays = rebatePostDays;
            FeePaymentAmount = feePaymentAmount;
            PensionPaymentDetailCount = pensionPaymentDetailCount;
            PensionPaymentDetails = pensionPaymentDetails;
            PensionPaymentBankBSBNumber = pensionPaymentBankBSBNumber;
            PensionPaymentBankShortName = pensionPaymentBankShortName;
            PensionPaymentBankName = pensionPaymentBankName;
            PensionPaymentBankAddressDetails = pensionPaymentBankAddressDetails;
            PensionPaymentBankAccountNumber = pensionPaymentBankAccountNumber;
            PensionPaymentBankAccountName = pensionPaymentBankAccountName;
            PensionScheduleDetailCount = pensionScheduleDetailCount;
            PensionScheduleDetails = pensionScheduleDetails;
            PensionPaymentScheduleWarning = pensionPaymentScheduleWarning;
            ManagedAccountFlag = managedAccountFlag;
            PensionDrawdownAutoAlign = pensionDrawdownAutoAlign;
            Messages = messages;
            MessageTypes = messageTypes;
        }

        public string AccountFeeOption { get; }

        public string AllocatedPensionAccountFlag { get; }

        public string PensionType { get;  }

        public string PreRetirementIndicator { get;  }

        public string FirstPaymentDateChangeFlag { get;  }

        public string PaymentFrequency { get;  }

        public string PaymentFrequencyDescription { get;  }

        public DateTime? LastPaymentDate { get;  }

        public decimal LastPaymentAmount { get;  }

        public DateTime? NextPaymentDate { get;  }

        public decimal NextPaymentAmount { get;  }

        public string AnnualPensionRequested { get;  }

        public decimal MinAmountPercentage { get;  }

        public decimal MaxAmountPercentage { get;  }

        public decimal Term { get;  }

        public decimal GrossAnnualAmount { get;  }

        public decimal GrossPerPaymentAmount { get;  }

        public DateTime? NextAllowedMonthlyPaymentDate { get;  }

        public decimal GrossAnnualAllowed { get;  }

        public DateTime? LastFundValDate { get;  }

        public string IncreasedByCPI { get;  }

        public decimal CPIRate { get;  }

        public string ProRataEditable { get;  }

        public string ProRata { get;  }

        public string IncomeVariationType { get;  }

        public decimal GrossSpecifiedAnnualAmount { get;  }

        public decimal IncomeVariancePercentage { get;  }

        public string NewComponent { get;  }

        public string AnnualPaymentFinancialYear { get;  }

        public decimal PaymentRequired { get;  }

        public decimal YearToDatePaid { get;  }

        public decimal RemainingPayment { get;  }

        public decimal DeductibleAllowed { get;  }

        public decimal DeductibleYearToDatePaid { get;  }

        public decimal RebatePreDays { get;  }

        public decimal RebatePostDays { get;  }

        public decimal FeePaymentAmount { get;  }

        public int PensionPaymentDetailCount { get;  }

        public IEnumerable<PensionPaymentDetail> PensionPaymentDetails { get;  }

        public string PensionPaymentBankBSBNumber { get;  }

        public string PensionPaymentBankShortName { get;  }

        public string PensionPaymentBankName { get;  }

        public IEnumerable<PensionPaymentBankAddressDetail> PensionPaymentBankAddressDetails { get;  }

        public string PensionPaymentBankAccountNumber { get;  }

        public string PensionPaymentBankAccountName { get;  }

        public int PensionScheduleDetailCount { get;  }

        public IEnumerable<PensionScheduleDetail> PensionScheduleDetails { get;  }

        public string PensionPaymentScheduleWarning { get;  }

        public string ManagedAccountFlag { get;  }

        public string PensionDrawdownAutoAlign { get;  }

        public IEnumerable<string> Messages { get; }

        public IEnumerable<string> MessageTypes { get; }

        public bool HasError { get; }
    }   
}