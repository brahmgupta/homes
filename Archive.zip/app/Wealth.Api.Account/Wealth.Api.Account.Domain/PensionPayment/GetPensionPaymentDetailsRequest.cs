﻿using Wealth.Api.Account.Domain.AccountAggregate;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class GetPensionPaymentDetailsRequest : RequestContext
    {
        public string AccountNumber { get; set; }        
    }
}
