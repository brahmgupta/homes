﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class Transaction : ValueObject
    {
        public Transaction(DateTime? date, string description, decimal amount, decimal accountBalance,
            TransactionStatus status, decimal unitPrice = 0, decimal units = 0, decimal unitBalance = 0,
            bool isRefunded = false, decimal fees = 0, decimal net = 0, int count = 0, TransactionRefundType? refundType = null)
        {
            Date = date;
            Description = description;
            Amount = amount;
            UnitPrice = unitPrice;
            Units = units;
            UnitBalance = unitBalance;
            IsRefunded = isRefunded;
            Fees = fees;
            Net = net;
            AccountBalance = accountBalance;
            RefundType = refundType;
            Count = count;
            Status = status;
        }

        public DateTime? Date { get; }

        public string Description { get; }

        public decimal Amount { get; }

        public decimal UnitPrice { get; }

        public decimal Units { get; }

        public decimal UnitBalance { get; }

        public bool IsRefunded { get; }

        public TransactionRefundType? RefundType { get; }

        public decimal Fees { get; }

        public decimal Net { get; }

        public decimal AccountBalance { get; }

        public int Count { get; }

        public TransactionStatus Status { get; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Date;
            yield return Description;
            yield return Amount;
            yield return UnitPrice;
            yield return Units;
            yield return UnitBalance;
            yield return IsRefunded;
            yield return RefundType;
            yield return Fees;
            yield return Net;
            yield return AccountBalance;
            yield return Status;
        }
    }
}
