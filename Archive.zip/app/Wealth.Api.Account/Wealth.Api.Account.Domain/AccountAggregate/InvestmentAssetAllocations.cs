﻿using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class InvestmentAssetAllocations : DomainCollection<InvestmentAssetAllocation>
    {
        public InvestmentAssetAllocations()
        {
        }

        public InvestmentAssetAllocations(IEnumerable<InvestmentAssetAllocation> investmentAssetAllocations) : base(investmentAssetAllocations)
        {
        }

        internal override bool SetItem(InvestmentAssetAllocation investmentAssetAllocation)
        {
            if (investmentAssetAllocation == null)
            {
                return false;
            }

            Items.AddOrReplace(item => item.Equals(investmentAssetAllocation), investmentAssetAllocation);

            return true;
        }
    }
}
