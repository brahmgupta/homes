﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class GetAccountsRequest : RequestContext
    {
        public AccountStatus AccountStatus { get; set; }
        public bool IsAccountDetailsNeeded { get; set; }
    }
}