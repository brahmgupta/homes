﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class UpdateInsuranceRequest: RequestContext
    {
        public AccountDetails Account { get; set; }
    }
}
