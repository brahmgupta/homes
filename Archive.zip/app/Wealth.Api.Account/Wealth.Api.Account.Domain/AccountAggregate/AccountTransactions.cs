﻿using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class AccountTransactions : Entity<string>, IAggregateRoot
    {
        public AccountTransactions(string accountNumber, AccountType accountType, bool transactionLimitReached, IEnumerable<Transaction> transactions)
        {
            Id = accountNumber;
            AccountType = accountType;
            TransactionLimitReached = transactionLimitReached;
            Transactions = new Transactions(transactions);
        }

        public bool TransactionLimitReached { get; }
        public string AccountNumber => Id;
        public AccountType AccountType { get; }
        public Transactions Transactions { get; }
    }
}