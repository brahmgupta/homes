using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class Beneficiary : ValueObject
    {
        public Beneficiary(BeneficiaryType type, string description, string name, DateTime? dob, string relationship,
            decimal? percentage)
        {
            Type = type;
            Description = description;
            Name = name;
            Dob = dob;
            Relationship = relationship;
            Percentage = percentage;
        }

        public BeneficiaryType Type { get; }

        public string Description { get; }

        public string Name { get; }

        public DateTime? Dob { get; }

        public string Relationship { get; }

        public decimal? Percentage { get; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Type;
            yield return Dob;
            yield return Relationship;
            yield return Percentage;
        }
    }
}