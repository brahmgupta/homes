﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class RequestContext
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}