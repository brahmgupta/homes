﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public enum BeneficiaryType
    {
        Unknown,
        NonLapsing,
        Reversionary,
        Nominated,
        AnnuityNominated,
        AnnuitySubsequent,
        AnnuityReversionary,
        AnnuityReversionaryLifeInsured,
        Expired
    }
}
