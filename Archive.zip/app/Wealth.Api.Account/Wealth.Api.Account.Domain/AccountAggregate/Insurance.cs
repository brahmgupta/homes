﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class Insurance : ValueObject
    {
        public Insurance(decimal totalDeathCoverAmount, decimal employerSelectedDeathCoverPremium,
            decimal investorSelectedDeathCoverPremium, decimal totalTpdCoverAmount,
            decimal employerSelectedTpdCoverPremium, decimal investorSelectedTpdCoverPremium,
            decimal totalSciCoverAmount, decimal totalSciCoverPremium, decimal waitingPeriod,
            decimal maximumBenefitPeriod, decimal employerSelectedDeathAmount, decimal investorSelectedDeathAmount,
            decimal employerSelectedTpdAmount, decimal investorSelectedTpdAmount, decimal employerSelectedSciAmount,
            decimal investorSelectedSciAmount, decimal employerSelectedSciPremium, decimal investorSelectedSciPremium,
            DateTime? insuranceElectionDate, string occupationDescription, bool? isSmoker)
        {
            EmployerSelectedDeathCoverAmount = employerSelectedDeathAmount;
            InvestorSelectedDeathCoverAmount = investorSelectedDeathAmount;
            TotalDeathCoverAmount = totalDeathCoverAmount;
            EmployerSelectedDeathCoverPremium = employerSelectedDeathCoverPremium;
            InvestorSelectedDeathCoverPremium = investorSelectedDeathCoverPremium;
            TotalDeathCoverPremium = employerSelectedDeathCoverPremium + investorSelectedDeathCoverPremium;
            EmployerSelectedTpdCoverAmount = employerSelectedTpdAmount;
            InvestorSelectedTpdCoverAmount = investorSelectedTpdAmount;
            TotalTpdCoverAmount = totalTpdCoverAmount;
            EmployerSelectedTpdCoverPremium = employerSelectedTpdCoverPremium;
            InvestorSelectedTpdCoverPremium = investorSelectedTpdCoverPremium;
            TotalTpdCoverPremium = employerSelectedTpdCoverPremium + investorSelectedTpdCoverPremium;
            EmployerSelectedSciCoverAmount = employerSelectedSciAmount;
            InvestorSelectedSciCoverAmount = investorSelectedSciAmount;
            TotalSciCoverAmount = totalSciCoverAmount;
            EmployerSelectedSciCoverPremium = employerSelectedSciPremium;
            InvestorSelectedSciCoverPremium = investorSelectedSciPremium;
            TotalSciCoverPremium = totalSciCoverPremium;
            WaitingPeriod = waitingPeriod;
            MaximumBenefitPeriod = maximumBenefitPeriod;
            InsuranceElectionDate = insuranceElectionDate;
            OccupationClassification = occupationDescription;
            IsSmoker = isSmoker;
        }

        public decimal TotalDeathCoverAmount { get; }
        public decimal EmployerSelectedDeathCoverPremium { get; }
        public decimal InvestorSelectedDeathCoverPremium { get; }
        public decimal TotalTpdCoverAmount { get; }
        public decimal EmployerSelectedTpdCoverPremium { get; }
        public decimal InvestorSelectedTpdCoverPremium { get; }
        public decimal TotalSciCoverAmount { get; }
        public decimal TotalSciCoverPremium { get; }
        public decimal WaitingPeriod { get; }
        public decimal MaximumBenefitPeriod { get; }
        public decimal EmployerSelectedDeathCoverAmount { get; }
        public decimal InvestorSelectedDeathCoverAmount { get; }
        public decimal TotalDeathCoverPremium { get; }
        public decimal EmployerSelectedTpdCoverAmount { get; }
        public decimal InvestorSelectedTpdCoverAmount { get; }
        public decimal TotalTpdCoverPremium { get; }
        public decimal EmployerSelectedSciCoverAmount { get; }
        public decimal InvestorSelectedSciCoverAmount { get; }
        public decimal EmployerSelectedSciCoverPremium { get; }
        public decimal InvestorSelectedSciCoverPremium { get; }
        public DateTime? InsuranceElectionDate { get; private set; }
        public string OccupationClassification { get; }
        public bool? IsSmoker { get; private set; }
        public bool IsInsuranceElectionModified { get; internal set; }
        public bool IsSmokerStatusModified { get; internal set; }
        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return TotalDeathCoverAmount;
            yield return EmployerSelectedDeathCoverPremium;
            yield return InvestorSelectedDeathCoverPremium;
            yield return TotalTpdCoverAmount;
            yield return EmployerSelectedTpdCoverPremium;
            yield return InvestorSelectedTpdCoverPremium;
            yield return TotalSciCoverAmount;
            yield return TotalSciCoverPremium;
            yield return WaitingPeriod;
            yield return MaximumBenefitPeriod;
            yield return EmployerSelectedDeathCoverAmount;
            yield return InvestorSelectedDeathCoverAmount;
            yield return TotalDeathCoverPremium;
            yield return EmployerSelectedTpdCoverAmount;
            yield return InvestorSelectedTpdCoverAmount;
            yield return TotalTpdCoverPremium;
            yield return EmployerSelectedSciCoverAmount;
            yield return InvestorSelectedSciCoverAmount;
            yield return EmployerSelectedSciCoverPremium;
            yield return InvestorSelectedSciCoverPremium;
            yield return InsuranceElectionDate;
            yield return OccupationClassification;
            yield return IsSmoker;

        }
    }
}
