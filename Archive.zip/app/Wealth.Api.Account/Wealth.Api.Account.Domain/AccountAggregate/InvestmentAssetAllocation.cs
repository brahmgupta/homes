﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class InvestmentAssetAllocation
    {
        public InvestmentAssetAllocation(string className, decimal percentage, decimal value)
        {
            ClassName = className;
            Percentage = percentage;
            Value = value;
        }

        public string ClassName { get; }
        public decimal Percentage { get; }
        public decimal Value { get; }
    }
}
