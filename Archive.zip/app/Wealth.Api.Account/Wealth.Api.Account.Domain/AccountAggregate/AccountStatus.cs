﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public enum AccountStatus
    {
        Open = 0,
        Pending = 1,
        Closed = 2,
    }
}