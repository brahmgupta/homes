﻿using System;

namespace Wealth.Api.Account.Domain.SeedWork
{
    /// <inheritdoc />
    /// <summary>
    ///     When applied to a parameter,
    ///     this attribute provides an indication to code analysis that the argument has been null checked.
    /// </summary>
    [AttributeUsage(AttributeTargets.Parameter)]
    internal sealed class ValidatedNotNullAttribute : Attribute
    {
    }

    internal static class Guard
    {
        public static void AgainstNullOrEmptyArgument(string parameterName, [ValidatedNotNull] string argument)
        {
            if (string.IsNullOrWhiteSpace(argument)) throw new ArgumentException($"{parameterName} is null or empty.");
        }

        public static void AgainstNullArgument(string parameterName, [ValidatedNotNull] object argument)
        {
            if (argument == null) throw new ArgumentException($"{parameterName} is null.");
        }
    }
}