﻿using System;

namespace Wealth.Api.Account.Domain.SeedWork
{
    public interface IModifiableEntity
    {
        string Name { get; set; }
        bool IsModified { get; }
    }

    public interface IEntity : IModifiableEntity
    {
        object Id { get; }
        DateTime CreatedDate { get; set; }
        DateTime? ModifiedDate { get; set; }
        string CreatedBy { get; set; }
        string ModifiedBy { get; set; }
        byte[] Version { get; set; }
    }

    public interface IEntity<T> : IEntity
    {
        new T Id { get; set; }
    }

    public abstract class Entity<T> : IEntity<T>
    {
        private DateTime? _createdDate;

        public T Id { get; set; }
        object IEntity.Id => Id;

        public string Name { get; set; }

        public bool IsModified { get; private set; }

        public DateTime CreatedDate
        {
            get => _createdDate ?? DateTime.UtcNow;
            set => _createdDate = value;
        }

        public DateTime? ModifiedDate { get; set; }

        public string CreatedBy { get; set; }

        public string ModifiedBy { get; set; }

        public byte[] Version { get; set; }

        protected void OnModified()
        {
            IsModified = true;
            ModifiedDate = DateTime.UtcNow;
        }

        protected void OnModified(string modifiedBy)
        {
            OnModified();
            ModifiedBy = modifiedBy;
        }
    }
}