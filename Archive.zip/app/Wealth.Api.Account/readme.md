# Wealth Api Account
---
Contains the .Net Core 2.1 web api template.

## Features 
- Health check
- Hosting model
- Exception handler
- Configuration and secret loading
- Logging (logLevel configuration to be decided later)
- Api Documentation using.Swashbuckle.AspNetCore
- Simple test project sample

