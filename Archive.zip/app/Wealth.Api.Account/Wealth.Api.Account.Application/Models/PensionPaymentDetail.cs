﻿namespace Wealth.Api.Account.Application.Models
{
    public class PensionPaymentDetail
    {
        public int PensionPaymentOptionId { get; set; }

        public string PensionPaymentOptionName { get; set; }

        public decimal PensionPaymentPercentage { get; set; }

        public decimal PensionPaymentSequence { get; set; }

    }
}
