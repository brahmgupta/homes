using System;

namespace Wealth.Api.Account.Application.Models
{
    public class BeneficiaryDto
    {
        public string Type { get; set; }

        public string Description { get; set; }

        public string Name { get; set; }

        public DateTime? Dob { get; set; }

        public string Relationship { get; set; }

        public decimal? Percentage { get; set; }
    }
}