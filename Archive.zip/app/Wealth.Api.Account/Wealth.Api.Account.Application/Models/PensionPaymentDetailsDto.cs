﻿using System;
using System.Collections.Generic;

namespace Wealth.Api.Account.Application.Models
{
    public class PensionPaymentDetailsDto
    {
        public string AccountFeeOption { get; set; }

        public string AllocatedPensionAccountFlag { get; set; }

        public string PensionType { get; set; }

        public string PreRetirementIndicator { get; set; }

        public string FirstPaymentDateChangeFlag { get; set; }

        public string PaymentFrequency { get; set; }

        public string PaymentFrequencyDescription { get; set; }

        public DateTime LastPaymentDate { get; set; }

        public decimal LastPaymentAmount { get; set; }

        public DateTime NextPaymentDate { get; set; }

        public decimal NextPaymentAmount { get; set; }

        public string AnnualPensionRequested { get; set; }

        public decimal MinAmountPercentage { get; set; }

        public decimal MaxAmountPercentage { get; set; }

        public decimal Term { get; set; }

        public decimal GrossAnnualAmount { get; set; }

        public decimal GrossPerPaymentAmount { get; set; }

        public DateTime NextAllowedMonthlyPaymentDate { get; set; }

        public decimal GrossAnnualAllowed { get; set; }

        public DateTime LastFundValDate { get; set; }

        public string IncreasedByCPI { get; set; }

        public decimal CPIRate { get; set; }

        public string ProRataEditable { get; set; }

        public string ProRata { get; set; }

        public string IncomeVariationType { get; set; }

        public decimal GrossSpecifiedAnnualAmount { get; set; }

        public decimal IncomeVariancePercentage { get; set; }

        public string NewComponent { get; set; }

        public string AnnualPaymentFinancialYear { get; set; }

        public decimal PaymentRequired { get; set; }

        public decimal YearToDatePaid { get; set; }

        public decimal RemainingPayment { get; set; }

        public decimal DeductibleAllowed { get; set; }

        public decimal DeductibleYearToDatePaid { get; set; }

        public decimal RebatePreDays { get; set; }

        public decimal RebatePostDays { get; set; }

        public decimal FeePaymentAmount { get; set; }

        public int PensionPaymentDetailCount { get; set; }

        public IEnumerable<PensionPaymentDetail> PensionPaymentDetails { get; set; }

        public string PensionPaymentBankBSBNumber { get; set; }

        public string PensionPaymentBankShortName { get; set; }

        public string PensionPaymentBankName { get; set; }

        public IEnumerable<PensionPaymentBankAddressDetail> PensionPaymentBankAddressDetails { get; set; }

        public string PensionPaymentBankAccountNumber { get; set; }

        public string PensionPaymentBankAccountName { get; set; }

        public int PensionScheduleDetailCount { get; set; }

        public IEnumerable<PensionScheduleDetail> PensionScheduleDetails { get; set; }

        public string PensionPaymentScheduleWarning { get; set; }

        public string ManagedAccountFlag { get; set; }

        public string PensionDrawdownAutoAlign { get; set; }

        public IEnumerable<string> Messages { get; set; }

        public IEnumerable<string> MessageTypes { get; set; }

        public bool HasError { get; set; }
    }
}
