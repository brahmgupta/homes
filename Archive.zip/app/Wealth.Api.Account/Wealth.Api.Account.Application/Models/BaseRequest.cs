﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Application.Models
{
    public abstract class BaseRequest
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}