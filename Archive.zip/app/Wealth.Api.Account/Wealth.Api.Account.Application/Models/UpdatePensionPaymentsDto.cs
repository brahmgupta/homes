﻿using System;
using System.Collections.Generic;

namespace Wealth.Api.Account.Application.Models
{
    public class UpdatePensionPaymentsDto
    {
        public DateTime? ExecutionDate { get; set; }
        public DateTime? ExecutionTime { get; set; }
        public DateTime? NextPaymentDate { get; set; }
        public decimal NextPaymentAmount { get; set; }
        public decimal GrossAnnualAmount { get; set; }
        public string AnnualPaymentFinancialYear { get; set; }
        public decimal PaymentRequired { get; set; }
        public decimal RemainingPayment { get; set; }
        public decimal NextFinancialYearGrossAmount { get; set; }
        public decimal GrossPerPaymentAmount { get; set; }
        public string PaymentFrequency { get; set; }
        public string IncreasedByCPI { get; set; }
        public decimal CPIRate { get; set; }
        public int PensionScheduleCount { get; set; }
        public IEnumerable<PensionScheduleDetail> PensionScheduleDetails { get; set; }
        public string BankName { get; set; }
        public IEnumerable<PensionPaymentBankAddressDetail> BankAddressDetails { get; set; }
        public IEnumerable<string> Messages { get; set; }
        public IEnumerable<string> MessageTypes { get; set; }
        public bool HasError { get; set; }
    }
}
