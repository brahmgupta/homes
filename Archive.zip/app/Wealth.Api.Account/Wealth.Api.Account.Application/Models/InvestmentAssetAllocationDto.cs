﻿namespace Wealth.Api.Account.Application.Models
{
    public class InvestmentAssetAllocationDto
    {
        public string ClassName { get; set; }
        public decimal Percentage { get; set; }
        public decimal Value { get; set; }
    }
}
