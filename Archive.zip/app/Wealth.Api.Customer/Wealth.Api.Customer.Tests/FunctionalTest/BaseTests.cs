﻿using AutoMapper;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Wealth.Api.Customer.Application.Commands.UpdateCustomer;

namespace Wealth.Api.Customer.Tests.FunctionalTest
{
    public class BaseTests
    {
        protected IMapper Mapper { get; }
        protected TestServer Server { get; }

        protected BaseTests()
        {
            Server = new TestServer(
                WebHost
                    .CreateDefaultBuilder()
                    .ConfigureAppConfiguration((hostingContext, config) =>{})
                    .UseStartup<TestStartup>());
            Mapper = new MapperConfiguration(c =>
                c.AddProfile<UpdateCustomerMappingProfile>()).CreateMapper();

        }
    }
}
