﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Wealth.Api.Customer.Domain.CustomerAggregate;
using Wealth.Api.Customer.Host;

namespace Wealth.Api.Customer.Tests.FunctionalTest
{
    public class TestStartup : Startup
    {
        public TestStartup(IConfiguration configuration)
            : base(configuration)
        {
        }

        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);

            services
                .AddSingleton(x => Substitute.For<ICustomerRepository>())
                .AddSingleton(x => Substitute.For<ILogger>());
        }
    }
}
