using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Wealth.Api.Customer.Application.Commands.UpdateCustomer;
using Wealth.Api.Customer.Application.Models;
using Wealth.Api.Customer.Application.Queries.GetCustomer;
using Wealth.Api.Customer.Host.Infrastructure;
using Wealth.Api.Customer.Host.Infrastructure.Attributes;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Filters;
using Wealth.Toolkit.Response.Models;

namespace Wealth.Api.Customer.Host.Controllers
{
    public class CustomersController : BaseController
    {
        private readonly IMediator _mediator;

        public CustomersController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Route("{customerNumber}")]
        [HttpGet]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber")]
        [ProducesResponseType(typeof(CustomerDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<CustomerDto>> GetCustomer(
            [FromHeader] [Optional] string sessionId,
            [FromHeader] [Optional] string channel,
            [FromRoute] [Required] string customerNumber,
            [FromQuery] [Required] string companyCode,
            CancellationToken cancellationToke)
        {
            var request = new GetCustomerQuery
            {
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber),
            };

            var response = await _mediator.Send(request, cancellationToke);

            return response.ToTypedActionResult<CustomerDto>();
        }

        [Route("{customerNumber}")]
        [HttpPatch]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber")]
        [ProducesResponseType(typeof(UpdateCustomerResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<UpdateCustomerResponse>> UpdateCustomer(
            [FromHeader] [Optional] string sessionId,
            [FromHeader] [Optional] string channel,
            [FromRoute] [Required] string customerNumber,
            [FromHeader] [Required] string companyCode,
            JsonPatchDocument<CustomerDto> customerPatch,
            CancellationToken cancellationToken)
        {
            var updateCustomerCommand = new UpdateCustomerCommand
            {
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber),
                PatchDocument = customerPatch
            };

            var response = await _mediator.Send(updateCustomerCommand, cancellationToken);

            return response.ToTypedActionResult<UpdateCustomerResponse>();
        }
    }
}
