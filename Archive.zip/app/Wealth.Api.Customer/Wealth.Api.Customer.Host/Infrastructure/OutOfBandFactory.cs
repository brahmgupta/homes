﻿using System.Collections.Generic;

namespace Wealth.Api.Customer.Host.Infrastructure
{
    public static class OutOfBandFactory
    {
        public static IDictionary<string, string> Create(
            string sessionId,
            string channel,
            string companyCode,
            string customerNumber
        )
        {
            var outOfBand = new Dictionary<string, string>
            {
                {nameof(companyCode), companyCode},
                {nameof(customerNumber), customerNumber}
            };

            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                outOfBand.Add(nameof(sessionId), sessionId);
            }

            if (!string.IsNullOrWhiteSpace(channel))
            {
                outOfBand.Add(nameof(channel), channel);
            }

            return outOfBand;
        }
    }
}
