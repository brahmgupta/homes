﻿using System.Collections.Generic;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class ContactDetails : ValueObject
    {
        public ContactDetails(string homePhone, string workPhone, string mobile, string fax, string emailAddress)
        {
            EmailAddress = emailAddress;
            Fax = fax;
            HomePhone = homePhone;
            WorkPhone = workPhone;
            Mobile = mobile;
        }

        public string HomePhone { get; }
        public string WorkPhone { get; }
        public string Mobile { get; }
        public string Fax { get; }
        public string EmailAddress { get; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return string.IsNullOrWhiteSpace(HomePhone) ? null : HomePhone.ToLower();
            yield return string.IsNullOrWhiteSpace(WorkPhone) ? null : WorkPhone.ToLower();
            yield return string.IsNullOrWhiteSpace(EmailAddress) ? null : EmailAddress.ToLower();
        }
    }
}