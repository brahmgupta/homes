﻿using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class Accounts : DomainCollection<Account>
    {
        public Accounts()
        {
        }

        public Accounts(IEnumerable<Account> accounts):base(accounts)
        {
        }

        internal override bool SetItem(Account account)
        {
            if (account == null)
            {
                return false;
            }

            var matchedAccount = this.FirstOrDefault(a => a.Id == account.Id);
            if (matchedAccount == null)
            {
                return false;
            }

            var isMailingAddressUpdated = matchedAccount.SetMailingAddress(account.MailingAddress);
            var isCommPrefUpdated = matchedAccount.SetCommunicationPreferences(account.CommunicationPreferences);

            return isMailingAddressUpdated || isCommPrefUpdated;
        }
    }
}