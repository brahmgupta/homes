﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class GetCustomerRequest : RequestContext
    {
    }
}
