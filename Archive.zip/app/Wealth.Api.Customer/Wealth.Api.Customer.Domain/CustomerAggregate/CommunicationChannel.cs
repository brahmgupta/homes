namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public static class CommunicationChannel
    {
        public static string None => "None";
        public static string Email => "Email";
        public static string Mail => "Mail";
    }
}