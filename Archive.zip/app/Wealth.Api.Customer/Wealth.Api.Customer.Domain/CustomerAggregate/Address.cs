﻿using System;
using System.Collections.Generic;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class Address : ValueObject
    {
        public Address(
            string addressLine1,
            string addressLine2,
            string addressLine3,
            string suburb,
            string state,
            string postcode,
            string country
        )
        {
            AddressLine1 = addressLine1;
            AddressLine2 = addressLine2;
            AddressLine3 = addressLine3;
            Country = country;
            Postcode = postcode;
            State = state;
            Suburb = suburb;
        }

        public string AddressLine1 { get; }
        public string AddressLine2 { get; }
        public string AddressLine3 { get; }
        public string Suburb { get; }
        public string State { get; }
        public string Postcode { get; }
        public string Country { get; }
        public bool IsDomestic => !string.IsNullOrWhiteSpace(Country) && string.Equals(Country,
                                      CustomerConstants.AustraliaCountryCode, StringComparison.OrdinalIgnoreCase);

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return string.IsNullOrWhiteSpace(AddressLine1) ? null : AddressLine1.ToLower();
            yield return string.IsNullOrWhiteSpace(AddressLine2) ? null : AddressLine2.ToLower();
            yield return string.IsNullOrWhiteSpace(AddressLine3) ? null : AddressLine3.ToLower();
            yield return string.IsNullOrWhiteSpace(Country) ? null : Country.ToLower();
            yield return string.IsNullOrWhiteSpace(Postcode) ? null : Postcode.ToLower();
            yield return string.IsNullOrWhiteSpace(State) ? null : State.ToLower();
            yield return string.IsNullOrWhiteSpace(Suburb) ? null : Suburb.ToLower();
        }
    }
}