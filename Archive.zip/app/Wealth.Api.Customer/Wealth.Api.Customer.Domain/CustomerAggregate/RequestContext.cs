﻿using System.Collections.Generic;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class RequestContext
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}
