﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public interface ICustomerRepository
    {
        Task<Result<string>> UpdateCustomer(UpdateCustomerRequest customer, CancellationToken cancellationToken = default(CancellationToken));

        Task<Result<CustomerDetails>> GetCustomer(GetCustomerRequest request, CancellationToken cancellationToken = default(CancellationToken));
    }
}