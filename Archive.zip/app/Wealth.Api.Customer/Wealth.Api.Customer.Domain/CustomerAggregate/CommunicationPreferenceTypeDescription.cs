﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class CommunicationPreferenceTypeDescription
    {
        public const string IqMagazine = "Quarterly newsletter";
        public const string PromotionalMaterials = "Communications, education and market updates";
        public const string AnnualReport = "Annual reports";
        public const string StatementsAndConfirmations = "Statements, transaction and other account communications";
    }
}
