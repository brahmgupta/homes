﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public enum AccessMode
    {
        None = 0,
        ReadOnly = 1,
        Full = 2
    }
}
