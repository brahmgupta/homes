﻿namespace Wealth.Api.Customer.Application.Models
{
    public class CommunicationPreferenceTypeDescription
    {
        public const string IqMagazine = "IQ Magazine";
        public const string PromotionalMaterials = "Promotional communications";
        public const string AnnualReport = "Annual report";
        public const string StatementsAndConfirmations = "Statements and transaction confirmations";
    }
}
