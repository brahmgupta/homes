using System;
using System.Collections.Generic;

namespace Wealth.Api.Customer.Application.Models
{
    public class CustomerDto
    {
        public string CustomerNumber { get; set; }
        public string Title { get; set; }
        public string GivenName { get; set; }
        public string Surname { get; set; }
        public DateTime DateOfBirth { get; set; }
        public AddressDto ResidentialAddress { get; set; }
        public AddressDto MailingAddress { get; set; }
        public ContactDetailsDto ContactDetails { get; set; }
        public TfnDto Tfn { get; set; }
        public string EmployerAndSalarySacrifice { get; set; }
        public string CanAdviserCallReporting { get; set; }
        public string CanAdviserDetailChange { get; set; }
        public string AccessMode { get; set; }
        public int AccountsCount { get; set; }

        public IEnumerable<CommunicationPreferenceDto> CommunicationPreferences { get; set; }
        public IEnumerable<AccountDto> Accounts { get; set; }
    }
}
