namespace Wealth.Api.Customer.Application.Models
{
    public class ContactDetailsDto
    {
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string EmailAddress { get; set; }
    }
}