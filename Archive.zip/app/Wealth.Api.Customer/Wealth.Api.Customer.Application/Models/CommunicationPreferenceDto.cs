using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Application.Models
{
    public class CommunicationPreferenceDto
    {
        public int Id { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public CommunicationPreferenceType Type { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }
    }
}