﻿using System.Collections.Generic;

namespace Wealth.Api.Customer.Application.Models
{
    public class BaseRequest
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}
