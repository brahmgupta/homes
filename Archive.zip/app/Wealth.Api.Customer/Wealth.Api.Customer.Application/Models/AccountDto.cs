using System.Collections.Generic;
using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Application.Models
{
    public class AccountDto
    {
        public string Id { get; set; }
        public string AccountNumber { get; set; }
        public string AccountDesignation { get; set; }
        public string ProductCode { get; set; }
        public string AccountType { get; set; }
        public string ProductAbbreviation { get; set; }
        public AccessMode AccessMode { get; set; }
        public AddressDto MailingAddress { get; set; }
        public IEnumerable<CommunicationPreferenceDto> CommunicationPreferences { get; set; }
    }
}