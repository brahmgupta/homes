﻿using System.Linq;
using FluentValidation.Results;

namespace Wealth.Api.Customer.Application.Infrastructure
{
    public sealed class Utils
    {
        public static string FormatValidationErrorForLog(ValidationResult result)
        {
            return string.Join(",",
                result.Errors.Select(error =>
                    $"[{nameof(error.PropertyName)}: {error.PropertyName}, " +
                    $"{nameof(error.ErrorCode)}: {error.ErrorCode}, " +
                    $"{nameof(error.ErrorMessage)}: {error.ErrorMessage}]"));
        }
    }
}
