using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using Wealth.Toolkit.Configuration;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;
using Microsoft.Extensions.Hosting;
using Wealth.Toolkit.HttpService.Extensions;
using Wealth.Api.Account.Consent.Host.Infrastructure;

namespace Wealth.Api.Account.Consent.Host
{
    public class Startup
    {
        private const string API_NAME = "Wealth Api Account Consent";

        public Startup(IConfiguration configuration)
        {
            configuration.LoadAppSecrets("appsecrets.json", "Wealth.Api.Account.Consent.appSecrets.key");
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // ReSharper disable once UnusedParameter.Local
        private static Task HandleException(HttpContext context)
        {
            return Task.CompletedTask;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public virtual void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddLoggerContext();
            services.AddHttpServices(Configuration);
            services.AddDependencies(Configuration);
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = API_NAME, Version = "v1" });
                c.CustomSchemaIds(x => x.FullName);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            loggerFactory.UseNlog(serviceProvider);

            app.UseRouter(a => a.MapGet("healthcheck", context =>
            {
                context.Response.Headers[HeaderNames.CacheControl] = "no-cache, no-store";
                context.Response.Headers[HeaderNames.Pragma] = "no-cache";
                return context.Response.WriteAsync($"Success from ({env.EnvironmentName})");
            }));

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("../swagger/v1/swagger.json", API_NAME); });
            }

            app.UseExceptionHandler(new ExceptionHandlerOptions
            {
                ExceptionHandler = HandleException
            });

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpServices();

            app.UsePerformanceLogger();

            app.UseHttpsRedirection();
            
            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            
        }
    }
}
