﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Filters;
using Wealth.Toolkit.Response.Models;
using System.Runtime.InteropServices;
using System.ComponentModel.DataAnnotations;
using Wealth.Api.Account.Consent.Application.Commands;
using Wealth.Api.Account.Consent.Host.Infrastructure.Attributes;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Api.Account.Consent.Application.Queries;
using Wealth.Api.Account.Consent.Host.Infrastructure;

namespace Wealth.Api.Account.Consent.Host.Controllers
{
    [Route("api/Accounts")]
    [ApiController]
    public class ConsentsController : BaseController
    {
        [HttpGet("{accountNumber}/consents/{consentType}")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber", "accountNumber", "staffOin")]
        [ProducesResponseType(typeof(ConsentDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<ConsentDto>> GetConsent(
            [FromHeader] [Optional] string sessionId,
            [FromHeader] [Optional] string channel,
            [FromHeader] [Required] string companyCode,
            [FromQuery] [Required] string customerNumber,
            [FromHeader] [Optional] string staffOin,
            [FromRoute] [Required] string accountNumber,
            [FromRoute] [Required] string consentType,
            CancellationToken cancellation)
        {
            var request = new GetConsentQuery
            {
                AccountNumber = accountNumber,
                ConsentType = consentType,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber,
                    null,
                    null,
                    staffOin)
            };

            var response = await Mediator.Send(request, cancellation);
            return response.ToTypedActionResult<ConsentDto>();
        }

        [HttpPut("{accountNumber}/consents/{consentType}")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber", "accountNumber", "staffOin")]
        [ProducesResponseType(typeof(ConsentDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<ConsentDto>> UpdateConsent(
            [FromHeader] [Optional] string sessionId,
            [FromHeader] [Optional] string channel,
            [FromHeader] [Required] string companyCode,
            [FromHeader] [Optional] string staffOin,
            [FromQuery] [Required] string customerNumber,
            [FromRoute] [Required] string accountNumber,
            [FromRoute] [Required] string consentType,
            [FromBody][Optional]UpdateConsentRequest updateConsentRequest,
            CancellationToken cancellation)
        {
            var request = new UpdateConsentCommand
            {
                AccountNumber = accountNumber,
                ConsentType = consentType,
                ConfirmationLetter = updateConsentRequest?.ConfirmationLetter,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber,
                    null,
                    null,
                    staffOin)
            };

            var response = await Mediator.Send(request, cancellation);
            return response.ToTypedActionResult<ConsentDto>();
        }
    }
}