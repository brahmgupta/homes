﻿using System;
using Wealth.Api.Account.Consent.Application.Infrastructure;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Features
{
    public class FmsRequest
    {
        public FmsRequest(RequestContext request)
        {
            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandChannelKey, out var channelValue);
            if (!string.IsNullOrWhiteSpace(channelValue))
            {
                Channel = channelValue;
            }

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandSessionIdKey, out var sessionId);
            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                if (long.TryParse(sessionId, out var longSessionId))
                {
                    SessionId = longSessionId;
                }
                else
                {
                    throw new ArgumentException($"The {nameof(SessionId)} must be a number");
                }
            }

            long longCustomerNumber = 0;
            if (request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandCustomerNumberKey, out var customerNumber) &&
                !long.TryParse(customerNumber, out longCustomerNumber))
            {
                throw new ArgumentException($"The {nameof(CustomerNumber)} must be a number");
            }
            CustomerNumber = longCustomerNumber;

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandCompanyCodeKey, out var companyCode);
            CompanyCode = companyCode;

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandAdviserCodeKey, out var adviserCode);
            AdviserCode = adviserCode?.ToString() ?? string.Empty;

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandDealerCodeKey, out var dealerCode);
            DealerCode = dealerCode?.ToString() ?? string.Empty;

            long longStaffOin = 0;
            if (request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandStaffOinKey, out var staffOin) &&
                !long.TryParse(staffOin, out longStaffOin))
            {
                throw new ArgumentException($"The {nameof(StaffOin)} must be a number");
            }
            StaffOin = longStaffOin;
        }

        public long SessionId { get; }
        public string CompanyCode { get; }
        public long CustomerNumber { get; }
        public string Channel { get; }
        public string AdviserCode { get; }
        public string DealerCode { get; }
        public long StaffOin { get; }
    }
}
