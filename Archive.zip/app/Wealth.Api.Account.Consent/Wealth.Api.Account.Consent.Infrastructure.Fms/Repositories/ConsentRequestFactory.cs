﻿using FluentResults;
using MediatR;
using System;
using System.Collections.Generic;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Features.GetIlba;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Features.UpdateIlba;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Mappers;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Repositories
{
    public class ConsentRequestFactory
    {
        private readonly Dictionary<ConsentType,
                Func<string, RequestContext, IRequest<Result<ConsentDetails>>>>
            _requestTypeDictionary =
                new Dictionary<ConsentType, Func<string, RequestContext, IRequest<Result<ConsentDetails>>>>
                {
                    {
                        ConsentType.ILBA,
                        (accountNumber, requestContext) => new GetIlbaRequest(requestContext)
                            {AccountNumber = accountNumber}
                    }
                };

        private readonly Dictionary<ConsentType,
           Func<string, bool?, RequestContext, IRequest<Result<ConsentDetails>>>>
       _requestTypeUpdateDictionary =
           new Dictionary<ConsentType, Func<string, bool?, RequestContext, IRequest<Result<ConsentDetails>>>>
           {
                    {
                        ConsentType.ILBA,
                        (accountNumber, confirmationletter, requestContext) => new UpdateIlbaRequest(requestContext)
                            {AccountNumber = accountNumber,
                            ConfirmationLetter = confirmationletter}
                    }
           };

        public IRequest<Result<ConsentDetails>> CreateGetRequest(GetConsentRequest consentRequest)
        {
            var consentType = ConsentTypeMapper.GetConsentType(consentRequest.ConsentType);

            return _requestTypeDictionary.ContainsKey(consentType)
                ? _requestTypeDictionary[consentType].Invoke(consentRequest.AccountNumber, consentRequest)
                : null;
        }

        public IRequest<Result<ConsentDetails>> CreateUpdateRequest(UpdateConsentRequest consentRequest)
        {
            var consentType = ConsentTypeMapper.GetConsentType(consentRequest.ConsentType);

            return _requestTypeUpdateDictionary.ContainsKey(consentType)
                ? _requestTypeUpdateDictionary[consentType].Invoke(consentRequest.AccountNumber, consentRequest.ConfirmationLetter, consentRequest)
                : null;
        }
    }
}
