﻿using FluentValidation;
using Wealth.Api.Account.Consent.Application.Infrastructure;

namespace Wealth.Api.Account.Consent.Application.Queries
{
    public class GetConsentQueryValidator: BaseRequestValidator<GetConsentQuery>
    {
        public GetConsentQueryValidator()
        {
            RuleFor(x => x.AccountNumber).NotEmpty();
        }
    }
}

