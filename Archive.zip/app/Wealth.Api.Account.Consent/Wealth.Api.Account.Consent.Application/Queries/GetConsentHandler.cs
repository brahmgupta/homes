﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Factories;
using Wealth.Toolkit.Response.Models;

namespace Wealth.Api.Account.Consent.Application.Queries
{
    public class GetConsentHandler : IRequestHandler<GetConsentQuery, Response>
    {
        private const string ERROR_MESSAGE = "Error retrieving account consent";
        private readonly IConsentRepository _consentRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<GetConsentHandler> _logger;

        public GetConsentHandler(IConsentRepository consentRepository, IMapper mapper,
            ILogger<GetConsentHandler> logger)
        {
            _mapper = mapper;
            _logger = logger;
            _consentRepository = consentRepository;
        }

        public async Task<Response> Handle(GetConsentQuery request, CancellationToken cancellationToken)
        {
            var consentResult = await _consentRepository.GetConsent(new GetConsentRequest
            {
                AccountNumber = request.AccountNumber,
                ConsentType = request.ConsentType,
                OutOfBand = request.OutOfBand
            }, cancellationToken);

            if (consentResult.IsFailed)
            {
                var response = Responses.Fail(consentResult, ERROR_MESSAGE);
                response.Log(_logger, ERROR_MESSAGE);
                return response;
            }

            var consent = _mapper.Map<ConsentDto>(consentResult.Value);
            _logger.LogDebug("Successfully retrieved consent.");
            return Responses.Success(consent);
        }
    }
}
