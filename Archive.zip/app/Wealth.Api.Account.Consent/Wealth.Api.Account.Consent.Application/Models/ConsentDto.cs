﻿using System;

namespace Wealth.Api.Account.Consent.Application.Models
{
    public class ConsentDto
    {
        public DateTime? ExpiryDate { get; set; }
    }
}
