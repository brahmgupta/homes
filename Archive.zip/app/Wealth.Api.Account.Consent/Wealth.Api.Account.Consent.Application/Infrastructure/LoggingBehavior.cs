﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Wealth.Api.Account.Consent.Application.Infrastructure
{
    public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        private readonly ILogger _logger;

        public LoggingBehavior(ILogger<TRequest> logger)
        {
            _logger = logger;
        }

        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            _logger.LogTrace("Handling '{name}' Request: '{request}'", typeof(TRequest).Name, request);
            var response = await next();
            _logger.LogTrace("Handled '{name}' Response: '{response}'", typeof(TResponse).Name, response);

            return response;
        }
    }

}
