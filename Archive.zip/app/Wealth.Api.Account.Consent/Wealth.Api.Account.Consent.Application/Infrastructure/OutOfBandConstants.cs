﻿namespace Wealth.Api.Account.Consent.Application.Infrastructure
{
    public static class OutOfBandConstants
    {
        public const string OutOfBandSessionIdKey = "sessionId";
        public const string OutOfBandChannelKey = "channel";
        public const string OutOfBandCompanyCodeKey = "companyCode";
        public const string OutOfBandCustomerNumberKey = "customerNumber";
        public const string OutOfBandMobileChannelValue = "mobile";
        public const string OutOfBandAdviserCodeKey = "adviserCode";
        public const string OutOfBandDealerCodeKey = "dealerCode";
        public const string OutOfBandStaffOinKey = "staffOin";
    }
}
