﻿using FluentValidation;
using Wealth.Api.Account.Consent.Application.Infrastructure;

namespace Wealth.Api.Account.Consent.Application.Commands
{
    public class UpdateConsentCommandValidator : BaseRequestValidator<UpdateConsentCommand>
    {
         public UpdateConsentCommandValidator()
        {
            RuleFor(x => x.AccountNumber).NotEmpty().NotNull();
        }
    }
}
