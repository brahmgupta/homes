﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Factories;
using Wealth.Toolkit.Response.Models;
using UpdateConsentRequest = Wealth.Api.Account.Consent.Domain.ConsentAggregate.UpdateConsentRequest;

namespace Wealth.Api.Account.Consent.Application.Commands
{
    public class UpdateConsentCommandHandler : IRequestHandler<UpdateConsentCommand, Response>
    {
        private const string ERROR_MESSAGE = "Error retrieving account consent";
        private readonly IConsentRepository _consentRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<UpdateConsentCommandHandler> _logger;

        public UpdateConsentCommandHandler(IConsentRepository consentRepository, IMapper mapper,
            ILogger<UpdateConsentCommandHandler> logger)
        {
            _mapper = mapper;
            _logger = logger;
            _consentRepository = consentRepository;
        }

        public async Task<Response> Handle(UpdateConsentCommand request, CancellationToken cancellationToken)
        {
            var consentResult = await _consentRepository.UpdateConsent(new UpdateConsentRequest
            {
                AccountNumber = request.AccountNumber,
                ConsentType = request.ConsentType,
                ConfirmationLetter = request.ConfirmationLetter,
                OutOfBand = request.OutOfBand
            }, cancellationToken);

            if (consentResult.IsFailed)
            {
                var response = Responses.Fail(consentResult, ERROR_MESSAGE);
                response.Log(_logger, ERROR_MESSAGE);
                return response;
            }

            var consent = _mapper.Map<ConsentDto>(consentResult.Value);
            _logger.LogDebug("Successfully updated consent.");
            return Responses.Success(consent);
        }
    }
}
