using Xunit;

namespace Wealth.Api.Account.Consent.Tests
{
    public class HealthControllerTests
    {

        [Fact]
        public void ShouldReturnOkGivenHealthIsCalled()
        {
            Assert.Equal("OK", "OK");
        }
    }
}