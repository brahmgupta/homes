﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public class RequestContext
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}
