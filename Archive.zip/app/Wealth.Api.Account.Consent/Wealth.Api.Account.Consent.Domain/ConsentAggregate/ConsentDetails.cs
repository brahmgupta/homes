﻿using System;
using Wealth.Api.Account.Consent.Domain.SeedWork;

namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public class ConsentDetails : Entity<string>, IAggregateRoot
    {
        public ConsentDetails(DateTime? expiryDate)
        {
            ExpiryDate = expiryDate;
        }

        public DateTime? ExpiryDate { get; private set; }
    }
}
