﻿using System;

namespace FirstNet.Investor.WebApi.Application.Models
{
    public class Amount
    {
        public decimal Value { get; set; }
        public string Display => Value.ToString("C");
        public string AbsoluteDisplay => Value < decimal.Zero ? Math.Abs(Value).ToString("C") : null;
    }
}