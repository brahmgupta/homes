﻿using System;

namespace FirstNet.Investor.WebApi.Application.Models
{
    public class Date
    {
        public DateTime? Value { get; set; }
        public string Display => Value.HasValue ? string.Format("{0:d MMM yyyy}", Value) : null;
    }
}
