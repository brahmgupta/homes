﻿namespace FirstNet.Investor.WebApi.Application.Models
{
    public abstract class RequestBase
    {
        public string SessionId { get; set; }
        public string CompanyCode { get; set; }
        public string CustomerNumber { get; set; }
    }
}