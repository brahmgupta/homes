﻿using System.Net;
using FirstNet.Investor.WebApi.Common.Settings;
using FluentResults;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Wealth.Toolkit.Response.Factories;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Application.Infrastructure
{
    public class ErrorResponseFactory : IErrorResponseFactory
    {
        private readonly UpstreamSettings _settings;

        public ErrorResponseFactory(IOptions<UpstreamSettings> options)
        {
            _settings = options.Value;
        }

        [System.Obsolete]
        public Response CreateErrorResponse(ResultBase result, string message)
        {
            var response = Responses.Fail(result, message);
            if (response.HttpStatusCode == HttpStatusCode.Forbidden)
            {
                response.Headers[HeaderNames.Location] = _settings.SessionTimeoutRedirectUrl;
            }

            return response;
        }

        public Response CreateProblemResponse(ResultBase result, string message)
        {
            var response = Responses.ToProblemDetailsResponse(result, message);
            if (response.HttpStatusCode == HttpStatusCode.Forbidden)
            {
                response.Headers[HeaderNames.Location] = _settings.SessionTimeoutRedirectUrl;
            }

            return response;
        }
    }
}
