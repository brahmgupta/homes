﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Application.SSO
{
    public interface ISSOHandler
    {
        string Type { get; }
        Task<Response> Handle(IEnumerable<Claim> claims, string ssoCode, CancellationToken cancellationToken);
    }
}
