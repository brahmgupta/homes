﻿using System.Security.Claims;

namespace FirstNet.Investor.WebApi.Application.CurrentContext
{
    public interface ICurrentContextProvider
    {
        UserContext GetUserContext(ClaimsPrincipal user);
        ExperienceSettings GetExperienceSettings(UserContext userContext);
    }
}
