﻿namespace FirstNet.Investor.WebApi.Application.CurrentContext
{
    public class ExperienceSettings
    {
        public string FullName { get; set; }
        public string CompanyCode { get; set; }
        public string DataToolsBaseUrl { get; set; }
        public int DataToolsTimeout { get; set; }
        public string DataToolsKey { get; set; }
        public string NewFniBaseUrl { get; set; }
        public string LogoutUrl { get; set; }
        public string CfsBaseUrl { get; set; }
        public string AnalyticsEnvironment { get; set; }
        public string AnalyticsRSId { get; set; }
        public string AnalyticsVersion { get; set; }
        public bool IsEmulation { get; set; }
        public bool IsSmsAuthenticated { get; set; }
        public string EnvironmentName { get; set; }
    }
}
