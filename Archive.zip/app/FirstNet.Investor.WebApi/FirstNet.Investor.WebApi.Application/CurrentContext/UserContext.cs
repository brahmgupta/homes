﻿namespace FirstNet.Investor.WebApi.Application.CurrentContext
{
    public class UserContext
    {
        public string CustomerNumber { get; set; }
        public string SessionId { get; set; }
        public string CompanyCode { get; set; }
        public string FullName { get; set; }
        public bool IsEmulation { get; set; }
        public bool IsSmsAuthenticated{ get; set; }

        public static class Claims
        {
            public static string CompanyCode = "CompanyCode";
            public static string CustomerNumber = "Oin";
            public static string SessionId = "FmsSession";
            public static string FullName = "FullName";
            public static string IsEmulation = "IsEmulation";
            public static string MultiFactorAuth = "MultiFactorAuth";
        }
    }
}