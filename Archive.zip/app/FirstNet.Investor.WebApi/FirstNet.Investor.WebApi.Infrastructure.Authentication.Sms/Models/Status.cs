﻿namespace FirstNet.Investor.WebApi.Infrastructure.Authentication.Sms.Models
{
    public static class Status
    {
        public static class GenerateSmsCode
        {
            public const string Generated = "Generated";
            public const string InvalidMobileNo = "InvalidMobileNo";
            public const string SmsAuthenticationLocked = "SmsAuthenticationLocked";
            public const string InvalidCallerUserId = "InvalidCallerUserId";
            public const string Error = "Error";
        }

        public static class VerifySmsCode
        {
            public const string Verified = "Verified";
            public const string InvalidMobileNo = "InvalidMobileNo";
            public const string InvalidSmsCode = "InvalidSmsCode";
            public const string SmsAuthenticationLocked = "SmsAuthenticationLocked";
            public const string Error = "Error";
            public const string InvalidCallerUserId = "InvalidCallerUserId";
        }
    }
}