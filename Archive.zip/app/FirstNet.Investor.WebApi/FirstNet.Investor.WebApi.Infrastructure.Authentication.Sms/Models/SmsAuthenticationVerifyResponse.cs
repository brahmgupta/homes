﻿namespace FirstNet.Investor.WebApi.Infrastructure.Authentication.Sms.Models
{
    public class SmsAuthenticationVerifyResponse
    {
        public string AuthenticationResult { get; set; }
    }
}
