﻿namespace FirstNet.Investor.WebApi.Infrastructure
{
    public interface ICacheableService
    {
        string CacheKey { get; }
    }
}