﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using FluentResults;
using Microsoft.Extensions.Logging;
using Wealth.Toolkit.HttpService.HttpService;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Models;
using Error = Wealth.Toolkit.Response.Models.Error;
using ILogger = Microsoft.Extensions.Logging.ILogger;

namespace FirstNet.Investor.WebApi.Infrastructure
{
    public class ApiResponseHandler : IApiResponseHandler
    {
        private readonly ILogger _logger;

        public ApiResponseHandler(ILogger<ApiResponseHandler> logger)
        {
            _logger = logger;
        }

        public async Task<Result<TResult>> HandleResponse<TResult>(HttpResponseMessage response)
        {
            try
            {
                _logger.LogTrace("Handling the response returned by '{RequestUri}'", response.RequestMessage.RequestUri);
                var result = await HttpHelper.HandleResponse<TResult>(response);
                _logger.LogTrace("Handled the response returned by '{RequestUri}'", response.RequestMessage.RequestUri);

                return Results.Ok(result);
            }
            catch (Exception exception)
            {
                _logger.LogInformation(exception,
                    "Error in the response returned by '{RequestUri}'. Falling back to the error handler.",
                    response.RequestMessage.RequestUri);
                return await HandleError<TResult>(response);
            }
        }

        public async Task<Result> HandleResponse(HttpResponseMessage response)
        {
            _logger.LogTrace("Handling the response returned by '{RequestUri}'", response.RequestMessage.RequestUri);
            if (response.IsSuccessStatusCode)
            {
                _logger.LogTrace("Handled the response returned by '{RequestUri}'",
                    response.RequestMessage.RequestUri);
                return Results.Ok();
            }

            _logger.LogInformation(
                "Error in the response returned by '{RequestUri}'. Falling back to the error handler.",
                response.RequestMessage.RequestUri);

            return await HandleError(response);
        }


        private async Task<Result> HandleError(HttpResponseMessage response)
        {
            try
            {
                _logger.LogTrace("Handling the error returned by '{RequestUri}'", response.RequestMessage.RequestUri);
                var responseError = await HttpHelper.HandleResponse<Error>(response, false);
                _logger.LogTrace("Handled the error returned by '{RequestUri}' Error: '{responseError}'",
                    response.RequestMessage.RequestUri, responseError);

                return Results.Fail(new WrappedError(responseError));
            }
            catch (Exception exception)
            {
                _logger.LogWarning(exception,
                    "Failed to handle the error returned by '{RequestUri}'. Falling back to raw content returned by this call.",
                    response.RequestMessage.RequestUri);
                return Results.Fail(new WrappedError(exception.ToError()));
            }
        }

        private async Task<Result<TResult>> HandleError<TResult>(HttpResponseMessage response)
        {
            try
            {
                _logger.LogTrace("Handling the error returned by '{RequestUri}'", response.RequestMessage.RequestUri);
                var responseError = await HttpHelper.HandleResponse<Error>(response, false);
                _logger.LogTrace("Handled the error returned by '{RequestUri}' Error: '{responseError}'",
                    response.RequestMessage.RequestUri, responseError);

                return Results.Fail<TResult>(new WrappedError(responseError));
            }
            catch (Exception exception)
            {
                _logger.LogWarning(exception,
                    "Failed to handle the error returned by '{RequestUri}'. Falling back to raw content returned by this call.",
                    response.RequestMessage.RequestUri);
                return Results.Fail<TResult>(new WrappedError(exception.ToError()));
            }
        }
    }
}
