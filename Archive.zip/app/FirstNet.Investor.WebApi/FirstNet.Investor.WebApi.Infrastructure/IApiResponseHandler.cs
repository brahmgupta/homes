﻿using System.Net.Http;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Infrastructure
{
    public interface IApiResponseHandler
    {
        Task<Result<TResult>> HandleResponse<TResult>(HttpResponseMessage response);
        Task<Result> HandleResponse(HttpResponseMessage response);
    }
}