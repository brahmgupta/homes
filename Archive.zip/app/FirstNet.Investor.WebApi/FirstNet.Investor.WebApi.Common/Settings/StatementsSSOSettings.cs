﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class StatementsSSOSettings
    {
        public string SharedKey { get; set; }
        public string TokenIssuer { get; set; }
        public int TokenLifeTimeInMinutes { get; set; }
        public string Url { get; set; }
        public string EncryptionKey { get; set; }
        public string EncryptionInitVector { get; set; }

    }
}
