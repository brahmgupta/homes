﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class AppSettings
    {
        public DownstreamSettings DownstreamSettings { get; set; }
        public UpstreamSettings UpstreamSettings { get; set; }
        public Logging Logging { get; set; }
        public SmsAuthenticationSettings SmsAuthenticationSettings { get; set; }

        public StatementsSSOSettings StatementsSSOSettings { get; set; }
        public string MenuConfigFilename { get; set; }
        public string ContentsFilename { get; set; }
    }
}
