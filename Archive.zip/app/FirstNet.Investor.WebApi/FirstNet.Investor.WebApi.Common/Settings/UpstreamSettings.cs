﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class UpstreamSettings
    {
        public string DataToolsBaseUrl { get; set; }
        public int DataToolsTimeout { get; set; }
        public string DataToolsKey { get; set; }
        public string NewFniBaseUrl { get; set; }
        public string LogoutUrl { get; set; }
        public string LoginUrl { get; set; }
        public string CfsBaseUrl { get; set; }
        public string ClassicFirstNetBaseUrl { get; set; }
        public string SessionTimeoutRedirectPage { get; set; }

        public string SessionTimeoutRedirectUrl => ClassicFirstNetBaseUrl + SessionTimeoutRedirectPage;

        public string AnalyticsEnvironment { get; set; }
        public string AnalyticsRSId { get; set; }
        public string AnalyticsVersion { get; set; }
    }
}