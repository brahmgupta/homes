﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class ProductApiSettings
    {
        public string CbaApiKey { get; set; }
        public string BaseUrl { get; set; }
    }
}
