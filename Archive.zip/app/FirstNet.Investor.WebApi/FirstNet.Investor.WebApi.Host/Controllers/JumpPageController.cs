﻿using System;
using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.SSO;
using FirstNet.Investor.WebApi.Common.Settings;
using FirstNet.Investor.WebApi.Host.Infrastructure.SSO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    [Route("")]
    public class JumpPageController : Controller
    {
        private readonly ISSOHandlerFactory _ssoHandlerFactory;
        private readonly IOptions<AppSettings> _options;

        public JumpPageController(ISSOHandlerFactory ssoHandlerFactory, IOptions<AppSettings> options)
        {
            _ssoHandlerFactory = ssoHandlerFactory;
            _options = options;
        }

        [HttpGet]
        [Route("jumppage")]
        public async Task<IActionResult> Get([FromQuery(Name = "dst")]string destination, [FromQuery(Name = "code")]string ssoCode)
        {
            var ssoHandler = _ssoHandlerFactory.CreateHandler(destination);
            var result = await ssoHandler.Handle(HttpContext.User.Claims, ssoCode, CancellationToken.None);

            if (ssoHandler.Type == SSOTypes.STATEMENTS && result is ValueResponse<string> statementsResponse)
            {
                ViewData["StatementSSOUrl"] = _options.Value.StatementsSSOSettings.Url;
                ViewData["token"] = statementsResponse.Value;
                return View();
            }
            if (ssoHandler.Type == SSOTypes.FNI && result is ValueResponse<Func<IResponseCookies, string>> fniCookieHandler)
            {
                fniCookieHandler.Value(HttpContext.Response.Cookies);
                return Redirect(_options.Value.UpstreamSettings.NewFniBaseUrl + "/" + destination);
            }

            return Redirect(_options.Value.UpstreamSettings.LoginUrl);
        }
    }
}
