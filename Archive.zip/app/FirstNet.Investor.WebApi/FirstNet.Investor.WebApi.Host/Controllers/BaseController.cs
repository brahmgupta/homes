﻿using FirstNet.Investor.WebApi.Application.CurrentContext;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public abstract class BaseController : ControllerBase
    {
        private IMediator _mediator;
        private ICurrentContextProvider _currentContextProvider;
        private UserContext _userContext;

        protected IMediator Mediator => _mediator ?? (_mediator = HttpContext.RequestServices.GetService<IMediator>());

        protected ICurrentContextProvider CurrentContextProvider =>
            _currentContextProvider ??
            (_currentContextProvider = HttpContext.RequestServices.GetService<ICurrentContextProvider>());

        protected UserContext UserContext => _userContext ?? (_userContext = CurrentContextProvider.GetUserContext(User));
    }
}