﻿using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Models;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Queries.GetRegistrationStatus;
using FirstNet.Investor.WebApi.Application.TwoFactorAuthentication.Commands.GenerateSms;
using FirstNet.Investor.WebApi.Application.TwoFactorAuthentication.Commands.VerifySms;
using FirstNet.Investor.WebApi.Application.TwoFactorAuthentication.Queries.GetSmsStatus;
using FirstNet.Investor.WebApi.Host.Infrastructure.Authorization;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Lib.InvestorAuthentication.Cookie;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    [Authorize(Policy = AuthorizationPolicyTypes.SmsAuthentication)]
    public class SmsAuthenticationController : BaseController
    {
        [Route("generate", Name = "generateSmsAuth")]
        [HttpPost]
        [ProducesResponseType(typeof(SmsGenerateViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<SmsGenerateViewModel>> Generate(
            [FromHeader(Name = Constants.Headers.FirstNetCodePurposeHeader)] [Required]
            string purpose)
        {
            var request = new Application.SmsAuthentication.Commands.GenerateSms.GenerateSmsCommand
            {
                CompanyCode = UserContext.CompanyCode,
                CustomerNumber = UserContext.CustomerNumber,
                Purpose = purpose
            };

            var response = await Mediator.Send(request);

            return response.ToTypedActionResult<SmsGenerateViewModel>();
        }

        [Route("verify", Name = "verifySmsAuth")]
        [HttpPost]
        [ProducesResponseType(typeof(SmsVerifyViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<SmsVerifyViewModel>> Verify(
            [FromHeader(Name = Constants.Headers.FirstNetCodePurposeHeader)] [Required]
            string purpose,
            SmsAuthentication smsAuthentication,
            [FromServices] ICookieHandler investorCookieHandler)
        {
            var request = new Application.SmsAuthentication.Commands.VerifySms.VerifySmsCommand
            {
                CompanyCode = UserContext.CompanyCode,
                CustomerNumber = UserContext.CustomerNumber,
                Purpose = purpose,
                AuthenticationCode = smsAuthentication.Code
            };

            var response = await Mediator.Send(request);

            if (response.IsSuccessfulResponse)
            {
                if (response is ValueResponse<SmsVerifyViewModel> valueResponse && valueResponse.Value.Success)
                {
                    investorCookieHandler.StepUpCookieForSms(Response.Cookies, User.Claims);
                }
            }

            return response.ToTypedActionResult<SmsVerifyViewModel>();
        }

        [Route("status", Name = "getSmsAuthStatus")]
        [HttpGet]
        [ProducesResponseType(typeof(SmsStatusViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<SmsStatusViewModel>> GetStatus()
        {
            var request = new GetRegistrationStatusQuery
            {
                CompanyCode = UserContext.CompanyCode,
                CustomerNumber = UserContext.CustomerNumber,
                SessionId = UserContext.SessionId,
            };

            var response = await Mediator.Send(request);

            return response.ToTypedActionResult<SmsStatusViewModel>();
        }
    }
}