﻿using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Commands.UpdateCustomerProfile;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Models;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Queries.GetCustomerProfile;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Host.Infrastructure.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class CustomerProfileController : BaseController
    {
        [HttpGet(Name = "getCustomerProfile")]
        [Authorize(Policy = AuthorizationPolicyTypes.CustomerProfileView)]
        [ProducesResponseType(typeof(CustomerProfileViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CustomerProfileViewModel>> Get(CancellationToken cancellationToken)
        {
            var response = await Mediator.Send(new GetCustomerProfileQuery
            {
                CustomerNumber = UserContext.CustomerNumber,
                SessionId = UserContext.SessionId,
                CompanyCode = UserContext.CompanyCode,
                IsAuthorized = true
            }, cancellationToken);

            return response.ToTypedActionResult<CustomerProfileViewModel>();
        }

        [HttpPost(Name="updateCustomerProfile")]
        [Authorize(Policy = AuthorizationPolicyTypes.UpdateDetails)]
        [ProducesResponseType(typeof(UpdateCustomerResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<UpdateCustomerResponse>> Update(CustomerProfileViewModel customerProfile, CancellationToken cancellationToken)
        {
            var response = await Mediator.Send(new UpdateCustomerProfileCommand
            {
                CustomerNumber = UserContext.CustomerNumber,
                SessionId = UserContext.SessionId,
                CompanyCode = UserContext.CompanyCode,
                CustomerProfile = customerProfile
            }, cancellationToken);

            return response.ToTypedActionResult<UpdateCustomerResponse>();
        }
    }
}
