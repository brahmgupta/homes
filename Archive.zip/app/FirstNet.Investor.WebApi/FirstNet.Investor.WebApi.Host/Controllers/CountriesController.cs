﻿using FirstNet.Investor.WebApi.Application.Countries.Models;
using FirstNet.Investor.WebApi.Application.Countries.Queries;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading;
using System.Threading.Tasks;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class CountriesController : BaseController
    {
        [HttpGet(Name="getCountries")]
        [ProducesResponseType(typeof(CountryModel[]), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CountryModel[]>> Get(CancellationToken cancellationToken)
        {
            var results = await Mediator.Send(new GetCountriesQuery(), cancellationToken);

            return results.ToTypedActionResult<CountryModel[]>();
        }
    }
}
