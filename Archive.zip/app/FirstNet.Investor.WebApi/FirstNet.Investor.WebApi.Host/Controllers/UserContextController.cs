﻿using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.CurrentContext;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class UserContextController : BaseController
    {
        [HttpGet(Name="getUserContext")]
        [ProducesResponseType(typeof(ExperienceSettings), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<ExperienceSettings>> Get()
        {
            var response = await Task.Run(() => CurrentContextProvider.GetExperienceSettings(UserContext));

            return Ok(response);
        }
    }
}