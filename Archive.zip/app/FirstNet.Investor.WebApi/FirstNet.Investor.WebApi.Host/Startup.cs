using System;
using System.Reflection;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.CurrentContext;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Queries.GetCustomerProfile;
using FirstNet.Investor.WebApi.Application.Infrastructure;
using FirstNet.Investor.WebApi.Application.Infrastructure.States;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Commands.GetMobileStatus;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Commands.GetMobileStatus.States;
using FirstNet.Investor.WebApi.Application.SSO;
using FirstNet.Investor.WebApi.Application.SSO.FNI;
using FirstNet.Investor.WebApi.Application.SSO.Statements;
using FirstNet.Investor.WebApi.Application.TwoFactorAuthentication.Common;
using FirstNet.Investor.WebApi.Common.Settings;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Domain.Content;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Customer;
using FirstNet.Investor.WebApi.Infrastructure.Services.SmsAuthentication;
using FluentValidation.AspNetCore;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Wealth.Toolkit.Configuration;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;
using Wealth.Toolkit.Response.Filters;
using Wealth.Lib.InternalAccessToken.Consumer;
using Wealth.Toolkit.HttpService.HttpService;
using FirstNet.Investor.WebApi.Domain.Product;
using FirstNet.Investor.WebApi.Domain.SSO;
using FirstNet.Investor.WebApi.Infrastructure.Services.Product;
using FirstNet.Investor.WebApi.Host.Infrastructure.Authentication;
using FirstNet.Investor.WebApi.Host.Infrastructure.Authorization;
using FirstNet.Investor.WebApi.Host.Infrastructure.SSO;
using FirstNet.Investor.WebApi.Infrastructure;
using FirstNet.Investor.WebApi.Infrastructure.Services.Accounts;
using MediatR.Pipeline;
using Wealth.Toolkit.HttpService.Extensions;
using FirstNet.Investor.WebApi.Infrastructure.Services.AccountMenu;
using FirstNet.Investor.WebApi.Infrastructure.Services.Authentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Contents;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Wealth.Lib.AntiForgery;
using Wealth.Lib.InvestorAuthentication;
using Wealth.Lib.ReleaseFeatureToggles;
using FirstNet.Investor.WebApi.Infrastructure.Services.AccountTransactions;
using FirstNet.Investor.WebApi.Domain.AccountTransactions;

[assembly: ApiController]
[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace FirstNet.Investor.WebApi.Host
{
    public class Startup
    {
        private const string API_NAME = "FirstNet.Investor.WebApi";
        private const string APP_SECRETS = "appsecrets.json";
        private const string FNI_CONFIGURATION_SECTION_NAME = "Authentication:FNI";

        public Startup(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            configuration.LoadAppSecrets(APP_SECRETS, $"{API_NAME}.appSecrets.key");
            Configuration = configuration;
            HostingEnvironment = hostingEnvironment;
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment HostingEnvironment { get; }

        // ReSharper disable once UnusedParameter.Local
        private static Task HandleException(HttpContext context)
        {
            return Task.CompletedTask;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public virtual void ConfigureServices(IServiceCollection services)
        {
            services.AddFNIAuthentication(Configuration, FNI_CONFIGURATION_SECTION_NAME);
            services.AddInternalAccessTokenAuthentication(Configuration);
            services
                .AddMvc(options =>
                {
                    options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                    options.Filters.Add(new ResponseCacheAttribute
                    { Location = ResponseCacheLocation.None, NoStore = true });
                })
                .AddJsonOptions(options =>
                {
                    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                })
                .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<GetCustomerProfileQueryValidator>())
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestPreProcessorBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
            services.AddMediatR(typeof(GetCustomerProfileQueryHandler).GetTypeInfo().Assembly);
            services.Configure<AppSettings>(Configuration);
            services.Configure<UpstreamSettings>(Configuration.GetSection(nameof(UpstreamSettings)));
            services.Configure<DownstreamSettings>(Configuration.GetSection(nameof(DownstreamSettings)));
            services.Configure<SmsAuthenticationSettings>(Configuration.GetSection(nameof(SmsAuthenticationSettings)));
            services.Configure<ProductApiSettings>(Configuration.GetSection($"{nameof(DownstreamSettings)}:WealthApiProductApiSettings"));
            services.AddSingleton<IHttpRequestBuilder, HttpRequestBuilder>();
            services.AddTransient<IHeaderUtility, HeaderUtility>();
            services.AddTransient<ISmsAuthenticationHeaderFactory, SmsAuthenticationHeaderFactory>();
            services.AddTransient<ISmsStatusResponseFactory, SmsStatusResponseFactory>();
            services.AddTransient<Application.SmsAuthentication.Common.ISmsStatusResponseFactory, Application.SmsAuthentication.Common.SmsStatusResponseFactory>();
            services.AddTransient<ISmsMessageMapper, SmsMessageMapper>();
            services.AddTransient<Application.SmsAuthentication.Common.ISmsMessageMapper, Application.SmsAuthentication.Common.SmsMessageMapper>();
            services.AddTransient<IApiResponseHandler, ApiResponseHandler>();
            services.AddTransient<ISmsAuthenticationResponseHandler, SmsAuthenticationResponseHandler>();
            services.AddTransient<ICurrentContextProvider, CurrentContextProvider>();
            services.AddTransient<IErrorResponseFactory, ErrorResponseFactory>();
            services.AddTransient<ISSOHandler, FniSSOHandler>();
            services.AddTransient<ISSOHandler, StatementsSSOHandler>();
            services.AddTransient<ISSOHandlerFactory, SSOHandlerFactory>();

            services.AddHttpServices(Configuration);
            services.AddHttpService<ICustomerService, CustomerService>();
            services.AddHttpService<IAccountsService, AccountsService>();
            services.AddHttpService<IAccountTransactionsService, AccountTransactionsService>();
            services.AddHttpService<ISmsAuthenticationService, SmsAuthenticationService>();
            services.AddHttpService<IProductService, ProductService>();
            services.AddHttpService<IAuthenticationApiService, AuthenticationApiService>();
            services.Decorate<IProductService, CachedProductService>();
            services.AddTransient<IAccountMenuService, AccountMenuService>();
            services.AddReleaseFeatureToggle(HostingEnvironment.EnvironmentName);
            services.AddTransient<IAccountMenuConfigService, CachedAccountMenuConfigService>();
            services.AddTransient<IProductRule, ProductRule>();
            services.AddSingleton<IScript, CachedScript>();
            services.AddTransient<IContentsService, ContentsService>();
            services.Decorate<IContentsService, CachedContentsService>();
            services.TryAddSingleton<ISystemClock, SystemClock>();

            services.AddLoggerContext();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = API_NAME, Version = "V1" });
                c.EnableAnnotations();
                c.DescribeAllEnumsAsStrings();
                c.CustomSchemaIds(x => x.FullName);
            });

            services.AddAuthorization(options =>
            {
                options.AddPolicy(AuthorizationPolicyTypes.CustomerProfileView,
                    policy =>
                    {
                        policy.AddRequirements(new CustomerProfileViewRequirement());
                    });
                options.AddPolicy(AuthorizationPolicyTypes.UpdateDetails,
                    policy =>
                    {
                        policy.AddRequirements(new UpdateRequirement());
                    });
                options.AddPolicy(AuthorizationPolicyTypes.SmsAuthentication,
                    policy => { policy.AddRequirements(new SmsAuthenticationRequirement()); });
            });

            services.AddTransient<IAuthorizationHandler, UpdateHandler>();
            services.AddTransient<IAuthorizationHandler, CustomerProfileViewHandler>();
            services.AddTransient<IAuthorizationHandler, SmsAuthenticationHandler>();
            services.AddTransient<IStateFactory, MobileStatusStateFactory>();
            services.AddTransient<IGetMobileStatusContext, GetMobileStatusContext>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory,
            IServiceProvider serviceProvider)
        {
            loggerFactory.UseNlog(serviceProvider);
            app.UseRouter(a => a.MapGet("healthcheck", context =>
            {
                context.Response.Headers[HeaderNames.CacheControl] = "no-cache, no-store";
                context.Response.Headers[HeaderNames.Pragma] = "no-cache";
                return context.Response.WriteAsync($"Success from ({env.EnvironmentName})");
            }));

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("../swagger/v1/swagger.json", API_NAME); });
            }

            app.UseExceptionHandler(new ExceptionHandlerOptions
            {
                ExceptionHandler = HandleException
            });

            app.UseAntiForgeryValidation("/api");
            app.UseHttpServices();
            app.UsePerformanceLogger();
            app.UseWebApiAuthentication();
            app.UseMvc();
        }
    }
}
