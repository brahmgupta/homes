﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.SSO
{
    public interface IAuthenticationApiService
    {
        Task<Result<string>> GetFmsSessionId(string customerNumber, string companyCode, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<SSOCode>> GetSSOCodeDetails(string code, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result> SmsAuthenticationRegister(string customerNumber,
            string mobileNumber, CancellationToken cancellationToken = default(CancellationToken));
    }
}
