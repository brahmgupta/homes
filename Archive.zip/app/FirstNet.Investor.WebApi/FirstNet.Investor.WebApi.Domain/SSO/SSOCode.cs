﻿using System;

namespace FirstNet.Investor.WebApi.Domain.SSO
{
    public class SSOCode
    {
        public int Id { get; set; }
        public Guid Code { get; set; }
        public string Token { get; set; }
        public string CustomerNumber { get; set; }
        public string Parameters { get; set; }
        public DateTimeOffset RequestDate { get; set; }
    }

    public class SSOParameters
    {
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
    }
}
