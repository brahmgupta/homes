﻿namespace FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication
{
    public class SmsVerifyResponse : IErrorMessage
    {
        public string AuthenticationResult { get; set; }
        public string Message { get; set; }
    }
}
