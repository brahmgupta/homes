﻿namespace FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication
{
    public interface IErrorMessage
    {
        string Message { get; set; }
    }
}