﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication
{
    public interface ISmsAuthenticationService
    {
        Task<Result<SmsGenerateResponse>> GenerateSms(string customerNumber, string companyCode, string purpose,
            string mobileNumber, CancellationToken cancellationToken = default(CancellationToken));

        Task<Result<SmsStatusResponse>> GetSmsRegistrationStatus(string customerNumber, string companyCode,
            CancellationToken cancellationToken = default(CancellationToken));

        Task<Result<SmsVerifyResponse>> VerifySms(string customerNumber, string companyCode,
            string purpose, string authenticationCode, string mobileNumber,
            CancellationToken cancellationToken = default(CancellationToken));
    }
}
