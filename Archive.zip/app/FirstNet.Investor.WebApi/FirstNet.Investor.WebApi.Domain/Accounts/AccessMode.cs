﻿namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public enum AccessMode
    {
        None,
        ReadOnly,
        Full
    }
}
