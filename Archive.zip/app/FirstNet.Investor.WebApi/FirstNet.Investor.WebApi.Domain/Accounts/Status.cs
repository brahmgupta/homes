﻿
namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public enum Status
    {
        Closed,
        Open,
        Pending
    }
}
