﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public interface IAccountsService
    {
        Task<Result<Account>> Get(string accountNumber, string customerNumber, string sessionId, string companyCode,
            CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<IEnumerable<Account>>> Get(string customerNumber, string sessionId, string companyCode,
            bool details,
            CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<UpdateInsuranceResponse>> UpdateInsurance(string customerNumber, string accountNumber, string sessionId, string companyCode,
            object payload, CancellationToken cancellationToken = default(CancellationToken));
    }
}
