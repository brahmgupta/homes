namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public enum AccountType
    {
        Annuity,
        Cash,
        Pension,
        Superannuation,
        UnitTrust,
        Other
    }
}