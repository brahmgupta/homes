﻿using System;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public class Insurance
    {
        public decimal EmployerSelectedDeathCoverAmount { get; set; }
        public decimal InvestorSelectedDeathCoverAmount { get; set; }
        public decimal TotalDeathCoverAmount { get; set; }
        public decimal EmployerSelectedDeathCoverPremium { get; set; }
        public decimal InvestorSelectedDeathCoverPremium { get; set; }
        public decimal TotalDeathCoverPremium { get; set; }
        public decimal EmployerSelectedTpdCoverAmount { get; set; }
        public decimal InvestorSelectedTpdCoverAmount { get; set; }
        public decimal TotalTpdCoverAmount { get; set; }
        public decimal EmployerSelectedTpdCoverPremium { get; set; }
        public decimal InvestorSelectedTpdCoverPremium { get; set; }
        public decimal TotalTpdCoverPremium { get; set; }
        public decimal EmployerSelectedSciCoverAmount { get; set; }
        public decimal InvestorSelectedSciCoverAmount { get; set; }
        public decimal TotalSciCoverAmount { get; set; }
        public decimal EmployerSelectedSciCoverPremium { get; set; }
        public decimal InvestorSelectedSciCoverPremium { get; set; }
        public decimal TotalSciCoverPremium { get; set; }
        public decimal WaitingPeriod { get; set; }
        public decimal MaximumBenefitPeriod { get; set; }
        public DateTime? InsuranceElectionDate { get; set; }
        public bool? IsSmoker { get; set; }
        public string OccupationClassification { get; set; }
    }
}
