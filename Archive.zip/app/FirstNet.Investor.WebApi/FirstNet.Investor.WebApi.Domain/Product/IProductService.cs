﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.Product
{
    public interface IProductService
    {
        Task<Result<IEnumerable<Country>>> GetCountries(CancellationToken cancellationToken = default(CancellationToken));
    }
}