﻿namespace FirstNet.Investor.WebApi.Domain.Product
{
    public class Country
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
