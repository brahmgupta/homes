﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public interface ICustomerService
    {
        Task<Result<Customer>> Get(string customerNumber, string sessionId, string companyCode,
            CancellationToken cancellationToken = default(CancellationToken));

        Task<Result<UpdateCustomerResponse>> Update(string customerNumber, string sessionId, string companyCode,
            object payload, CancellationToken cancellationToken = default(CancellationToken));
    }
}