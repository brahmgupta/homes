﻿using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class Account
    {
        public string Id { get; set; }
        public string AccountNumber { get; set; }
        public string AccountDesignation { get; set; }
        public string AccountType { get; set; }
        public string ProductCode { get; set; }
        public Address MailingAddress { get; set; }
        public AccessMode AccessMode { get; set; }
        public IEnumerable<CommunicationPreference> CommunicationPreferences { get; set; }
    }
}