﻿using System.Collections.Generic;
using FirstNet.Investor.WebApi.Domain.SeedWork;

namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class Address : ValueObject
    {
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Suburb { get; set; }
        public string State { get; set; }
        public string Postcode { get; set; }
        public string Country { get; set; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return AddressLine1;
            yield return AddressLine2;
            yield return AddressLine3;
            yield return Suburb;
            yield return State;
            yield return Country;
            yield return Postcode;
        }
    }
}