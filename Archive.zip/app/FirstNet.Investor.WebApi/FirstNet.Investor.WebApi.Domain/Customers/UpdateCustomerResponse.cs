﻿namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class UpdateCustomerResponse
    {
        public string ConfirmationId { get; set; }
    }
}