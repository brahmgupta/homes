﻿namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public enum AccessMode
    {
        None,
        ReadOnly,
        Full
    }
}