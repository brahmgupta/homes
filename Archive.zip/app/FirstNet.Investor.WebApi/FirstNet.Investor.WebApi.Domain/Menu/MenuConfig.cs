﻿namespace FirstNet.Investor.WebApi.Domain.Menu
{

    public class MenuConfig
    {
        public MenuConfigItem[] Items { get; set; }
    }
}