﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public interface IAccountTransactionsService
    {
        Task<Result<AccountTransaction>> Get(string accountNumber, string customerNumber, string sessionId, string companyCode,
            CancellationToken cancellationToken = default(CancellationToken));

    }
}
