﻿namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public enum TransactionRefundType
    {
        Redemption,
        Application,
        Others
    }
}
