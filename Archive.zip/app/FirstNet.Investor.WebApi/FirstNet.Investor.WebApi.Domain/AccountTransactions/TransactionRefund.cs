﻿
namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public class TransactionRefund
    {
        public decimal Amount { get; set; }
        public string RefundType { get; set; }
    }
}
