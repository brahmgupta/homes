﻿using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.Countries.Models;
using FirstNet.Investor.WebApi.Domain.Product;
using FirstNet.Investor.WebApi.Infrastructure.Services.Product;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.Response.Models;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class CountryControllerTests : BaseTests
    {
        private readonly Fixture _fixture;
        private const string GET_COUNTIRES_URL = "api/countries";

        public CountryControllerTests()
        {
            _fixture = new Fixture();
        }

        [Fact]
        public async void Get_ShouldReturnSuccessWhenAbleToGetCountries()
        {
            var countries = _fixture.CreateMany<Country>();
            var expected = countries.Select(c => new CountryModel
            {
                Value = c.Code,
                Label = c.Name
            })
            .OrderBy(cm => cm.Label);
            var json = JsonConvert.SerializeObject(countries);
            MockHttp
                .When(HttpMethod.Get, ProductApi.GetCountriesUri(AppSettings.DownstreamSettings.ProductApiSettings.BaseUrl, "1"))
                .WithHeaders("cba-api-key", AppSettings.DownstreamSettings.ProductApiSettings.CbaApiKey)
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(GET_COUNTIRES_URL).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var entity = JToken.Parse(await response.Content.ReadAsStringAsync());
            Assert.True(JToken.DeepEquals(entity, JToken.FromObject(expected, JsonSerializer)));
        }

        [Fact]
        public async void Get_ShouldReturnErrorWhenServiceFails()
        {
            var responseObj = _fixture.CreateMany<object>();
            var json = JsonConvert.SerializeObject(responseObj);
            MockHttp
                .When(HttpMethod.Get, ProductApi.GetCountriesUri(AppSettings.DownstreamSettings.ProductApiSettings.BaseUrl, "1"))
                .WithHeaders("cba-api-key", AppSettings.DownstreamSettings.ProductApiSettings.CbaApiKey)
                .Respond(HttpStatusCode.InternalServerError, new StringContent(json));

            var response = await CreateRequest(GET_COUNTIRES_URL).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
            var result = JsonConvert.DeserializeObject<Error>(await response.Content.ReadAsStringAsync());
            result.Code.Should().Be(ErrorCodes.InternalServerError);
            result.Message.Should().Be("Error retrieving country list");
        }

        [Fact]
        public async Task ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GET_COUNTIRES_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }
    }
}