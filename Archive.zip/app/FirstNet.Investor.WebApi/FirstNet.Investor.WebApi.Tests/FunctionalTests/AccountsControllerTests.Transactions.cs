﻿using AutoFixture;
using FirstNet.Investor.WebApi.Application.AccountTransactions.Models;
using FirstNet.Investor.WebApi.Application.Models;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Domain.AccountTransactions;
using FirstNet.Investor.WebApi.Infrastructure.Services.AccountTransactions;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class AccountsControllerTests
    {
        private const string GET_TRANSACTIONS_URL = "api/accounts/1234567890/transactions";
        private static TransactionViewModel TansactionViewModelCreditWithNoTransactions = new TransactionViewModel();
        private static DateTime currentDate = DateTime.Now;

        private static TransactionViewModel TansactionViewModelCreditWithNoComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = true,  Net = new Amount { Value = 300 }, Refund=new Amount{ Value = 400 }, TransactionType = TransactionType.Credit.ToString(), Status = "Open"} }
        };

        private static TransactionViewModel TansactionViewModelCreditWithComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = false, Net = new Amount { Value = 300 }, TransactionType = TransactionType.Credit.ToString(), Status = "Open",
                    TransactionComponents = new List<TransactionComponentModel>
                    {
                        new TransactionComponentModel{Amount= new Amount{Value = 400}, Description="DEF", IsTaxable = true},
                        new TransactionComponentModel{Amount= new Amount{Value = 500}, Description="DEF", IsTaxable = false}
                    }
                } }
        };
        private static TransactionViewModel TansactionViewModelCreditWithComponentsNoDate = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = null, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = true, Net = new Amount { Value = 300 }, Refund = new Amount { Value = -400 }, TransactionType = TransactionType.Credit.ToString(), Status = "Open",
                    TransactionComponents = new List<TransactionComponentModel>
                    {
                        new TransactionComponentModel{Amount= new Amount{Value = 400}, Description="DEF", IsTaxable = true},
                        new TransactionComponentModel{Amount= new Amount{Value = 500}, Description="DEF", IsTaxable = false}
                    }
                } }
        };

        private static TransactionViewModel TansactionViewModelDebitWithComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = -100 }, TaxesAndFees = new Amount { Value = -200 }, IsRefunded = true, Net = new Amount { Value = -300 }, Refund = new Amount { Value = -400 }, TransactionType = TransactionType.Debit.ToString(), Status = "Open",
                    TransactionComponents = new List<TransactionComponentModel>
                    {
                        new TransactionComponentModel{Amount= new Amount{Value = -400}, Description="DEF", IsTaxable = true},
                        new TransactionComponentModel{Amount= new Amount{Value = -500}, Description="DEF", IsTaxable = false}
                    }
                } }
        };

        private static TransactionViewModel TansactionViewModelSwitchWithComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = true, Net = new Amount { Value = 300 }, Refund = new Amount { Value = 400 }, TransactionType = TransactionType.Switch.ToString(), Status = "Open",
                    TransactionComponents = new List<TransactionComponentModel>
                    {
                        new TransactionComponentModel{Amount= new Amount{Value = 400}, Description="DEF", IsTaxable = true},
                        new TransactionComponentModel{Amount= new Amount{Value = 500}, Description="GHI", IsTaxable = true},
                    }
                } }
        };
        private static TransactionViewModel TansactionViewModelSwitchWithNoComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = true, Net = new Amount { Value = 300 }, Refund = new Amount { Value = 400 }, TransactionType = TransactionType.Switch.ToString(), Status = "Open",
                } }
        };

        private static TransactionViewModel TansactionViewModelCreditWith1Component = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = 100 }, TaxesAndFees = new Amount { Value = 200 }, IsRefunded = true, Net = new Amount { Value = 300 }, Refund = new Amount { Value = 400 }, TransactionType = TransactionType.Credit.ToString(), Status = "Open",
                    TransactionComponents = new List<TransactionComponentModel>
                    {
                        new TransactionComponentModel{Amount= new Amount{Value = 400}, Description="DEF", IsTaxable = true},
                    }
                } }
        };


        private static TransactionViewModel TansactionViewModelDebitWithNoComponents = new TransactionViewModel
        {
            Transactions = new List<TransactionModel> {
                new TransactionModel{ Date = new Date { Value = currentDate }, Description = "ABC", Gross = new Amount { Value = -100 }, TaxesAndFees = new Amount { Value = -200 }, IsRefunded = true, Net = new Amount { Value = -300 }, Refund = new Amount { Value = -400 }, TransactionType = TransactionType.Debit.ToString(), Status = "Open",
                } }
        };

        public static IEnumerable<object[]> Data =>
            new List<object[]>
            {
                new object[] {TansactionViewModelCreditWithNoTransactions, TansactionViewModelCreditWithNoTransactions},
                new object[] {TansactionViewModelCreditWithNoComponents, TansactionViewModelCreditWithNoComponents},
                new object[] {TansactionViewModelCreditWithComponents, TansactionViewModelCreditWithComponents},
                new object[] { TansactionViewModelCreditWithComponentsNoDate, TansactionViewModelCreditWithComponentsNoDate},
                new object[] { TansactionViewModelCreditWith1Component, TansactionViewModelCreditWithNoComponents},
                new object[] {TansactionViewModelDebitWithComponents, TansactionViewModelDebitWithNoComponents},
                new object[] { TansactionViewModelSwitchWithComponents, TansactionViewModelSwitchWithNoComponents},
           };

        [Theory]
        [MemberData(nameof(Data))]
        public async void ShouldGetAccountTransactions(TransactionViewModel inputTransactionViewModel, TransactionViewModel expectedTransactionViewModel)
        {
            string accountNumber = "1234567890";
            string accountType = AccountType.Annuity.ToString();

            List<Transaction> transactions = GetTransactions(inputTransactionViewModel.Transactions);

            var accountTransaction = _fixture.Build<AccountTransaction>()
                .With(a => a.AccountNumber, accountNumber)
                .With(a => a.AccountType, accountType)
                .With(a => a.Transactions, transactions)
                .Create();

            BuildMockForAccountTransactions(accountTransaction);

            var response = await CreateRequest(GET_TRANSACTIONS_URL).GetAsync();
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var receivedJson = JObject.Parse(jsonResponse);
            ValidateAccountTransaction(receivedJson, expectedTransactionViewModel);
        }

        private List<Transaction> GetTransactions(IEnumerable<TransactionModel> transactionModels)
        {
            List<Transaction> transactions = null;
            if (transactionModels != null)
            {
                transactions = new List<Transaction>();
                foreach (TransactionModel transactionModel in transactionModels)
                {
                    var transaction = new Transaction();
                    if (transactionModel.Date != null)
                    {
                        transaction.Date = transactionModel.Date.Value;
                    }
                    transaction.Description = transactionModel.Description;
                    transaction.Amount = transactionModel.Gross.Value;
                    transaction.IsRefunded = transactionModel.IsRefunded;
                    if (transactionModel.Refund != null)
                    {
                        transaction.Refund = new TransactionRefund();
                        transaction.Refund.Amount = transactionModel.Refund.Value;
                    }

                    transaction.Net = transactionModel.Net.Value;
                    transaction.Fees = transactionModel.TaxesAndFees.Value;
                    transaction.Status = transactionModel.Status;
                    transaction.TransactionType = (TransactionType)Enum.Parse(typeof(TransactionType), transactionModel.TransactionType);
                    if (transactionModel.TransactionComponents != null)
                    {
                        var components = new List<TransactionComponent>();
                        foreach (TransactionComponentModel componentModel in transactionModel.TransactionComponents)
                        {
                            var component = new TransactionComponent();
                            component.Amount = componentModel.Amount.Value;
                            component.Description = componentModel.Description;
                            component.IsTaxable = componentModel.IsTaxable;
                            components.Add(component);
                        }
                        transaction.TransactionComponents = components;
                    }
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }


        private void BuildMockForAccountTransactions(AccountTransaction accountTransaction)
        {
            var json = JsonConvert.SerializeObject(accountTransaction);
            GetMockHttpForAccountTransactionsApi(HttpMethod.Get, accountTransaction.AccountNumber).Respond(HttpStatusCode.OK, new StringContent(json));
        }
        private MockedRequest GetMockHttpForAccountTransactionsApi(HttpMethod method, string accountNumber)
        {
            return MockHttp
                .When(method, $"{AppSettings.DownstreamSettings.WealthApiAccountTransactionBaseUrl}/api/transactions")
                .WithHeaders(AccountTransactionsConstants.SessionIdHeaderName, DefaultSessionId)
                .WithHeaders(AccountTransactionsConstants.CompanyCodeHeaderName, DefaultCompanyCode)
                .WithQueryString(AccountTransactionsConstants.CustomerNumberQueryName, DefaultCustomerNumber)
                .WithQueryString(AccountTransactionsConstants.AccountNumberQueryName, accountNumber);
        }

        private void ValidateAccountTransaction(JObject expJson, TransactionViewModel expectedTransactionViewModel)
        {
            if (expectedTransactionViewModel.Transactions == null)
            {
                expJson["transactions"].Should().BeNull();
                return;
            }

            expJson["transactions"].Should().NotBeNull();
            var transactions = expJson["transactions"].ToArray();
            transactions.Count().Should().Be(expectedTransactionViewModel.Transactions.Count());
            var expectedTransactions = expectedTransactionViewModel.Transactions.ToList();
            for (var i = 0; i < transactions.Count(); i++)
            {
                var expectedTransaction = expectedTransactions[i];
                var transaction = transactions[i];
                if (expectedTransaction.Date == null)
                {
                    transaction["date"].Should().BeEmpty();
                    transaction["monthYear"].Should().BeNull();
                }
                else
                {
                    transaction["date"].Should().NotBeNull();
                    transaction["date"]["display"].ToString().Should().Be(expectedTransaction.Date.Display.ToString());
                    transaction["date"]["value"].ToString().Should().Be(expectedTransaction.Date.Value.ToString());
                    transaction["monthYear"].ToString().Should().Be(expectedTransaction.MonthYear);
                }

                transaction["description"].ToString().Should().Be(expectedTransaction.Description.ToString());
                ValidateAmountField(transaction, "taxesAndFees", expectedTransaction.TaxesAndFees);
                ValidateAmountField(transaction, "gross", expectedTransaction.Gross);
                ValidateAmountField(transaction, "net", expectedTransaction.Net);


                transaction["transactionType"].ToString().Should().Be(expectedTransaction.TransactionType.ToString());

                transaction["status"].ToString().Should().Be(expectedTransaction.Status.ToString());
                transaction["isRefunded"].ToString().Should().Be(expectedTransaction.IsRefunded.ToString());
                ValidateAmountField(transaction, "refund", expectedTransaction.Refund);

                if (expectedTransaction.TransactionComponents == null)
                {
                    transaction["transactionComponents"].Should().BeNull();
                }
                else
                {
                    transaction["transactionComponents"].Should().NotBeNull();
                    var components = transaction["transactionComponents"].ToArray();
                    var expectedComponents = expectedTransaction.TransactionComponents.ToList();

                    for (var j = 0; j < components.Count(); j++)
                    {
                        var expectedComponent = expectedComponents[j];
                        var component = components[j];
                        component["description"].ToString().Should().Be(expectedComponent.Description.ToString());
                        ValidateAmountField(component, "amount", expectedComponent.Amount);
                        component["isTaxable"].ToString().Should().Be(expectedComponent.IsTaxable.ToString());
                    }

                }
            }
        }

        private void ValidateAmountField(JToken transaction, string fieldName, Amount expectedAmountField)
        {
            if (expectedAmountField == null)
            {
                transaction[fieldName].Should().BeNull();
            }
            else
            {
                transaction[fieldName].Should().NotBeNull();
                transaction[fieldName]["display"].ToString().Should().Be(expectedAmountField.Display.ToString());
                transaction[fieldName]["value"].ToString().Should().Be(expectedAmountField.Value.ToString());
                if (expectedAmountField.AbsoluteDisplay != null)
                {
                    transaction[fieldName]["absoluteDisplay"].ToString().Should().Be(expectedAmountField.AbsoluteDisplay.ToString());
                }
                else
                {
                    transaction[fieldName]["absoluteDisplay"].Should().BeNull();
                }

            }

        }

        [Theory]
        [InlineData(HttpStatusCode.NotFound)]
        [InlineData(HttpStatusCode.InternalServerError)]
        [InlineData(HttpStatusCode.Forbidden)]
        [InlineData(HttpStatusCode.Unauthorized)]
        [InlineData(HttpStatusCode.BadRequest)]
        public async void ShouldHandleProblems(HttpStatusCode httpStatusCode)
        {
            // Arrange
            var problemDetails = _fixture.Build<ProblemDetails>()
                .With(x => x.Status, (int)httpStatusCode)
                .Create();

            var json = JsonConvert.SerializeObject(problemDetails);
            GetMockHttpForAccountTransactionsApi(HttpMethod.Get, "1234567890")
                .Respond(httpStatusCode, new StringContent(json));

            // Act
            var response = await CreateRequest(GET_TRANSACTIONS_URL).GetAsync();

            // Assert
            var actual = JsonConvert.DeserializeObject<ProblemDetails>(await response.Content.ReadAsStringAsync());
            response.StatusCode.Should().Be(httpStatusCode);
            actual.Should().BeEquivalentTo(problemDetails);
        }
    }
}