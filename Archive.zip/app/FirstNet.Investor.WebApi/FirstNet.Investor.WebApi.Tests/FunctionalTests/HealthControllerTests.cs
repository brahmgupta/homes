using System.Net;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class HealthControllerTests : BaseTests
    {
        [Fact]
        public async Task ShouldReturnOkGivenHealthIsCalled()
        {
            var response = await CreateRequest("healthcheck").AddHeader("Authorization", "Basic dGVzdDp0ZXN0").GetAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}