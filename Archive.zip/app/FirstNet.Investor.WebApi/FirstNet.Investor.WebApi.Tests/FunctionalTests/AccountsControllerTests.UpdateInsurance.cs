﻿using System.Net;
using System.Net.Http;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.Accounts.Models;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.Response.Models;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class AccountsControllerTests
    {
        private const string UPDATE_INSURANCE_URL = "api/accounts/00000111/insurance";

        [Fact]
        public async void UpdateInsurance_ShouldReturnSuccessWhenAbleToUpdateInsurance()
        {
            var insurance = _fixture.Create<UpdateInsuranceModel>();
            var updateInsuranceResponse = new UpdateInsuranceResponse
            {
                ConfirmationId = "123"
            };
            MockHttp
                .When(HttpMethod.Patch, $"{AppSettings.DownstreamSettings.WealthApiAccountBaseUrl}/api/accounts/*")
                .Respond(HttpStatusCode.OK, JsonFormatter.CreateStringContent(updateInsuranceResponse));

            var response = await CreateRequest(UPDATE_INSURANCE_URL, CustomerStepUpClaims)
                .And(r => r.Content = JsonFormatter.CreateStringContent(insurance))
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        [Fact]
        public async void UpdateInsurance_ShouldReturnForbiddenWhenIsEmulation()
        {
            var response = await CreateRequest(UPDATE_INSURANCE_URL, StaffClaims)
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Fact]
        public async void UpdateInsurance_ShouldReturnForbiddenWhenAccessTokenMissing()
        {
            var insurance = _fixture.Create<UpdateInsuranceModel>();

            var response = await Server.CreateRequest(UPDATE_INSURANCE_URL)
                .And(r => r.Content = JsonFormatter.CreateStringContent(insurance))
                .PostAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Theory]
        [InlineData(HttpStatusCode.BadRequest)]
        [InlineData(HttpStatusCode.Forbidden)]
        public async void UpdateInsurance_ShouldReturnFailureWhenUnableToUpdateInsurance(HttpStatusCode httpStatusCode)
        {
            var insurance = _fixture.Create<UpdateInsuranceModel>();
            var errorResponse = new Error("error", "some error");
            MockHttp
                .When(HttpMethod.Patch, $"{AppSettings.DownstreamSettings.WealthApiAccountBaseUrl}/api/accounts/*")
                .Respond(httpStatusCode, JsonFormatter.CreateStringContent(errorResponse));

            var response = await CreateRequest(UPDATE_INSURANCE_URL, CustomerStepUpClaims)
                .And(r => r.Content = JsonFormatter.CreateStringContent(insurance))
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async void UpdateInsurance_ShouldReturnForbiddenWhenNotEmulationOrNotSteppedUp()
        {
            var insurance = _fixture.Create<UpdateInsuranceModel>();
            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/accounts/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.NotFound, new StringContent("test"));

            var response = await CreateRequest(UPDATE_INSURANCE_URL, CustomerClaims)
                .And(r => r.Content = JsonFormatter.CreateStringContent(insurance))
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }
    }
}
