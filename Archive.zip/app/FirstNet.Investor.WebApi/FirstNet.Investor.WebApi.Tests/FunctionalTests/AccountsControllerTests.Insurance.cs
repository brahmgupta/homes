﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using AutoFixture;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.Test;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class AccountsControllerTests
    {
        private class InsuranceTestData
        {
            public string AccountType { get; set; }
            public string ProductAbbreviation { get; set; }
            public decimal EmployerSelectedDeathCoverAmount { get; set; }
            public decimal InvestorSelectedDeathCoverAmount { get; set; }
            public decimal TotalDeathCoverAmount { get; set; }
            public decimal EmployerSelectedDeathCoverPremium { get; set; }
            public decimal InvestorSelectedDeathCoverPremium { get; set; }
            public decimal TotalDeathCoverPremium { get; set; }
            public decimal EmployerSelectedTpdCoverAmount { get; set; }
            public decimal InvestorSelectedTpdCoverAmount { get; set; }
            public decimal TotalTpdCoverAmount { get; set; }
            public decimal EmployerSelectedTpdCoverPremium { get; set; }
            public decimal InvestorSelectedTpdCoverPremium { get; set; }
            public decimal TotalTpdCoverPremium { get; set; }
            public decimal EmployerSelectedSciCoverAmount { get; set; }
            public decimal InvestorSelectedSciCoverAmount { get; set; }
            public decimal TotalSciCoverAmount { get; set; }
            public decimal EmployerSelectedSciCoverPremium { get; set; }
            public decimal InvestorSelectedSciCoverPremium { get; set; }
            public decimal TotalSciCoverPremium { get; set; }
            public decimal WaitingPeriod { get; set; }
            public decimal MaximumBenefitPeriod { get; set; }
            public string InsuranceElectionDate { get; set; }
            public string OccupationClassification { get; set; }
            public string IsSmoker { get; set; }
        }

        private void BuildMockForAccountsApiWithInsuranceData(InsuranceTestData data, string accountNumber)
        {
            Enum.TryParse<AccountType>(data.AccountType, out var accountType);
            var productAbbreviation = data.ProductAbbreviation;
            var insurance = _fixture.Build<Insurance>().Create();

            insurance.EmployerSelectedDeathCoverAmount = data.EmployerSelectedDeathCoverAmount;
            insurance.InvestorSelectedDeathCoverAmount = data.InvestorSelectedDeathCoverAmount;
            insurance.TotalDeathCoverAmount = data.TotalDeathCoverAmount;
            insurance.EmployerSelectedDeathCoverPremium = data.EmployerSelectedDeathCoverPremium;
            insurance.InvestorSelectedDeathCoverPremium = data.InvestorSelectedDeathCoverPremium;
            insurance.TotalDeathCoverPremium = data.TotalDeathCoverPremium;
            insurance.EmployerSelectedTpdCoverAmount = data.EmployerSelectedTpdCoverAmount;
            insurance.InvestorSelectedTpdCoverAmount = data.InvestorSelectedTpdCoverAmount;
            insurance.TotalTpdCoverAmount = data.TotalTpdCoverAmount;
            insurance.EmployerSelectedTpdCoverPremium = data.EmployerSelectedTpdCoverPremium;
            insurance.InvestorSelectedTpdCoverPremium = data.InvestorSelectedTpdCoverPremium;
            insurance.TotalTpdCoverPremium = data.TotalTpdCoverPremium;
            insurance.EmployerSelectedSciCoverAmount = data.EmployerSelectedSciCoverAmount;
            insurance.InvestorSelectedSciCoverAmount = data.InvestorSelectedSciCoverAmount;
            insurance.TotalSciCoverAmount = data.TotalSciCoverAmount;
            insurance.EmployerSelectedSciCoverPremium = data.EmployerSelectedSciCoverPremium;
            insurance.InvestorSelectedSciCoverPremium = data.InvestorSelectedSciCoverPremium;
            insurance.TotalSciCoverPremium = data.TotalSciCoverPremium;
            insurance.WaitingPeriod = data.WaitingPeriod;
            insurance.MaximumBenefitPeriod = data.MaximumBenefitPeriod;

            if (data.InsuranceElectionDate.Equals("0"))
                insurance.InsuranceElectionDate = null;
            else
                insurance.InsuranceElectionDate = Convert.ToDateTime(data.InsuranceElectionDate);
            insurance.OccupationClassification = data.OccupationClassification;
            if (data.IsSmoker.Equals("0"))
                insurance.IsSmoker = null;
            else
                insurance.IsSmoker = Convert.ToBoolean(data.IsSmoker);

            var account = _fixture.Build<Account>()
                .With(b => b.AccountType, accountType)
                .With(b => b.ProductAbbreviation, productAbbreviation)
                .With(b => b.Insurance, insurance)
                .With(b => b.OpenAccountsCount, _openAccountsCount)
                .Create();
            var json = JsonConvert.SerializeObject(account);
            GetMockHttpForAccountsApi(HttpMethod.Get, accountNumber)
                .Respond(HttpStatusCode.OK, new StringContent(json));
        }

        private void ValidateInsuranceDetails(JObject expJson, InsuranceTestData data, string[] expData)
        {
            var dataIndex = 0;
            var account = expJson["account"];
            var insurance = account["insurance"];

            if (data.TotalDeathCoverAmount.ToString().Equals("0") && data.TotalSciCoverAmount.ToString().Equals("0") && data.TotalTpdCoverAmount.ToString().Equals("0"))
                insurance.Should().BeNull();
            else
            {
                if (data.AccountType.Equals("Superannuation"))
                {
                    var covers = insurance["covers"];
                    account["accountType"].ToString().Should().Be(expData[0]);
                    for (int coverType = 0; coverType < covers.Count(); coverType++)
                    {
                        var insuranceType = covers[coverType]["type"].ToString();
                        switch (insuranceType)
                        {
                            case "Death":
                                dataIndex = 1;
                                break;
                            case "Tpd":
                                dataIndex = 7;
                                break;
                            case "Sci":
                                dataIndex = 13;
                                break;
                        }
                        List<string> actualData = new List<string>();
                        if (!expData[dataIndex].Equals("0"))
                        {
                            actualData.Add(covers[coverType]["amount"]["employerSelected"]["display"].ToString());
                            actualData.Add(covers[coverType]["amount"]["investorSelected"]["display"].ToString());
                        }
                        actualData.Add(covers[coverType]["amount"]["total"]["display"].ToString());
                        if (!expData[dataIndex].Equals("0"))
                        {
                            actualData.Add(covers[coverType]["premium"]["employerSelected"]["display"].ToString());
                            actualData.Add(covers[coverType]["premium"]["investorSelected"]["display"].ToString());
                        }
                        actualData.Add(covers[coverType]["premium"]["total"]["display"].ToString());
                        string[] arrActualData = actualData.ToArray();
                        for (int coverModel = 0, actualCover = 0; coverModel < 6; coverModel++)
                        {
                            if (!expData[dataIndex].Equals("0"))
                            {
                                arrActualData[actualCover].Should().Be(expData[dataIndex]);
                                actualCover++;
                            }
                            dataIndex++;
                        }
                    }
                    insurance["insuranceElection"].ToString().Should().Be(expData[19]);
                    insurance["occupationClassification"].ToString().Should().Be(expData[20]);

                    if (string.IsNullOrEmpty(expData[23]))
                        insurance["insuranceElectionDate"].Should().BeNullOrEmpty();
                    else
                        insurance["insuranceElectionDate"].ToString().Should().Be(expData[23]);

                    if (data.ProductAbbreviation.Equals("FCESUP"))
                        insurance["smokerStatus"].Should().BeNullOrEmpty();
                    else
                        insurance["smokerStatus"].ToString().Should().Be(expData[21]);
                }
                else
                    insurance["covers"].ToString().Should().Be("[]");
            }
        }

        [Theory]
        [ExcelData("FunctionalTests\\TestData\\Insurance_TestData.xlsx")]
        public async void ShouldEvaluateInsuranceDetailsWithTestData(string scNo, string accAccountType,
            string accProductAbbreviation, string accEmployerSelectedDeathCoverAmount, string accInvestorSelectedDeathCoverAmount,
            string accTotalDeathCoverAmount, string accEmployerSelectedDeathCoverPremium, string accInvestorSelectedDeathCoverPremium,
            string accTotalDeathCoverPremium, string accEmployerSelectedTpdCoverAmount, string accInvestorSelectedTpdCoverAmount,
            string accTotalTpdCoverAmount, string accEmployerSelectedTpdCoverPremium, string accInvestorSelectedTpdCoverPremium,
            string accTotalTpdCoverPremium, string accEmployerSelectedSciCoverAmount, string accInvestorSelectedSciCoverAmount,
            string accTotalSciCoverAmount, string accEmployerSelectedSciCoverPremium, string accInvestorSelectedSciCoverPremium,
            string accTotalSciCoverPremium, string accWaitingPeriod, string accMaximumBenefitPeriod,
            string accInsuranceElectionDate, string accOccupationClassification, string accIsSmoker,

            string expAccountType, string expProductAbbreviation, string expEmployerSelectedDeathCoverAmount, string expInvestorSelectedDeathCoverAmount,
            string expTotalDeathCoverAmount, string expEmployerSelectedDeathCoverPremium, string expInvestorSelectedDeathCoverPremium,
            string expTotalDeathCoverPremium, string expEmployerSelectedTpdCoverAmount, string expInvestorSelectedTpdCoverAmount,
            string expTotalTpdCoverAmount, string expEmployerSelectedTpdCoverPremium, string expInvestorSelectedTpdCoverPremium,
            string expTotalTpdCoverPremium, string expEmployerSelectedSciCoverAmount, string expInvestorSelectedSciCoverAmount,
            string expTotalSciCoverAmount, string expEmployerSelectedSciCoverPremium, string expInvestorSelectedSciCoverPremium,
            string expTotalSciCoverPremium, string expInsuranceElection, string expOccupationClassification, string expIsSmoker,
            string expInsuranceElectionDate)
        {
            var accountNumber = _fixture.Create<int>();
            var testData = new InsuranceTestData
            {
                AccountType = accAccountType,
                ProductAbbreviation = accProductAbbreviation,
                EmployerSelectedDeathCoverAmount = Convert.ToDecimal(accEmployerSelectedDeathCoverAmount),
                InvestorSelectedDeathCoverAmount = Convert.ToDecimal(accInvestorSelectedDeathCoverAmount),
                TotalDeathCoverAmount = Convert.ToDecimal(accTotalDeathCoverAmount),
                EmployerSelectedDeathCoverPremium = Convert.ToDecimal(accEmployerSelectedDeathCoverPremium),
                InvestorSelectedDeathCoverPremium = Convert.ToDecimal(accInvestorSelectedDeathCoverPremium),
                TotalDeathCoverPremium = Convert.ToDecimal(accTotalDeathCoverPremium),
                EmployerSelectedTpdCoverAmount = Convert.ToDecimal(accEmployerSelectedTpdCoverAmount),
                InvestorSelectedTpdCoverAmount = Convert.ToDecimal(accInvestorSelectedTpdCoverAmount),
                TotalTpdCoverAmount = Convert.ToDecimal(accTotalTpdCoverAmount),
                EmployerSelectedTpdCoverPremium = Convert.ToDecimal(accEmployerSelectedTpdCoverPremium),
                InvestorSelectedTpdCoverPremium = Convert.ToDecimal(accInvestorSelectedTpdCoverPremium),
                TotalTpdCoverPremium = Convert.ToDecimal(accTotalTpdCoverPremium),
                EmployerSelectedSciCoverAmount = Convert.ToDecimal(accEmployerSelectedSciCoverAmount),
                InvestorSelectedSciCoverAmount = Convert.ToDecimal(accInvestorSelectedSciCoverAmount),
                TotalSciCoverAmount = Convert.ToDecimal(accTotalSciCoverAmount),
                EmployerSelectedSciCoverPremium = Convert.ToDecimal(accEmployerSelectedSciCoverPremium),
                InvestorSelectedSciCoverPremium = Convert.ToDecimal(accInvestorSelectedSciCoverPremium),
                TotalSciCoverPremium = Convert.ToDecimal(accTotalSciCoverPremium),
                WaitingPeriod = Convert.ToDecimal(accWaitingPeriod),
                MaximumBenefitPeriod = Convert.ToDecimal(accMaximumBenefitPeriod),
                InsuranceElectionDate = accInsuranceElectionDate,
                OccupationClassification = accOccupationClassification,
                IsSmoker = accIsSmoker
            };

            string[] expectedTestData =
            {
                expAccountType, //0
                expEmployerSelectedDeathCoverAmount, //1
                expInvestorSelectedDeathCoverAmount,
                expTotalDeathCoverAmount,
                expEmployerSelectedDeathCoverPremium,
                expInvestorSelectedDeathCoverPremium,
                expTotalDeathCoverPremium, //6
                expEmployerSelectedTpdCoverAmount, //7
                expInvestorSelectedTpdCoverAmount,
                expTotalTpdCoverAmount,
                expEmployerSelectedTpdCoverPremium,
                expInvestorSelectedTpdCoverPremium,
                expTotalTpdCoverPremium,
                expEmployerSelectedSciCoverAmount, //13
                expInvestorSelectedSciCoverAmount,
                expTotalSciCoverAmount,
                expEmployerSelectedSciCoverPremium,
                expInvestorSelectedSciCoverPremium,
                expTotalSciCoverPremium,
                expInsuranceElection, //19
                expOccupationClassification,
                expIsSmoker,
                expProductAbbreviation,
                expInsuranceElectionDate
            };

            BuildMockForAccountsApiWithInsuranceData(testData, accountNumber.ToString());

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var expectedJson = JObject.Parse(jsonResponse);

            ValidateInsuranceDetails(expectedJson, testData, expectedTestData);
        }
    }
}