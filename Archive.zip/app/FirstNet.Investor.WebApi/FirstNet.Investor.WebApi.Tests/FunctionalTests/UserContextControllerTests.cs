using System.Net;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FirstNet.Investor.WebApi.Tests.Helpers;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class UserContextControllerTests : BaseTests
    {
        private const string GET_USER_CONTEXT_URL = "api/userContext";

        [Fact]
        public async Task ShouldReturnSuccessWhenAbleToGetExperienceSettings()
        {
            var response = await CreateRequest(GET_USER_CONTEXT_URL).GetAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GET_USER_CONTEXT_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task ShouldReturnUnAuthenticatedWhenAccessTokenMissing()
        {
            var response = await Server.CreateRequest(GET_USER_CONTEXT_URL).AddAntiForgeryHeader().GetAsync();

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }
    }
}