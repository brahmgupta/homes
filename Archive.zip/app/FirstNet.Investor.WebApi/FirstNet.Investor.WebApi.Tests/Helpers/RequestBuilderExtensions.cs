﻿using Microsoft.AspNetCore.TestHost;

namespace FirstNet.Investor.WebApi.Tests.Helpers
{
    public static class RequestBuilderExtensions
    {
        private const string ANTI_FORGERY_HEADER_NAME = "X-Requested-With";
        private const string ANTI_FORGERY_HEADER_VALUE = "XMLHttpRequest";

        public static RequestBuilder AddAntiForgeryHeader(this RequestBuilder requestBuilder)
        {
            return requestBuilder.AddHeader(ANTI_FORGERY_HEADER_NAME, ANTI_FORGERY_HEADER_VALUE);
        }
    }
}
