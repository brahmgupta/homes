﻿using System.IO;
using System.Threading.Tasks;

namespace FirstNet.Investor.WebApi.Tests.Helpers
{
    internal static class TestUtils
    {
        public static async Task<string> ReadFileAsync(string path)
        {
            using (var reader = File.OpenText(path))
            {
                return await reader.ReadToEndAsync();
            }
        }
    }
}
