﻿using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace FirstNet.Investor.WebApi.Tests.Helpers
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class JsonFormatter
    {
        private const string MEDIA_TYPE = "application/json";

        private static readonly JsonSerializerSettings JsonSerializerSettings = new JsonSerializerSettings
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver
            {
                NamingStrategy = new CamelCaseNamingStrategy {ProcessDictionaryKeys = false}
            }
        };

        public static string SerializeToJson(object obj)
        {
            return JsonConvert.SerializeObject(
                obj,
                Formatting.None,
                JsonSerializerSettings
            );
        }

        public static StringContent CreateStringContent(object obj)
        {
            return new StringContent(
                SerializeToJson(obj),
                Encoding.UTF8,
                MEDIA_TYPE
            );
        }

        public static StringContent CreateStringContentFromString(string json)
        {
            return new StringContent(json, Encoding.UTF8, MEDIA_TYPE);
        }
    }
}