using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.SpaServices.ReactDevelopmentServer;
using Microsoft.AspNetCore.StaticFiles.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Wealth.Toolkit.Configuration;
using Wealth.Toolkit.HttpService.Extensions;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;

namespace FirstNet.Investor.WebApp
{
    public class Startup
    {
        private const string ClientAppPath = "ClientApp";
        private const string ClientAppBuildPath = "build";

        public Startup(IConfiguration configuration)
        {
            configuration.LoadAppSecrets("appsecrets.json", "FirstNet.Investor.WebApp.appSecrets.key");
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddHttpServices(Configuration);
            // In production, the React files will be served from this directory
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = $"{ClientAppPath}/{ClientAppBuildPath}";
            });

            services.AddLoggerContext();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory,
            IServiceProvider serviceProvider)
        {
            loggerFactory.UseNlog(serviceProvider);

            app.UseRouter(a => a.MapGet("healthcheck", context =>
            {
                context.Response.Headers[HeaderNames.CacheControl] = "no-cache, no-store";
                context.Response.Headers[HeaderNames.Pragma] = "no-cache";
                return context.Response.WriteAsync($"Success from ({env.EnvironmentName})");
            }));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UsePerformanceLogger();
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSpaStaticFiles();
            app.UseHttpServices();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller}/{action=Index}/{id?}");
            });

            app.UseSpa(spa =>
            {
                spa.Options.SourcePath = ClientAppPath;
                spa.Options.DefaultPageStaticFileOptions = new StaticFileOptions
                {
                    OnPrepareResponse = (context) =>
                    {
                        var headers = context.Context.Response.GetTypedHeaders();
                        headers.CacheControl = new CacheControlHeaderValue {NoCache = true, NoStore = true};
                    }
                };

                // NOTE: ONLY uncomment below code block when running from Visual Studio
                // and at development time
                //if (env.IsDevelopment())
                //{
                //    spa.UseReactDevelopmentServer(npmScript: "start");
                //}
            });
        }
    }
}
