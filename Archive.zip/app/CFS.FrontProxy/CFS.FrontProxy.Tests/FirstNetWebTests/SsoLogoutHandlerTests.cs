﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using CFS.FrontProxy.Authentication.Sso;
using NSubstitute;
using Xunit;
using Microsoft.Extensions.Logging;

namespace CFS.FrontProxy.Tests.FirstNetWebTests
{
    public class SsoLogoutHandlerTests
    {
        private readonly HttpClient _client;
        private readonly ISsoSettings _fnCookieSettings;

        public SsoLogoutHandlerTests()
        {
            ILoggerFactory loggerFactory = Substitute.For<ILoggerFactory>();
            _fnCookieSettings = Substitute.For<ISsoSettings>();
            _fnCookieSettings.LegacyLogoutUrl.Returns("http://test");
            _client = new HttpClient(new SsoLogoutHandler(loggerFactory, _fnCookieSettings));
        }

        [Fact]
        public async void ShouldClear_AuthenticationCookies_When_Invoked()
        {
            _fnCookieSettings.CookieName.Returns("fnac");
            _fnCookieSettings.CSRFCookieName.Returns("fnrt");
            _fnCookieSettings.CookiePath.Returns("/");

            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
            Assert.Equal("http://test/?FromUrl=fp", response.Headers.Location.ToString());
            Assert.Equal(2, response.Headers.GetValues("Set-Cookie").Count());
            Assert.Equal(string.Empty, response.Headers.GetValues("Set-Cookie").ElementAt(0).Split(";").First().Split("=")[1]);
            Assert.Equal(string.Empty, response.Headers.GetValues("Set-Cookie").ElementAt(1).Split(";").First().Split("=")[1]);
        }
    }
}
