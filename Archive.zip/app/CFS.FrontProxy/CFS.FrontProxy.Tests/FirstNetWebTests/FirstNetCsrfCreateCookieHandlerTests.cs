﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using CFS.FrontProxy.Authentication.CSRF;
using CFS.FrontProxy.Authentication.Sso;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Xunit;

namespace CFS.FrontProxy.Tests.FirstNetWebTests
{
    public class FirstNetCSRFCreateCookieHandlerTests
    {
        private readonly HttpClient _client;
        private readonly ISsoSettings _fnCookieSettings;

        public FirstNetCSRFCreateCookieHandlerTests()
        {
            ILoggerFactory loggerFactory = Substitute.For<ILoggerFactory>();
            _fnCookieSettings = Substitute.For<ISsoSettings>();
            _fnCookieSettings.LegacyLoginUrl.Returns("http://test");
            var csrfCreateCookieHandler = new FirstNetCSRFCreateCookieHandler(loggerFactory, _fnCookieSettings)
            {
                InnerHandler = new SsoCallbackHandler(loggerFactory, _fnCookieSettings)
            };
            _client = new HttpClient(csrfCreateCookieHandler);
        }

        [Fact]
        public async void ShouldCreate_RequesTokenCookie_When_AccessToken_NotFoundAsync()
        {
            _fnCookieSettings.CookieName.Returns("fnac");
            _fnCookieSettings.CookiePath.Returns("/");
            _fnCookieSettings.CSRFCookieName.Returns("fnrt");

            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
            Assert.Equal("http://test/", response.Headers.Location.ToString());
            Assert.Single(response.Headers, header => header.Key.Equals("Set-Cookie"));
        }

        [Fact]
        public async void ShouldCreate_RequesTokenCookie_When_AccessToken_PassesValidationAsync()
        {
            _fnCookieSettings.CookieName.Returns("fnac");
            _fnCookieSettings.CookiePath.Returns("/");
            _fnCookieSettings.CSRFCookieName.Returns("fnrt");

            var formContent = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("access_token", "access-token"),
                new KeyValuePair<string, string>("state", "http://test")
            });
            var response = await _client.PostAsync(new Uri("http://test"), formContent);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
            Assert.Equal("http://test/", response.Headers.Location.ToString());
            Assert.Equal(2, response.Headers.GetValues("Set-Cookie").Count());
        }
    }
}