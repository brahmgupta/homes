﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using CFS.FrontProxy.Authentication.Sso;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Xunit;

namespace CFS.FrontProxy.Tests.FirstNetWebTests
{
    public class FirstNetBrowserSessionValidationHandlerTests
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public FirstNetBrowserSessionValidationHandlerTests()
        {
            var loggerFactory = Substitute.For<ILoggerFactory>();
            var ssoSettings = Substitute.For<ISsoSettings>();
            ssoSettings.LegacyLogoutUrl.Returns("http://test");
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _client = new HttpClient(new FirstNetBrowserSessionValidationHandler(loggerFactory, ssoSettings, _httpContextAccessor));
        }

        [Fact]
        public async void Should_Return_RedirectStatus_When_BrowserSessionClaim_NotFound_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(true);
            _httpContextAccessor.HttpContext.Request.Cookies[Arg.Any<string>()].Returns(Guid.NewGuid().ToString());

            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
        }

        [Fact]
        public async void Should_Return_RedirectStatus_When_BrowserSessionCookie_NotFound_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(false);
            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
        }

        [Fact]
        public async void Should_Return_RedirectStatus_When_BrowserSessionClaim_DoesNotMatch_BrowserSessionCookie_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(true);
            _httpContextAccessor.HttpContext.Request.Cookies[Arg.Any<string>()].Returns(Guid.NewGuid().ToString());
            _httpContextAccessor.HttpContext.User.Claims.Returns(
                new List<Claim>().Append(new Claim("browserSessionId", "abc")));

            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
        }
    }
}
