﻿using System;
using System.Net;
using System.Net.Http;
using CFS.FrontProxy.Authentication.CSRF;
using CFS.FrontProxy.Authentication.Sso;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using NSubstitute;
using Xunit;

namespace CFS.FrontProxy.Tests.FirstNetWebTests
{
    public class FirstNetCSRFValidateCookieHandlerTests
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public FirstNetCSRFValidateCookieHandlerTests()
        {
            var loggerFactory = Substitute.For<ILoggerFactory>();
            var fnCookieSettings = Substitute.For<ISsoSettings>();
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _client = new HttpClient(new FirstNetCSRFValidateCookieHandler(loggerFactory, fnCookieSettings, _httpContextAccessor));
        }

        [Fact]
        public async void Should_Return_ForbiddenStatus_When_XCSRFTokenHeader_DoesNotMatch_TokenCookie_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(true);
            _httpContextAccessor.HttpContext.Request.Cookies[Arg.Any<string>()].Returns(Guid.NewGuid().ToString());
            _httpContextAccessor.HttpContext.Request.Headers.ContainsKey(Arg.Any<string>()).Returns(true);
            _httpContextAccessor.HttpContext.Request.Headers[Arg.Any<string>()].Returns(new StringValues("abc"));

            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Forbidden);
        }

        [Fact]
        public async void Should_Return_ForbiddenStatus_When_XCSRFTokenHeader_DoesNotExist_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(true);
            _httpContextAccessor.HttpContext.Request.Cookies[Arg.Any<string>()].Returns(Guid.NewGuid().ToString());
            _httpContextAccessor.HttpContext.Request.Headers.ContainsKey(Arg.Any<string>()).Returns(false);
            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Forbidden);
        }

        [Fact]
        public async void Should_Return_ForbiddenStatus_When_TokenCookie_DoesNotExist_Async()
        {
            _httpContextAccessor.HttpContext.Request.Cookies.ContainsKey(Arg.Any<string>()).Returns(false);
            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Forbidden);
        }
    }
}
