﻿using CFS.FrontProxy.Authentication.CSRF;
using CFS.FrontProxy.Authentication.Sso;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Ocelot.DependencyInjection;
using Wealth.Lib.AntiForgery;
using Wealth.Lib.InternalAccessToken.Factory;

namespace CFS.FrontProxy.Routing
{
    public static class AddFrontProxyOcelotExtension
    {
        public static string ConfigurationSectionName = "InternalAccessToken";

        public static IServiceCollection AddFrontProxyOcelot(this IServiceCollection services, IConfiguration configuration)
        {
            var section = configuration.GetSection(ConfigurationSectionName);
            services.Configure<InternalAccessTokenRoutingSettings>(section);

            services.TryAddSingleton(s => s.GetRequiredService<IOptions<InternalAccessTokenRoutingSettings>>().Value);
            services.TryAddSingleton<IInternalAccessTokenFactorySettings, InternalAccessTokenRoutingSettings>();
            services.TryAddSingleton<InternalAccessTokenFactory>();

            services.AddOcelot()
                .AddDelegatingHandler<AntiForgeryHandler>(true)
                .AddDelegatingHandler<SsoCallbackHandler>()
                .AddDelegatingHandler<FirstNetCSRFCreateCookieHandler>()
                .AddDelegatingHandler<FirstNetCSRFValidateCookieHandler>()
                .AddDelegatingHandler<SsoLogoutHandler>()
                .AddDelegatingHandler<FirstNetBrowserSessionValidationHandler>();

            return services;
        }
    }
}
