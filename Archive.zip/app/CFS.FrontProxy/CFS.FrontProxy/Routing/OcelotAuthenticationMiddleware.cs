﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Ocelot.Configuration.Creator;
using Ocelot.DownstreamRouteFinder.UrlMatcher;
using Ocelot.Middleware;
using CFS.FrontProxy.Authentication;
using Wealth.Lib.InternalAccessToken.Factory;
using Wealth.Toolkit.HttpService.CorrelationId;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using Wealth.Toolkit.HttpService.ServiceAuthentication;
using Microsoft.Net.Http.Headers;

namespace CFS.FrontProxy.Routing
{
    public class OcelotAuthenticationMiddleware
    {
        public static async Task Middleware(DownstreamContext ctx, Func<Task> next)
        {
            var authenticationService = ctx.HttpContext.RequestServices.GetService<IAuthenticationService>();
            var routingSettings = ctx.HttpContext.RequestServices.GetService<InternalAccessTokenRoutingSettings>();
            var internalAccessTokenFactory = ctx.HttpContext.RequestServices.GetService<InternalAccessTokenFactory>();
            var correlationIdAccessor = ctx.HttpContext.RequestServices.GetService<ICorrelationIdAccessor>();
            var correlationIdSettings = ctx.HttpContext.RequestServices.GetService<IOptions<CorrelationIdSettings>>();
            var serviceAuthenticationCredentials = ctx.HttpContext.RequestServices.GetService<IOptions<ServiceAuthenticationCredentials>>();
            ctx.HttpContext.SetDownstreamContext(ctx);

            var scheme = ctx.DownstreamReRoute.AuthenticationOptions.AuthenticationProviderKey;
            ctx.DownstreamRequest.Headers.Clear();

            var result = await authenticationService.AuthenticateAsync(ctx.HttpContext, scheme);

            if (!result.Succeeded)
            {
                var authProperties = result.Properties;

                await authenticationService.ForbidAsync(ctx.HttpContext, scheme, authProperties);
                // Ocelot pipeline require valid DownstreamResponse if no errors set via context.SetError
                // In our case we want full control over Response so we construct the desired output in the
                // relevant authentication handler and assign it to ctx.DownstreamResponse.
                ctx.DownstreamResponse = ctx.HttpContext.GetDownstreamResponse();
                return;
            }

            var user = ctx.HttpContext.User = result.Principal;

            var jwt = internalAccessTokenFactory.Create(user.Claims.ToArray());
            ctx.DownstreamRequest.Headers.Add(routingSettings.HeaderName, jwt);

            var claimsPlaceholders = GetClaimsPlaceholders(user, routingSettings.ClaimsEnabledInRoutes ?? Array.Empty<string>());

            if (claimsPlaceholders.Any())
            {
                ctx.TemplatePlaceholderNameAndValues.AddRange(claimsPlaceholders);
            }

            var correlationId = correlationIdAccessor.GetCorrelationId();

            if (correlationId != null)
            {
                ctx.DownstreamRequest.Headers.Add(correlationIdSettings.Value.HeaderName, correlationId);
            }

            IncludeHeadersFromConfig(ctx.HttpContext.Request.Headers, ctx.DownstreamRequest.Headers, ctx.DownstreamReRoute.AddHeadersToUpstream, ctx.TemplatePlaceholderNameAndValues);

            IncludeServiceAuthentication(ctx.DownstreamRequest.Headers, serviceAuthenticationCredentials.Value);

            await next();
        }

        private static IReadOnlyCollection<PlaceholderNameAndValue> GetClaimsPlaceholders(ClaimsPrincipal user, IEnumerable<string> claimsEnabledInRoutes)
        {
            if (!claimsEnabledInRoutes.Any())
            {
                return Array.Empty<PlaceholderNameAndValue>();
            }

            var placeholders = new List<PlaceholderNameAndValue>(claimsEnabledInRoutes.Count());

            foreach (var enabledClaimName in claimsEnabledInRoutes)
            {
                var claim = user.Claims.FirstOrDefault(c => c.Type == enabledClaimName);

                if (claim == null)
                {
                    continue;
                }

                placeholders.Add(new PlaceholderNameAndValue($"{{{claim.Type}}}", claim.Value));
            }

            return placeholders;
        }

        private static void IncludeServiceAuthentication(HttpRequestHeaders targetHeaders, ServiceAuthenticationCredentials credentials)
        {
            var credentialsPresent = credentials?.AccountName != null && credentials.Password != null;

            if (credentialsPresent)
            {
                var bytes = Encoding.ASCII.GetBytes($"{credentials.AccountName}:{credentials.Password}");

                targetHeaders.Add(HeaderNames.Authorization, $"Basic {Convert.ToBase64String(bytes)}");
            }
        }

        private static void IncludeHeadersFromConfig(IHeaderDictionary sourceHeaders, HttpRequestHeaders targetHeaders, IReadOnlyCollection<AddHeader> newHeaders, IReadOnlyCollection<PlaceholderNameAndValue> templatePlaceholderNameAndValues)
        {
            foreach (var newHeader in newHeaders)
            {
                if (TryGetSelfKey(newHeader.Key, out var selfKey) && sourceHeaders.ContainsKey(selfKey))
                {
                    targetHeaders.Add(selfKey, sourceHeaders[selfKey].ToArray());
                    continue;
                }

                var headerValue = GetContentWithProcessedPlaceholders(newHeader.Value, templatePlaceholderNameAndValues);

                targetHeaders.Add(newHeader.Key, headerValue);
            }
        }

        private static bool TryGetSelfKey(string headerName, out string selfName)
        {
            var isSelf = headerName.Length > 2 && headerName.StartsWith("{") && headerName.EndsWith("}");

            selfName = isSelf
                ? headerName.Substring(1, headerName.Length - 2)
                : null;

            return isSelf;
        }

        private static string GetContentWithProcessedPlaceholders(string content, IReadOnlyCollection<PlaceholderNameAndValue> items)
        {
            foreach (var item in items)
            {
                content = content.Replace(item.Name, item.Value);
            }

            return content;
        }
    }
}
