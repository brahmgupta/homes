﻿using System.Collections.Generic;
using Wealth.Lib.InternalAccessToken.Factory;

namespace CFS.FrontProxy.Routing
{
    public class InternalAccessTokenRoutingSettings : IInternalAccessTokenFactorySettings
    {
        public string HeaderName { get; set; }

        public IEnumerable<string> ClaimsEnabledInRoutes { get; set; }

        public string Issuer { get; set; }

        public string Audience { get; set; }
    }
}
