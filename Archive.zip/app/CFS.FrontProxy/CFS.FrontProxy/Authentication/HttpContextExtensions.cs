﻿using Microsoft.AspNetCore.Http;
using Ocelot.Middleware;

namespace CFS.FrontProxy.Authentication
{
    public static class HttpContextExtensions
    {
        private static string DownstreamResponse { get; } = "DownstreamResponseKey";
        private static string DownstreamContext { get; } = "DownstreamContextKey";

        public static DownstreamResponse GetDownstreamResponse(this HttpContext @this)
        {
            return (DownstreamResponse)@this.Items[DownstreamResponse];
        }

        public static void SetDownstreamResponse(this HttpContext @this, DownstreamResponse downstreamResponse)
        {
            @this.Items[DownstreamResponse] = downstreamResponse;
        }
        public static DownstreamContext GetDownstreamContext(this HttpContext @this)
        {
            return (DownstreamContext)@this.Items[DownstreamContext];
        }

        public static void SetDownstreamContext(this HttpContext @this, DownstreamContext context)
        {
            @this.Items[DownstreamContext] = context;
        }
    }
}
