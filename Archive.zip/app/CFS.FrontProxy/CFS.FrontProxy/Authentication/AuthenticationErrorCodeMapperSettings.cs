﻿using System.Collections.Generic;

namespace CFS.FrontProxy.Authentication
{
    public class AuthenticationErrorCodeMapperSettings
    {
        public Dictionary<string, string> AccessToken { get; set; }
        public Dictionary<string, string> Cookie { get; set; }
        public string FallbackErrorCode { get; set; }
    }
}
