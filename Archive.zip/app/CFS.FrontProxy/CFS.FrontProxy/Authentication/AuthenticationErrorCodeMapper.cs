﻿using CFS.FrontProxy.Authentication.AccessToken;
using Wealth.Lib.InvestorAuthentication.Cookie;

namespace CFS.FrontProxy.Authentication
{
    public class AuthenticationErrorCodeMapper
    {
        private readonly AuthenticationErrorCodeMapperSettings _settings;

        public AuthenticationErrorCodeMapper(AuthenticationErrorCodeMapperSettings settings)
        {
            _settings = settings;
        }

        public string MapTokenErrorCode(AccessTokenErrorCode? accessTokenErrorCode)
        {
            if (accessTokenErrorCode.HasValue && _settings.AccessToken.TryGetValue(accessTokenErrorCode.Value.ToString(), out var errorCode))
            {
                return errorCode;
            }

            return _settings.FallbackErrorCode;
        }

        public string MapCookieErrorCode(CookieErrorCode? cookieErrorCode)
        {

            if (cookieErrorCode.HasValue && _settings.Cookie.TryGetValue(cookieErrorCode.Value.ToString(), out var errorCode))
            {
                return errorCode;
            }

            return _settings.FallbackErrorCode;
        }
    }
}
