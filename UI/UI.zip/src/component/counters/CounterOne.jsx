import React, { Component ,Fragment } from "react";

class ServiceDetails extends Component{
    render(){
        return(
            <Fragment>
                <h1>Hi Counters</h1>
            </Fragment>
        )
    }
}
export default ServiceDetails;